# -*- coding: utf-8 -*-
"""Cálculo del perfil de un alumno y del resumen de una clase (octágono de 8 habilidades).

Principios:
- Se muestran DOS capas: lo que el alumno dice de sí mismo (test) y lo observado en los minijuegos.
- Para clasificar una habilidad se usa el minijuego si existe; si no, el test, marcado como «provisional».
- Nunca se calcula un puntaje global ni un ranking entre alumnos.
"""
from collections import Counter

import catalogo as K
import juegos as J

N_DESTACADAS = 3
N_IMPULSAR = 2


def perfil_alumno(resultado_test, partidas):
    """resultado_test: dict de cuestionario.calcular_resultado (o None).
    partidas: {juego_id: {"puntaje": int, "detalle": dict, "fecha": str}} (la más reciente de cada juego)."""
    habilidades = []
    for orden, h in enumerate(K.HABILIDADES):
        auto = resultado_test["auto"].get(h["id"]) if resultado_test else None
        p = partidas.get(h["juego"])
        juego = p["puntaje"] if p else None
        valor = juego if juego is not None else auto
        fuente = "juego" if juego is not None else ("test" if auto is not None else None)
        habilidades.append({"id": h["id"], "nombre": h["nombre"], "orden": orden, "auto": auto, "juego": juego,
                            "valor": valor, "fuente": fuente, "nivel": K.nivel(valor),
                            "provisional": fuente == "test"})
    con_dato = [h for h in habilidades if h["valor"] is not None]
    # Destacadas: las más altas (mínimo 50). Para impulsar: las más bajas (menos de 75) que no sean destacadas.
    por_alto = sorted(con_dato, key=lambda h: (-h["valor"], 0 if h["fuente"] == "juego" else 1, h["orden"]))
    destacadas = [h["id"] for h in por_alto if h["valor"] >= K.UMBRAL_DESARROLLO][:N_DESTACADAS]
    por_bajo = sorted([h for h in con_dato if h["id"] not in destacadas],
                      key=lambda h: (h["valor"], 0 if h["fuente"] == "juego" else 1, h["orden"]))
    impulsar = [h["id"] for h in por_bajo if h["valor"] < K.UMBRAL_DESTACA][:N_IMPULSAR]
    return {
        "habilidades": habilidades,
        "destacadas": destacadas,
        "impulsar": impulsar,
        "estilo": resultado_test["estilo"] if resultado_test else None,
        "intereses": resultado_test["intereses"] if resultado_test else [],
        "tiene_test": resultado_test is not None,
        "juegos_hechos": len(partidas),
        "juegos_total": len(J.CATALOGO),
    }


def recomendaciones(perfil, partidas, asignados=()):
    """Sugerencias (no decisiones) de minijuegos: 2 para lucirse y 2 para fortalecer."""
    out = []
    for hid, razon in [(h, "destaca") for h in perfil["destacadas"][:2]] + [(h, "impulsar") for h in perfil["impulsar"]]:
        jid = K.HAB[hid]["juego"]
        out.append({"juego": jid, "habilidad": hid, "razon": razon,
                    "jugado": jid in partidas, "asignado": jid in asignados})
    return out


def resumen_clase(perfiles):
    """perfiles: lista de perfil_alumno(...) de los alumnos de la clase."""
    n = len(perfiles)
    habilidades = []
    for h in K.HABILIDADES:
        vals, autos, juegos, destacan = [], [], [], 0
        for p in perfiles:
            x = next(a for a in p["habilidades"] if a["id"] == h["id"])
            if x["valor"] is not None:
                vals.append(x["valor"])
                destacan += h["id"] in p["destacadas"]
            if x["auto"] is not None:
                autos.append(x["auto"])
            if x["juego"] is not None:
                juegos.append(x["juego"])
        media = lambda L: round(sum(L) / len(L)) if L else None  # noqa: E731
        habilidades.append({"id": h["id"], "nombre": h["nombre"], "valor": media(vals), "auto": media(autos),
                            "juego": media(juegos), "n": len(vals), "n_juego": len(juegos), "destacan": destacan})
    con_dato = [h for h in habilidades if h["valor"] is not None]
    top = [h["id"] for h in sorted(con_dato, key=lambda h: (-h["valor"], -h["n_juego"]))[:3]]
    estilos = Counter(p["estilo"]["principal"] for p in perfiles if p["estilo"])
    apoyo = Counter(p["estilo"]["secundario"] for p in perfiles if p["estilo"] and p["estilo"]["secundario"])
    intereses = Counter(i for p in perfiles for i in p["intereses"])
    return {
        "alumnos": n,
        "con_test": sum(1 for p in perfiles if p["tiene_test"]),
        "con_juegos": sum(1 for p in perfiles if p["juegos_hechos"] > 0),
        "habilidades": habilidades,
        "destacadas": top,
        "estilos": {c: estilos.get(c, 0) for c in "VAK"},
        "estilos_apoyo": {c: apoyo.get(c, 0) for c in "VAK"},
        "intereses": [{"id": i, "n": c} for i, c in intereses.most_common()],
    }
