# -*- coding: utf-8 -*-
"""PDF por alumno y por clase (ReportLab). Incluye el octágono de 8 habilidades dibujado con vectores."""
import io
import math
from datetime import datetime

from reportlab.graphics.shapes import Circle, Drawing, Line, Polygon, Rect, String
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.platypus import (KeepTogether, PageBreak, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle)

import catalogo as K
import juegos as J

NAVY = colors.HexColor("#1f2358")
GOLD = colors.HexColor("#f5b82e")
GREY = colors.HexColor("#5b6080")
LIGHT = colors.HexColor("#eef0ff")
INK = colors.HexColor("#22264a")
LAVENDER = colors.HexColor("#8b97ff")
COLOR_CANAL = {"V": colors.HexColor("#2f7de0"), "A": colors.HexColor("#d6457a"), "K": colors.HexColor("#e8862f")}
COLOR_NIVEL = {"Destaca": colors.HexColor("#1fa860"), "En desarrollo": colors.HexColor("#d99a00"),
               "Para impulsar": colors.HexColor("#6c5ce7")}


def _estilos():
    base = getSampleStyleSheet()
    return {
        "titulo": ParagraphStyle("titulo", parent=base["Title"], fontName="Helvetica-Bold", fontSize=22,
                                 textColor=colors.white, alignment=TA_CENTER, leading=26),
        "sub": ParagraphStyle("sub", parent=base["Normal"], fontSize=10.5, textColor=colors.HexColor("#d7dbff"),
                              alignment=TA_CENTER),
        "h2": ParagraphStyle("h2", parent=base["Heading2"], fontName="Helvetica-Bold", fontSize=13.5,
                             textColor=NAVY, spaceBefore=12, spaceAfter=5),
        "txt": ParagraphStyle("txt", parent=base["Normal"], fontSize=10, leading=14, textColor=INK),
        "peq": ParagraphStyle("peq", parent=base["Normal"], fontSize=8.5, leading=11.5, textColor=GREY),
        "cel": ParagraphStyle("cel", parent=base["Normal"], fontSize=9.5, leading=12.5, textColor=INK),
        "celb": ParagraphStyle("celb", parent=base["Normal"], fontName="Helvetica-Bold", fontSize=9.5, leading=12.5, textColor=INK),
        "vineta": ParagraphStyle("vineta", parent=base["Normal"], fontSize=10, leading=14, leftIndent=12, bulletIndent=0, textColor=INK),
    }


def _barra(pct, color, ancho=170, alto=11):
    d = Drawing(ancho, alto)
    d.add(Rect(0, 0, ancho, alto, rx=5, ry=5, fillColor=colors.HexColor("#e3e6fb"), strokeColor=None))
    if pct and pct > 0:
        d.add(Rect(0, 0, max(ancho * pct / 100.0, 8), alto, rx=5, ry=5, fillColor=color, strokeColor=None))
    return d


def _pie(canvas, doc):
    canvas.saveState()
    canvas.setFont("Helvetica", 8)
    canvas.setFillColor(GREY)
    canvas.drawString(2 * cm, 1.2 * cm, "Constelación · Orientación pedagógica: no es diagnóstico, calificación ni etiqueta.")
    canvas.drawRightString(letter[0] - 2 * cm, 1.2 * cm, f"Página {doc.page}")
    canvas.restoreState()


def _lista(items, est):
    return [Paragraph(t, est["vineta"], bulletText="•") for t in items]


def _cabecera(est, ancho, titulo, subtitulo):
    cab = Table([[Paragraph(titulo, est["titulo"])], [Paragraph(subtitulo, est["sub"])]], colWidths=[ancho])
    cab.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, -1), NAVY), ("TOPPADDING", (0, 0), (0, 0), 16),
                             ("BOTTOMPADDING", (0, -1), (-1, -1), 14), ("LINEBELOW", (0, -1), (-1, -1), 4, GOLD)]))
    return cab


def _datos_tabla(est, ancho, filas):
    t = Table(filas, colWidths=[2.3 * cm, ancho / 2 - 2.3 * cm, 2.3 * cm, ancho / 2 - 2.3 * cm])
    t.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, -1), LIGHT), ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                           ("INNERGRID", (0, 0), (-1, -1), 0.4, colors.white),
                           ("TOPPADDING", (0, 0), (-1, -1), 5), ("BOTTOMPADDING", (0, 0), (-1, -1), 5)]))
    return t


# ------------------------------------------------------------------ Octágono
def octagono(valores_juego, valores_auto, tam=330, titulo_leyenda=True, etiquetas_valor=True):
    """Dibuja el octágono de habilidades.
    valores_juego / valores_auto: dict {habilidad_id: 0-100 o None}.
    Capa sólida = minijuegos (o perfil); capa punteada = autopercepción del test."""
    ancho = tam + 120
    alto = tam + 30 + (18 if titulo_leyenda else 0)
    d = Drawing(ancho, alto)
    cx, cy, R = ancho / 2, (alto - (18 if titulo_leyenda else 0)) / 2 + (0), tam / 2 - 30
    n = len(K.HABILIDADES)

    def punto(i, radio):
        ang = math.pi / 2 - 2 * math.pi * i / n  # empieza arriba, sentido de las manecillas
        return cx + radio * math.cos(ang), cy + radio * math.sin(ang)

    for frac, grosor in ((0.25, 0.4), (0.5, 0.4), (0.75, 0.4), (1.0, 1.0)):
        pts = [c for i in range(n) for c in punto(i, R * frac)]
        d.add(Polygon(pts, fillColor=colors.HexColor("#f6f7ff") if frac == 1.0 else None,
                      strokeColor=colors.HexColor("#b9bfe8"), strokeWidth=grosor))
    for i in range(n):
        x, y = punto(i, R)
        d.add(Line(cx, cy, x, y, strokeColor=colors.HexColor("#d5d9f5"), strokeWidth=0.5))
    # Etiquetas de anillos
    for frac, txt in ((0.5, "50"), (1.0, "100")):
        d.add(String(cx + 3, cy + R * frac + 2, txt, fontName="Helvetica", fontSize=6.5, fillColor=GREY))

    def capa(valores, relleno, borde, grosor, punteado=False):
        pts, validos = [], 0
        for i, h in enumerate(K.HABILIDADES):
            v = valores.get(h["id"])
            if v is None:
                v = 0
            else:
                validos += 1
            pts += list(punto(i, R * max(v, 3) / 100.0))
        if validos == 0:
            return
        p = Polygon(pts, fillColor=relleno, strokeColor=borde, strokeWidth=grosor)
        if punteado:
            p.strokeDashArray = [4, 3]
        d.add(p)

    capa(valores_auto, None, colors.HexColor("#6b7280"), 1.3, punteado=True)
    capa(valores_juego, colors.Color(0.36, 0.36, 0.9, alpha=0.22), colors.HexColor("#4338ca"), 1.8)
    for i, h in enumerate(K.HABILIDADES):
        col = colors.HexColor(h["color_pdf"])
        vj, va = valores_juego.get(h["id"]), valores_auto.get(h["id"])
        v = vj if vj is not None else va
        if v is not None:
            x, y = punto(i, R * max(v, 3) / 100.0)
            d.add(Circle(x, y, 4.5, fillColor=col if vj is not None else colors.white, strokeColor=col, strokeWidth=2))
        # Etiqueta externa
        lx, ly = punto(i, R + 20)
        ancla = "middle" if abs(lx - cx) < 8 else ("start" if lx > cx else "end")
        d.add(String(lx, ly + 2, h["corto"] if h["id"] != "autoconocimiento" else "Autoconocimiento",
                     fontName="Helvetica-Bold", fontSize=8.5, fillColor=col, textAnchor=ancla))
        if etiquetas_valor and v is not None:
            d.add(String(lx, ly - 8, f"{v}%" + ("" if vj is not None else " (test)"), fontName="Helvetica", fontSize=7.5,
                         fillColor=GREY, textAnchor=ancla))
    if titulo_leyenda:
        y = 6
        d.add(Polygon([cx - 150, y + 1, cx - 130, y + 1, cx - 130, y + 9, cx - 150, y + 9], fillColor=colors.Color(0.36, 0.36, 0.9, alpha=0.22),
                      strokeColor=colors.HexColor("#4338ca"), strokeWidth=1.2))
        d.add(String(cx - 125, y + 2, "Minijuegos (lo observado)", fontName="Helvetica", fontSize=7.5, fillColor=GREY))
        ln = Line(cx + 20, y + 5, cx + 42, y + 5, strokeColor=colors.HexColor("#6b7280"), strokeWidth=1.3)
        ln.strokeDashArray = [4, 3]
        d.add(ln)
        d.add(String(cx + 47, y + 2, "Test (lo que dice el alumno)", fontName="Helvetica", fontSize=7.5, fillColor=GREY))
    return d


def _fecha_hoy():
    return datetime.now().strftime("%d/%m/%Y")


# ------------------------------------------------------------------ PDF del alumno
def generar_pdf_alumno(alumno, clase, docente, perfil, partidas, asignaciones, fecha=None):
    est = _estilos()
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=letter, leftMargin=2 * cm, rightMargin=2 * cm, topMargin=1.6 * cm,
                            bottomMargin=2 * cm, title=f"Perfil de {alumno['nombre']}", author="Constelación")
    ancho = letter[0] - 4 * cm
    hist = [_cabecera(est, ancho, "Perfil de fortalezas", "Octágono de habilidades · Intereses · Forma de aprender"), Spacer(1, 12)]

    fecha = fecha or _fecha_hoy()
    grupo = K.nombre_grupo(clase["nivel"], clase["grado"])
    hist.append(_datos_tabla(est, ancho, [
        [Paragraph("Alumno(a)", est["celb"]), Paragraph(alumno["nombre"], est["cel"]),
         Paragraph("Clase", est["celb"]), Paragraph(f"{clase['nombre']} · {grupo}", est["cel"])],
        [Paragraph("Edad", est["celb"]), Paragraph(f"{alumno['edad']} años" if alumno.get("edad") else "—", est["cel"]),
         Paragraph("Matrícula", est["celb"]), Paragraph(str(alumno.get("matricula") or "—"), est["cel"])],
        [Paragraph("Docente", est["celb"]), Paragraph(docente["nombre"], est["cel"]),
         Paragraph("Escuela", est["celb"]), Paragraph(docente["escuela"], est["cel"])],
        [Paragraph("Test", est["celb"]), Paragraph(fecha, est["cel"]),
         Paragraph("Minijuegos", est["celb"]), Paragraph(f"{perfil['juegos_hechos']} de {perfil['juegos_total']} jugados", est["cel"])],
    ]))

    hab = {h["id"]: h for h in perfil["habilidades"]}
    vj = {h["id"]: h["juego"] for h in perfil["habilidades"]}
    va = {h["id"]: h["auto"] for h in perfil["habilidades"]}

    # Resumen
    hist.append(Paragraph("Resumen", est["h2"]))
    nombre = alumno["nombre"].split()[0]
    partes = []
    if perfil["destacadas"]:
        nombres = ", ".join(K.NOMBRE_HAB[i].lower() for i in perfil["destacadas"])
        base = "mostró" if any(not hab[i]["provisional"] for i in perfil["destacadas"]) else "dice sentirse fuerte en"
        partes.append(f"<b>{nombre}</b> {base}: <b>{nombres}</b>.")
    else:
        partes.append(f"Con los resultados disponibles aún no se identifican habilidades en nivel alto para <b>{nombre}</b>; "
                      "conviene observarle en otras situaciones y aplicar más minijuegos.")
    if perfil["estilo"]:
        e = perfil["estilo"]
        canal = K.CANALES[e["principal"]].lower()
        if e["equilibrado"]:
            partes.append("Su forma de aprender es <b>equilibrada</b> entre los tres canales.")
        else:
            partes.append(f"Su canal de aprendizaje preferido es <b>{canal}</b>"
                          + (f", con apoyo <b>{K.CANALES[e['secundario']].lower()}</b>." if e["secundario"] else "."))
    if perfil["intereses"]:
        partes.append("Le interesan: " + ", ".join(K.NOMBRE_INT[i].lower() for i in perfil["intereses"]) + ".")
    hist.append(Paragraph(" ".join(partes), est["txt"]))

    # Octágono
    hist.append(Paragraph("Octágono de habilidades", est["h2"]))
    hist.append(octagono(vj, va, tam=300))
    hist.append(Paragraph(
        "El octágono muestra 8 habilidades de 0 a 100. La capa sólida resume lo observado en los minijuegos; la línea "
        "punteada, lo que el alumno dice de sí mismo en el test. Un punto hueco indica que aún no se juega ese minijuego "
        "(dato provisional). Cada habilidad se estima con pocos reactivos: es una señal inicial, no una medida exacta.", est["peq"]))

    # Tabla de habilidades
    filas = [[Paragraph("<b>Habilidad</b>", est["cel"]), Paragraph("<b>Nivel</b>", est["cel"]),
              Paragraph("<b>Juego</b>", est["cel"]), Paragraph("<b>Test</b>", est["cel"]), ""]]
    for h in perfil["habilidades"]:
        col = colors.HexColor(K.HAB[h["id"]]["color_pdf"])
        nivel = h["nivel"] or "Sin datos"
        if h["provisional"]:
            nivel += " (test)"
        filas.append([Paragraph(f"<font color='{K.HAB[h['id']]['color_pdf']}'>●</font> {h['nombre']}", est["cel"]),
                      Paragraph(nivel, est["cel"]),
                      Paragraph(f"{h['juego']}%" if h["juego"] is not None else "—", est["cel"]),
                      Paragraph(f"{h['auto']}%" if h["auto"] is not None else "—", est["cel"]),
                      _barra(h["valor"], col, ancho=110) if h["valor"] is not None else ""])
    th = Table(filas, colWidths=[5 * cm, 3.4 * cm, 1.7 * cm, 1.7 * cm, ancho - 11.8 * cm], repeatRows=1)
    th.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), LIGHT), ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                            ("LINEBELOW", (0, 0), (-1, -1), 0.3, colors.HexColor("#d5d9f5")),
                            ("TOPPADDING", (0, 0), (-1, -1), 3.5), ("BOTTOMPADDING", (0, 0), (-1, -1), 3.5)]))
    hist += [Spacer(1, 6), th, Spacer(1, 3),
             Paragraph("Destaca: 75% o más · En desarrollo: 50% a 74% · Para impulsar: menos de 50%. "
                       "«(test)» = nivel provisional basado solo en la autopercepción.", est["peq"])]

    hist.append(PageBreak())

    # Fortalezas / por impulsar
    bf = [Paragraph("Habilidades que destacan", est["h2"])]
    if perfil["destacadas"]:
        bf += _lista([f"<b>{K.NOMBRE_HAB[i]}</b>: {K.TIPS_DESTACA[i]}" for i in perfil["destacadas"]], est)
    else:
        bf.append(Paragraph("Aún no hay habilidades en nivel alto. Esto no significa que no existan: puede repetirse en otro "
                            "momento o con más apoyo.", est["txt"]))
    hist.append(KeepTogether(bf))
    bd = [Paragraph("Habilidades para impulsar", est["h2"])]
    if perfil["impulsar"]:
        bd += _lista([f"<b>{K.NOMBRE_HAB[i]}</b>: {K.TIPS_IMPULSAR[i]}" for i in perfil["impulsar"]], est)
    else:
        bd.append(Paragraph("Ninguna habilidad quedó por debajo del 75% con los datos disponibles.", est["txt"]))
    hist.append(KeepTogether(bd))

    # Estilo de aprendizaje
    if perfil["estilo"]:
        e = perfil["estilo"]
        be = [Paragraph("Forma de aprender (test de estilos, modelo PNL simplificado)", est["h2"])]
        filas = [[Paragraph(K.CANALES[c], est["cel"]),
                  Paragraph(f"{e['conteo'][c]} de {e['total']} respuestas ({e['porcentajes'][c]}%)", est["cel"]),
                  _barra(e["porcentajes"][c], COLOR_CANAL[c], ancho=150)] for c in "VAK"]
        te = Table(filas, colWidths=[3 * cm, 5.8 * cm, ancho - 8.8 * cm])
        te.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                                ("LINEBELOW", (0, 0), (-1, -1), 0.3, colors.HexColor("#d5d9f5")),
                                ("TOPPADDING", (0, 0), (-1, -1), 4), ("BOTTOMPADDING", (0, 0), (-1, -1), 4)]))
        be += [te, Spacer(1, 5)]
        if e["equilibrado"]:
            be.append(Paragraph("<b>Perfil equilibrado.</b> Se beneficia de combinar canales: ver, escuchar y hacer.", est["txt"]))
        else:
            be.append(Paragraph(f"<b>Preferencia {K.CANALES[e['principal']].lower()}.</b> {K.DESCRIPCION_ESTILO[e['principal']]} "
                                f"<i>Idea:</i> {K.IDEAS_ESTILO[e['principal']]}", est["txt"]))
            if e["secundario"]:
                be.append(Spacer(1, 3))
                be.append(Paragraph(f"<b>Apoyo {K.CANALES[e['secundario']].lower()}.</b> {K.DESCRIPCION_ESTILO[e['secundario']]}", est["txt"]))
        be.append(Paragraph("Son preferencias declaradas, no capacidades fijas; sirven para variar cómo se presenta la información.", est["peq"]))
        hist.append(KeepTogether(be))

    # Intereses
    if perfil["intereses"]:
        bi = [Paragraph("Intereses", est["h2"])]
        bi += _lista([f"<b>{K.NOMBRE_INT[i]}</b>: se pueden aprovechar con {K.TIPS_INTERES[i]}." for i in perfil["intereses"]], est)
        hist.append(KeepTogether(bi))

    # En sus propias palabras (Taller de ideas + Mi espejo)
    voz = []
    ideas = partidas.get("ideas")
    if ideas:
        for r in ideas["detalle"].get("rondas", []):
            if r["ideas"]:
                voz.append(f"<b>{r['objeto'].capitalize()}:</b> " + "; ".join(r["ideas"]))
    esp = partidas.get("espejo")
    if esp:
        d = esp["detalle"]
        if d.get("fortalezas"):
            voz.append("<b>Dice que lo que mejor hace:</b> " + ", ".join(K.NOMBRE_HAB[i].lower() for i in d["fortalezas"]) + ".")
        if d.get("mejorar"):
            voz.append("<b>Quiere mejorar en:</b> " + K.NOMBRE_HAB[d["mejorar"]].lower() + ".")
        if d.get("apoyo"):
            voz.append("<b>Algo que le ayuda a aprender:</b> «" + _esc(d["apoyo"]) + "»")
    if voz:
        bv = [Paragraph("En sus propias palabras", est["h2"])] + _lista(voz, est)
        bv.append(Paragraph("Las ideas se muestran tal como las escribió el alumno; el docente decide qué valor darles.", est["peq"]))
        hist.append(KeepTogether(bv))

    # Minijuegos jugados
    if partidas or any(e == "pendiente" for e in asignaciones.values()):
        bj = [Paragraph("Minijuegos", est["h2"])]
        filas = [[Paragraph("<b>Minijuego</b>", est["cel"]), Paragraph("<b>Habilidad</b>", est["cel"]), Paragraph("<b>Estado</b>", est["cel"])]]
        for j in J.CATALOGO:
            if j["id"] in partidas:
                est_j = f"Jugado ({partidas[j['id']]['puntaje']}%)"
            elif asignaciones.get(j["id"]) == "pendiente":
                est_j = "Asignado, pendiente"
            else:
                continue
            filas.append([Paragraph(j["titulo"], est["cel"]), Paragraph(j["habilidad_nombre"], est["cel"]), Paragraph(est_j, est["cel"])])
        tj = Table(filas, colWidths=[5.5 * cm, 5.5 * cm, ancho - 11 * cm])
        tj.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), LIGHT), ("LINEBELOW", (0, 0), (-1, -1), 0.3, colors.HexColor("#d5d9f5")),
                                ("TOPPADDING", (0, 0), (-1, -1), 3.5), ("BOTTOMPADDING", (0, 0), (-1, -1), 3.5)]))
        bj.append(tj)
        hist.append(KeepTogether(bj))

    # Observaciones del docente
    notas = (alumno.get("notas_docente") or "").strip()
    if notas:
        hist.append(KeepTogether([Paragraph("Observaciones del docente", est["h2"]), Paragraph(_esc(notas).replace("\n", "<br/>"), est["txt"])]))

    hist.append(Spacer(1, 10))
    hist.append(_nota(est, ancho))
    doc.build(hist, onFirstPage=_pie, onLaterPages=_pie)
    return buf.getvalue()


def _esc(t):
    return str(t).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def _nota(est, ancho):
    nota = Table([[Paragraph(
        "<b>Nota para el docente.</b> Este reporte es orientación para planear actividades; no es un diagnóstico, una calificación "
        "ni sirve para clasificar, comparar o tomar decisiones automáticas sobre el alumnado. Los resultados dependen del día y del "
        "contexto y deben contrastarse con su observación directa. Test de estilos adaptado de «Test estilo de aprendizaje (modelo PNL)», "
        "SEV (De la Parra Paz, E., <i>Herencia de vida para tus hijos</i>, Grijalbo, 2004).", est["peq"])]], colWidths=[ancho])
    nota.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, -1), LIGHT), ("BOX", (0, 0), (-1, -1), 0.6, LAVENDER),
                              ("LEFTPADDING", (0, 0), (-1, -1), 9), ("RIGHTPADDING", (0, 0), (-1, -1), 9),
                              ("TOPPADDING", (0, 0), (-1, -1), 7), ("BOTTOMPADDING", (0, 0), (-1, -1), 7)]))
    return nota


# ------------------------------------------------------------------ PDF de la clase
def generar_pdf_clase(clase, docente, resumen, alumnos_res, perfiles):
    est = _estilos()
    buf = io.BytesIO()
    grupo = K.nombre_grupo(clase["nivel"], clase["grado"])
    doc = SimpleDocTemplate(buf, pagesize=letter, leftMargin=2 * cm, rightMargin=2 * cm, topMargin=1.6 * cm,
                            bottomMargin=2 * cm, title=f"Perfil de la clase {clase['nombre']}", author="Constelación")
    ancho = letter[0] - 4 * cm
    hist = [_cabecera(est, ancho, "Perfil de la clase", "Octágono grupal · Estilos de aprendizaje · Intereses"), Spacer(1, 12)]
    hist.append(_datos_tabla(est, ancho, [
        [Paragraph("Clase", est["celb"]), Paragraph(f"{clase['nombre']} · {grupo}", est["cel"]),
         Paragraph("Fecha", est["celb"]), Paragraph(_fecha_hoy(), est["cel"])],
        [Paragraph("Docente", est["celb"]), Paragraph(docente["nombre"], est["cel"]),
         Paragraph("Escuela", est["celb"]), Paragraph(docente["escuela"], est["cel"])],
        [Paragraph("Alumnos", est["celb"]), Paragraph(str(resumen["alumnos"]), est["cel"]),
         Paragraph("Con test", est["celb"]), Paragraph(f"{resumen['con_test']} · con minijuegos: {resumen['con_juegos']}", est["cel"])],
    ]))

    hab = {h["id"]: h for h in resumen["habilidades"]}
    hist.append(Paragraph("Habilidades que destacan en la clase", est["h2"]))
    if resumen["destacadas"]:
        txt = "; ".join(f"<b>{K.NOMBRE_HAB[i]}</b> (promedio {hab[i]['valor']}%, {hab[i]['destacan']} de {hab[i]['n']} alumnos destacan)"
                        for i in resumen["destacadas"])
        hist.append(Paragraph(f"En promedio, el grupo muestra más fuerza en: {txt}.", est["txt"]))
    else:
        hist.append(Paragraph("Todavía no hay datos suficientes para identificar habilidades de la clase.", est["txt"]))
    hist.append(octagono({i: h["juego"] for i, h in hab.items()}, {i: h["auto"] for i, h in hab.items()}, tam=300))
    hist.append(Paragraph("Promedio del grupo por habilidad. Capa sólida: minijuegos (solo alumnos que ya jugaron); línea punteada: test. "
                          "Es una vista del grupo; no sirve para comparar alumnos.", est["peq"]))

    filas = [[Paragraph("<b>Habilidad</b>", est["cel"]), Paragraph("<b>Promedio</b>", est["cel"]),
              Paragraph("<b>Destacan</b>", est["cel"]), Paragraph("<b>Con minijuego</b>", est["cel"]), ""]]
    for h in K.HABILIDADES:
        x = hab[h["id"]]
        filas.append([Paragraph(f"<font color='{h['color_pdf']}'>●</font> {h['nombre']}", est["cel"]),
                      Paragraph(f"{x['valor']}%" if x["valor"] is not None else "—", est["cel"]),
                      Paragraph(f"{x['destacan']} de {x['n']}", est["cel"]),
                      Paragraph(f"{x['n_juego']}", est["cel"]),
                      _barra(x["valor"], colors.HexColor(h["color_pdf"]), ancho=110) if x["valor"] is not None else ""])
    th = Table(filas, colWidths=[5.2 * cm, 2.4 * cm, 2.6 * cm, 2.8 * cm, ancho - 13 * cm], repeatRows=1)
    th.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), LIGHT), ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                            ("LINEBELOW", (0, 0), (-1, -1), 0.3, colors.HexColor("#d5d9f5")),
                            ("TOPPADDING", (0, 0), (-1, -1), 3.5), ("BOTTOMPADDING", (0, 0), (-1, -1), 3.5)]))
    hist += [Spacer(1, 4), th]
    hist.append(PageBreak())

    # Estilos
    be = [Paragraph("Formas de aprender en la clase", est["h2"])]
    total = sum(resumen["estilos"].values()) or 1
    filas = [[Paragraph(K.CANALES[c], est["cel"]), Paragraph(f"{resumen['estilos'][c]} alumnos ({round(100 * resumen['estilos'][c] / total)}%)", est["cel"]),
              _barra(round(100 * resumen["estilos"][c] / total), COLOR_CANAL[c], ancho=150)] for c in "VAK"]
    te = Table(filas, colWidths=[3 * cm, 5.8 * cm, ancho - 8.8 * cm])
    te.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "MIDDLE"), ("LINEBELOW", (0, 0), (-1, -1), 0.3, colors.HexColor("#d5d9f5")),
                            ("TOPPADDING", (0, 0), (-1, -1), 4), ("BOTTOMPADDING", (0, 0), (-1, -1), 4)]))
    be.append(te)
    if resumen["con_test"]:
        pred = max("VAK", key=lambda c: resumen["estilos"][c])
        be.append(Spacer(1, 4))
        be.append(Paragraph(f"Predomina el canal <b>{K.CANALES[pred].lower()}</b>. <i>Idea para la clase:</i> {K.IDEAS_ESTILO[pred]} "
                            "Como la clase mezcla canales, conviene combinar formas de presentar la información.", est["txt"]))
    hist.append(KeepTogether(be))

    # Intereses
    if resumen["intereses"]:
        bi = [Paragraph("Intereses más frecuentes", est["h2"])]
        bi += _lista([f"<b>{K.NOMBRE_INT[i['id']]}</b> ({i['n']} alumnos): {K.TIPS_INTERES[i['id']]}." for i in resumen["intereses"][:4]], est)
        hist.append(KeepTogether(bi))

    # Sugerencias
    bs = [Paragraph("Ideas para planear", est["h2"])]
    sug = []
    for i in resumen["destacadas"][:2]:
        sug.append(f"Aprovechar <b>{K.NOMBRE_HAB[i].lower()}</b> como punto fuerte: {K.TIPS_DESTACA[i]}")
    bajos = sorted([h for h in resumen["habilidades"] if h["valor"] is not None], key=lambda h: h["valor"])[:2]
    for h in bajos:
        if h["id"] not in resumen["destacadas"]:
            sug.append(f"Dar más práctica en <b>{K.NOMBRE_HAB[h['id']].lower()}</b>: {K.TIPS_IMPULSAR[h['id']]}")
    if sug:
        bs += _lista(sug, est)
        hist.append(KeepTogether(bs))

    # Tabla de alumnos (orden alfabético; sin ranking)
    hist.append(Paragraph("Alumnos (orden alfabético)", est["h2"]))
    filas = [[Paragraph("<b>Alumno(a)</b>", est["cel"]), Paragraph("<b>Canal</b>", est["cel"]),
              Paragraph("<b>Habilidades que destacan</b>", est["cel"]), Paragraph("<b>Juegos</b>", est["cel"])]]
    for r in alumnos_res:
        top = ", ".join(K.HAB[i]["corto"] for i in r["destacadas"][:2]) or "—"
        filas.append([Paragraph(_esc(r["nombre"]), est["cel"]),
                      Paragraph(K.CANALES[r["estilo"]] if r["estilo"] else "Sin test", est["cel"]),
                      Paragraph(top if r["test"] or r["juegos_hechos"] else "Sin datos", est["cel"]),
                      Paragraph(f"{r['juegos_hechos']}/{r['juegos_total']}", est["cel"])])
    ta = Table(filas, colWidths=[6 * cm, 2.6 * cm, ancho - 10.4 * cm, 1.8 * cm], repeatRows=1)
    ta.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), LIGHT), ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                            ("LINEBELOW", (0, 0), (-1, -1), 0.3, colors.HexColor("#d5d9f5")),
                            ("TOPPADDING", (0, 0), (-1, -1), 3.5), ("BOTTOMPADDING", (0, 0), (-1, -1), 3.5)]))
    hist.append(ta)
    hist.append(Spacer(1, 10))
    hist.append(_nota(est, ancho))
    doc.build(hist, onFirstPage=_pie, onLaterPages=_pie)
    return buf.getvalue()
