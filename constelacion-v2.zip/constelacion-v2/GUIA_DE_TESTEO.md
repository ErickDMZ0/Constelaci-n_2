# Guía de testeo del prototipo

## 1. Preparación (15 min)
Arranca la app (ver README), carga la demo y prepara 1 dispositivo por docente (tableta u ordenador) y, para estudiantes, el dispositivo del docente por turnos.

## 2. Lista de verificación funcional (docente)
- [ ] Registro e inicio de sesión; cerrar sesión.
- [ ] Crear clase (Primaria 5.º/6.º, Secundaria 1.º–3.º); crear 2 clases.
- [ ] Agregar estudiantes uno a uno y en lote; editar y eliminar.
- [ ] Aplicar test (12 preguntas VAK + autopercepción + intereses).
- [ ] Asignar minijuegos (individual, a la clase, los 8).
- [ ] Jugar los 8 minijuegos; ver detalle de partida.
- [ ] Octágono del estudiante (con "Comparar con el test") y de la clase.
- [ ] PDF de estudiante, PDF de clase, ZIP de la clase y ZIP global se descargan y se leen bien.
- [ ] Notas del docente se guardan.

## 3. Accesibilidad e inclusión
- [ ] Solo teclado: Tab/Enter/Espacio; Torres con teclas 1, 2, 3.
- [ ] Voz (lectura en voz alta), texto grande, alto contraste, espaciado, sin animaciones.
- [ ] Ninguna información depende solo del color; no hay cronómetros.
- [ ] Lector de pantalla (NVDA/VoiceOver/TalkBack) en test y un minijuego.
- [ ] Móvil y tableta: legible, sin scroll horizontal; conexión lenta.

## 4. Protocolo de piloto en aula (2–3 sesiones de 30–40 min)
1. Con 1–2 docentes y un grupo de 10–15 estudiantes (consentimiento de familias y asentimiento del alumnado; alias en lugar de nombres).
2. Sesión 1: test. Sesión 2: 2–4 minijuegos. Sesión 3: revisión del perfil con el docente.
3. Observa: dudas de comprensión, abandonos, frustración, tiempo por actividad.
4. Cierre: cuestionario breve al docente (escala 1–5): claridad, utilidad pedagógica, tiempo ahorrado, confianza, riesgo de etiquetar; y 2 preguntas abiertas.
5. Triangula: ¿el perfil coincide con la observación del docente? Los desacuerdos son el dato más valioso.

## 5. Criterios de éxito sugeridos
- ≥80 % de estudiantes completan el test sin ayuda; ≥80 % completan cada minijuego.
- Docentes valoran utilidad ≥4/5 y nadie usa el perfil como calificación.
- 0 incidencias de accesibilidad bloqueantes.

## 6. Registro de incidencias
Tabla: fecha · quién · dispositivo · qué ocurrió · gravedad · captura.
