# Constelación v2 · Prototipo testeable (ProFuturo RETO 20)

Web para docentes de Primaria (5.º–6.º) y Secundaria (1.º–3.º): clases, estudiantes, test de estilo de aprendizaje simplificado (VAK + autopercepción), 8 minijuegos (uno por habilidad), octágono de habilidades por estudiante y por clase, y PDF por estudiante, por clase y ZIP.
No etiqueta ni decide sobre el alumnado: ofrece orientación pedagógica.

## Arranque rápido (SQLite, sin instalar base de datos)
```bash
python3 -m venv venv && source venv/bin/activate      # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env                                   # Windows: copy .env.example .env
python seed_demo.py                                    # datos de demostración (opcional)
python app.py                                          # abre http://127.0.0.1:5055
```
Docente demo: `demo@constelacion.test` / `Demo2026!` (clases "5.º A" y "2.º B", datos simulados).
`python seed_demo.py --borrar` elimina los datos demo.

## MySQL / MariaDB (opcional)
En `.env`: `DB_ENGINE=mysql` y credenciales; luego `python init_db.py` (crea la base `constelacion_v2`). **Esta ruta no se probó en el entorno de desarrollo**; pruébala antes del piloto.

## Pruebas automáticas
- `python test_flujo.py`: API, puntuación, privacidad, PDF y ZIP.
- `python test_e2e_navegador.py` (requiere `pip install playwright && playwright install chromium` y el servidor en marcha en el puerto 5055): recorre registro, clase, test y los 8 minijuegos y descarga PDFs.

## Estructura
`app.py` API Flask · `catalogo.py` habilidades y textos · `cuestionario.py` test · `juegos.py` minijuegos y corrección en servidor · `perfil.py` perfiles y resumen de clase · `report.py` PDF · `db.py`/`schema.sql` datos · `static/` interfaz (HTML/CSS/JS sin dependencias externas).

## Cómo se calcula (resumen)
- Valor de una habilidad = resultado del minijuego; si no se ha jugado, la autopercepción del test (marcada como provisional).
- Destacadas: las 3 más altas con ≥50. Para impulsar: las 2 más bajas (<75). No hay nota global ni ranking.
- Las respuestas correctas nunca viajan al navegador; se corrigen en el servidor.

## Privacidad y seguridad
- No subas `.env` ni `.secret_key` a ningún repositorio ni los compartas. Genera una clave nueva por despliegue.
- Almacena solo lo imprescindible (nombre o alias, curso). Para el piloto usa alias o iniciales.
- En producción: HTTPS, `COOKIE_SECURE=1`, copias de seguridad cifradas, consentimiento informado de familias.

## Limitaciones conocidas
- Los estudiantes juegan en el dispositivo del docente (el acceso propio del alumnado es fase 2).
- Creatividad (fluidez de ideas) y Cambio de reglas son estimaciones iniciales; requieren validación con grupos reales.
- Es un instrumento de orientación, no psicométrico validado.
