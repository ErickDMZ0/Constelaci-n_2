# -*- coding: utf-8 -*-
"""Acceso a base de datos.

Por defecto usa SQLite (un solo archivo, cero instalación): ideal para pruebas y pilotos pequeños.
Para producción con más usuarios: DB_ENGINE=mysql (MySQL / MariaDB con PyMySQL) y ejecutar schema.sql.
Las consultas se escriben con marcadores %s; para SQLite se convierten a '?'.
"""
import os
import sqlite3
from datetime import date, datetime

from flask import g

ENGINE = os.getenv("DB_ENGINE", "sqlite").lower()
SQLITE_PATH = os.getenv("SQLITE_PATH", os.path.join(os.path.dirname(os.path.abspath(__file__)), "constelacion.sqlite3"))

SQLITE_SCHEMA = """
CREATE TABLE IF NOT EXISTS docentes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  nombre TEXT NOT NULL,
  correo TEXT NOT NULL UNIQUE,
  escuela TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  creado_en TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS clases (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  docente_id INTEGER NOT NULL REFERENCES docentes(id) ON DELETE CASCADE,
  nombre TEXT NOT NULL,
  nivel TEXT NOT NULL CHECK (nivel IN ('primaria','secundaria')),
  grado INTEGER NOT NULL,
  ciclo TEXT,
  creado_en TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS alumnos (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  docente_id INTEGER NOT NULL REFERENCES docentes(id) ON DELETE CASCADE,
  clase_id INTEGER NOT NULL REFERENCES clases(id) ON DELETE CASCADE,
  nombre TEXT NOT NULL,
  edad INTEGER,
  genero TEXT,
  matricula TEXT,
  consentimiento INTEGER NOT NULL DEFAULT 0,
  accesibilidad_json TEXT,
  notas_docente TEXT,
  creado_en TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE (clase_id, matricula)
);
CREATE TABLE IF NOT EXISTS evaluaciones (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  alumno_id INTEGER NOT NULL REFERENCES alumnos(id) ON DELETE CASCADE,
  estado TEXT NOT NULL DEFAULT 'en_curso' CHECK (estado IN ('en_curso','completada')),
  resultado_json TEXT,
  creado_en TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  completada_en TEXT
);
CREATE TABLE IF NOT EXISTS asignaciones (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  alumno_id INTEGER NOT NULL REFERENCES alumnos(id) ON DELETE CASCADE,
  juego_id TEXT NOT NULL,
  estado TEXT NOT NULL DEFAULT 'pendiente' CHECK (estado IN ('pendiente','completada')),
  asignada_en TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  completada_en TEXT,
  UNIQUE (alumno_id, juego_id)
);
CREATE TABLE IF NOT EXISTS partidas (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  alumno_id INTEGER NOT NULL REFERENCES alumnos(id) ON DELETE CASCADE,
  juego_id TEXT NOT NULL,
  puntaje INTEGER NOT NULL,
  detalle_json TEXT,
  creada_en TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_partidas_alumno ON partidas (alumno_id, juego_id);
CREATE INDEX IF NOT EXISTS idx_alumnos_clase ON alumnos (clase_id);
CREATE INDEX IF NOT EXISTS idx_clases_docente ON clases (docente_id);
"""


def _conectar():
    if ENGINE == "sqlite":
        conn = sqlite3.connect(SQLITE_PATH, timeout=15)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        conn.execute("PRAGMA journal_mode = WAL")
        conn.executescript(SQLITE_SCHEMA)
        return conn
    import pymysql
    return pymysql.connect(
        host=os.getenv("DB_HOST", "127.0.0.1"),
        port=int(os.getenv("DB_PORT", "3306")),
        user=os.getenv("DB_USER", "constelacion"),
        password=os.getenv("DB_PASSWORD", ""),
        database=os.getenv("DB_NAME", "constelacion"),
        charset="utf8mb4",
        cursorclass=pymysql.cursors.DictCursor,
        autocommit=False,
    )


def conexion():
    if "db" not in g:
        g.db = _conectar()
    return g.db


def cerrar(_exc=None):
    conn = g.pop("db", None)
    if conn is not None:
        conn.close()


def _sql(sql):
    return sql.replace("%s", "?") if ENGINE == "sqlite" else sql


def _limpia(fila):
    if fila is None:
        return None
    fila = dict(fila)
    for k, v in fila.items():
        if isinstance(v, (datetime, date)):
            fila[k] = v.isoformat(sep=" ") if isinstance(v, datetime) else v.isoformat()
    return fila


def consulta(sql, params=(), uno=False):
    cur = conexion().cursor()
    cur.execute(_sql(sql), params)
    filas = cur.fetchall()
    cur.close()
    filas = [_limpia(f) for f in filas]
    if uno:
        return filas[0] if filas else None
    return filas


def ejecutar(sql, params=()):
    """Ejecuta INSERT/UPDATE/DELETE, confirma y devuelve el último id insertado."""
    conn = conexion()
    cur = conn.cursor()
    try:
        cur.execute(_sql(sql), params)
        nuevo_id = cur.lastrowid
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        cur.close()
    return nuevo_id


def ejecutar_varios(sentencias):
    """Ejecuta varias sentencias [(sql, params), ...] en una sola transacción."""
    conn = conexion()
    cur = conn.cursor()
    try:
        for sql, params in sentencias:
            cur.execute(_sql(sql), params)
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        cur.close()


def marcadores(n):
    return ",".join(["%s"] * n)
