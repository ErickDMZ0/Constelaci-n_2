import asyncio, random
from playwright.async_api import async_playwright

OUT = "/tmp/constelacion_e2e_"
BASE = "http://127.0.0.1:5055/"
rnd = random.Random(1)


async def clic_opcion(page, n=None):
    ops = page.locator("#a-esc .a-opcion:not([disabled])")
    c = await ops.count()
    await ops.nth(rnd.randrange(c) if n is None else n).click()


async def siguiente(page):
    b = page.locator("#a-esc .btn-primario:not([disabled])").last
    await b.click()


async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch()
        page = await (await b.new_context(viewport={"width": 1100, "height": 900})).new_page()
        errs = []
        page.on("console", lambda m: errs.append(m.text) if m.type == "error" and "401" not in m.text else None)
        page.on("pageerror", lambda e: errs.append(f"PAGEERROR {e}"))
        await page.goto(BASE)
        await page.fill("#form-registro input[name=nombre]", "Prueba Docente")
        await page.fill("#form-registro input[name=escuela]", "Escuela Prueba")
        await page.fill("#form-registro input[name=correo]", f"t{__import__('time').time_ns()}@x.com")
        await page.fill("#form-registro input[name=password]", "clave12345")
        await page.click("#form-registro button[type=submit]")
        await page.wait_for_selector(".clase-nueva")
        await page.click(".clase-nueva")
        await page.fill("dialog input[name=nombre]", "5.º A")
        await page.click("dialog label.opc-tarjeta:has-text('Primaria')")
        await page.locator("dialog fieldset:has(legend:text-is('Grado')) label").first.click()
        await page.click("dialog button[type=submit]")
        await page.wait_for_selector("text=Agregar estudiantes")
        await page.click("text=＋ Agregar estudiantes")
        await page.fill("dialog input[name=nombre]", "Luis Pérez Gómez")
        await page.check("dialog #cons-uno")
        await page.click("dialog .btn-primario:has-text('Guardar')")
        await page.wait_for_timeout(500)
        await page.click("dialog .btn-suave:has-text('Cerrar')")
        await page.wait_for_selector("table.tabla")
        await page.click("button:has-text('Aplicar test')")
        await page.wait_for_selector("#a-esc")
        await page.screenshot(path=OUT + "10_test_bienvenida.png")
        await siguiente(page)  # empezar
        for _ in range(12):
            await clic_opcion(page); await page.wait_for_timeout(350)
        await page.screenshot(path=OUT + "11_test_auto.png")
        for _ in range(16):
            await clic_opcion(page); await page.wait_for_timeout(350)
        await page.locator("#a-esc .a-opcion").nth(0).click()
        await page.locator("#a-esc .a-opcion").nth(3).click()
        await page.screenshot(path=OUT + "12_intereses.png")
        await siguiente(page)  # terminar
        await page.wait_for_selector("text=¡Lo lograste!")
        await siguiente(page)  # ir a misiones
        await page.wait_for_selector("text=Mis misiones")
        await page.click("#a-esc >> text=Terminar por ahora")
        await page.click("table.tabla a.nombre")
        await page.wait_for_selector(".hab-fila")
        # asignar los 8 y jugar cada uno desde el perfil
        await page.click("text=Asignar los 8")
        await page.wait_for_timeout(600)
        ids = ["ideas", "patrones", "mensaje", "equipo", "torres", "espejo", "zapatos", "reglas"]
        for k, jid in enumerate(ids):
            await page.locator(".juego-card button:has-text('Jugar ahora')").nth(k).click()
            await page.wait_for_selector("#a-esc button:has-text('¡Vamos!')")
            await page.screenshot(path=OUT + f"20_{jid}_portada.png")
            await page.click("#a-esc button:has-text('¡Vamos!')")
            await page.wait_for_timeout(200)
            if jid == "ideas":
                for r in range(3):
                    for i in range(3):
                        await page.locator("#a-esc input").nth(i).fill(f"usar para hacer cosa {i}{r}")
                    if r == 0: await page.screenshot(path=OUT + "21_ideas.png")
                    await siguiente(page)
            elif jid == "patrones":
                for r in range(6):
                    await clic_opcion(page); await siguiente(page)
            elif jid == "mensaje":
                for r in range(3):
                    if r == 0: await page.screenshot(path=OUT + "22_mensaje.png")
                    await page.locator("#a-esc .mov button:not([disabled])").first.click()
                    await siguiente(page)
                for r in range(2):
                    await clic_opcion(page); await siguiente(page)
            elif jid == "equipo":
                await siguiente(page)
                for r in range(5):
                    await clic_opcion(page)
                    if r == 0: await page.screenshot(path=OUT + "23_equipo.png")
                    await siguiente(page)
            elif jid == "torres":
                # nivel 1: 3 discos, jugar óptimo con teclas
                sol = [(0,2),(0,1),(2,1),(0,2),(1,0),(1,2),(0,2)]
                for a, c in sol:
                    await page.keyboard.press(str(a+1)); await page.keyboard.press(str(c+1))
                await page.screenshot(path=OUT + "24_torres.png")
                await siguiente(page)
                await page.click("#a-esc button:has-text('Pista')")
                await page.click("#a-esc button:has-text('Saltar este nivel')")
            elif jid == "espejo":
                for r in range(3):
                    await clic_opcion(page); await siguiente(page)
                    for q in range(3):
                        await clic_opcion(page); await siguiente(page)
                    await page.wait_for_selector("text=Compara tu predicción")
                    if r == 0: await page.screenshot(path=OUT + "25_espejo.png")
                    await siguiente(page)
                await page.locator("#a-esc .a-rejilla").first.locator(".a-opcion").nth(0).click()
                await siguiente(page)
            elif jid == "zapatos":
                for r in range(4):
                    groups = page.locator("#a-esc .a-opciones")
                    await groups.nth(0).locator(".a-opcion").nth(rnd.randrange(4)).click()
                    await groups.nth(1).locator(".a-opcion").nth(rnd.randrange(4)).click()
                    if r == 0: await page.screenshot(path=OUT + "26_zapatos.png")
                    await siguiente(page)
            elif jid == "reglas":
                for f in range(3):
                    await page.click("#a-esc button:has-text('Entendido')")
                    n = 6 if f != 1 else 8
                    for t in range(n):
                        await page.locator("#a-esc .cartas-meta button").nth(rnd.randrange(4)).click()
                        await page.wait_for_timeout(1400)
                        if f == 0 and t == 0: await page.screenshot(path=OUT + "27_reglas.png")
            await page.wait_for_selector("text=¡Misión cumplida!", timeout=15000)
            await page.click("#a-esc button:has-text('Volver a mis misiones')")
            await page.click("#a-esc button:has-text('Terminar por ahora')")
            await page.wait_for_selector(".hab-fila")
            await page.wait_for_timeout(200)
        await page.screenshot(path=OUT + "30_perfil_final.png", full_page=True)
        async with page.expect_download() as d:
            await page.click("button:has-text('📄 PDF')")
        dl = await d.value
        await dl.save_as(OUT + "alumno.pdf")
        await page.click("a:has-text('5.º A')")
        await page.wait_for_selector("svg.octa")
        async with page.expect_download() as d:
            await page.click("button:has-text('📄 PDF de la clase')")
        await (await d.value).save_as(OUT + "clase.pdf")
        print("ERRORES:", errs)
        await b.close()

asyncio.run(main())
