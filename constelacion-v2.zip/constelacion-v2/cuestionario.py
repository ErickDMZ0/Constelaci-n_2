# -*- coding: utf-8 -*-
"""Cuestionario inicial simplificado: estilo de aprendizaje (VAK / PNL), autopercepción de habilidades e intereses.

Base: «Test estilo de aprendizaje (modelo PNL)», SEV (40 preguntas). Aquí se simplificó a 12 preguntas con
lenguaje escolar (sin referencias a pareja, coche, etc.) y se complementó con 16 afirmaciones de autopercepción
(2 por habilidad). Las claves viven solo en el servidor.

IMPORTANTE (honestidad pedagógica): el estilo de aprendizaje es una PREFERENCIA declarada, no una capacidad, y la
evidencia de que enseñar "según el estilo" mejore resultados es limitada. Se usa para variar la forma de presentar
la información, no para etiquetar. La autopercepción tampoco es un puntaje objetivo.
"""
import catalogo as K

# --------------------------------------------------------------- Estilo de aprendizaje (12 preguntas)
# Cada opción lleva su canal (V, A, K). Se rotó la posición para que ningún canal quede siempre en la misma letra.
_VAK = [
    ("Cuando quieres aprender algo nuevo, ¿qué te ayuda más?",
     [("Ver un video o dibujos que lo muestren", "V"), ("Que alguien me lo explique hablando", "A"),
      ("Probarlo yo mismo con las manos", "K")]),
    ("Para recordar un número de teléfono, tú…",
     [("Lo repito en voz alta", "A"), ("Lo escribo o lo marco con los dedos varias veces", "K"),
      ("Me imagino cómo se ve escrito", "V")]),
    ("En el salón, ¿qué es lo que más te distrae?",
     [("Estar mucho tiempo sentado sin moverme", "K"), ("Lo que pasa afuera de la ventana o en el pizarrón", "V"),
      ("Los ruidos y las voces", "A")]),
    ("¿Qué disfrutas más en tu tiempo libre?",
     [("Dibujar, ver películas o mirar fotos", "V"), ("Escuchar música o platicar", "A"),
      ("Hacer deporte, bailar o construir cosas", "K")]),
    ("Si alguien te explica cómo llegar a un lugar, prefieres…",
     [("Que te lo digan con palabras", "A"), ("Un mapa o un dibujo", "V"),
      ("Ir caminando y encontrarlo tú", "K")]),
    ("¿Cómo estudias mejor para un examen?",
     [("Con resúmenes, colores y esquemas", "V"), ("Explicándolo o repitiéndolo en voz alta", "A"),
      ("Haciendo ejemplos, juegos o ejercicios prácticos", "K")]),
    ("Cuando conversas con alguien, tú…",
     [("La escuchas con mucha atención", "A"), ("Te mueves o usas mucho las manos al hablar", "K"),
      ("La miras a los ojos y observas sus gestos", "V")]),
    ("De una persona que acabas de conocer, ¿qué recuerdas mejor?",
     [("Lo que hicimos juntos o cómo me sentí con ella", "K"), ("Su cara", "V"), ("Su nombre y su voz", "A")]),
    ("En clase prefieres que tu maestra o maestro…",
     [("Use el pizarrón, imágenes y esquemas", "V"), ("Explique y converse con el grupo", "A"),
      ("Nos ponga a hacer experimentos o actividades", "K")]),
    ("Si tienes que armar algo, ¿qué haces?",
     [("Pido que alguien me lea o me explique los pasos", "A"), ("Empiezo a armarlo y voy descubriendo cómo", "K"),
      ("Miro el dibujo de las instrucciones", "V")]),
    ("Cuando te aburres esperando, ¿qué haces?",
     [("Me muevo o juego con algo en las manos", "K"), ("Miro a mi alrededor o dibujo", "V"),
      ("Canto, tarareo o platico", "A")]),
    ("¿Qué frase se parece más a ti?",
     [("«Lo entiendo cuando lo veo»", "V"), ("«Lo entiendo cuando lo escucho»", "A"),
      ("«Lo entiendo cuando lo hago»", "K")]),
]
N_VAK = len(_VAK)

# --------------------------------------------------------------- Autopercepción (2 afirmaciones por habilidad)
# p = primaria, s = secundaria. Escala 1-4 (nada, poco, bastante, mucho).
ESCALA = [
    {"valor": 1, "emoji": "😐", "texto": "Nada"},
    {"valor": 2, "emoji": "🙂", "texto": "Un poco"},
    {"valor": 3, "emoji": "😀", "texto": "Bastante"},
    {"valor": 4, "emoji": "🤩", "texto": "Mucho"},
]
_AUTO = {
    "creatividad": [
        ("Se me ocurren muchas ideas distintas cuando tengo que resolver algo.",
         "Se me ocurren muchas ideas distintas cuando tengo que resolver algo."),
        ("Me gusta inventar, dibujar o crear cosas nuevas, aunque nadie me lo pida.",
         "Creo cosas nuevas (dibujos, historias, música, proyectos) por iniciativa propia."),
    ],
    "logico": [
        ("Me gustan los acertijos, los juegos de estrategia o encontrar patrones.",
         "Me gustan los acertijos, los juegos de estrategia o encontrar patrones."),
        ("Cuando algo no tiene sentido, busco la regla o la razón que lo explica.",
         "Cuando algo no cuadra, busco la regla o la razón que lo explica."),
    ],
    "comunicacion": [
        ("Puedo explicar mis ideas para que los demás me entiendan.",
         "Puedo explicar mis ideas para que los demás me entiendan."),
        ("Me siento a gusto al hablar o presentar frente al grupo.",
         "Me siento a gusto al hablar o presentar frente al grupo."),
    ],
    "colaboracion": [
        ("Me gusta trabajar en equipo y repartir las tareas.",
         "Me gusta trabajar en equipo y repartir las tareas con justicia."),
        ("Cuando hay un desacuerdo en el equipo, busco que nos pongamos de acuerdo.",
         "Cuando hay un desacuerdo en el equipo, busco una solución que sirva a todos."),
    ],
    "resolucion": [
        ("Cuando algo me sale mal, pruebo otra forma hasta lograrlo.",
         "Cuando algo me sale mal, pruebo otra estrategia hasta lograrlo."),
        ("Antes de resolver un problema, pienso en los pasos que voy a seguir.",
         "Antes de resolver un problema, planeo los pasos que voy a seguir."),
    ],
    "autoconocimiento": [
        ("Sé en qué cosas soy bueno y en cuáles necesito ayuda.",
         "Sé en qué cosas soy bueno y en cuáles necesito ayuda."),
        ("Me doy cuenta de lo que siento y por qué lo siento.",
         "Identifico lo que siento y qué lo provoca."),
    ],
    "empatia": [
        ("Noto cuando alguien está triste o molesto, aunque no lo diga.",
         "Noto cuando alguien está triste o molesto, aunque no lo diga."),
        ("Me pongo en el lugar de otras personas antes de opinar.",
         "Intento entender el punto de vista de otras personas antes de opinar."),
    ],
    "adaptabilidad": [
        ("Me adapto con facilidad cuando cambian los planes o las reglas.",
         "Me adapto con facilidad cuando cambian los planes o las reglas."),
        ("Me animo a probar cosas nuevas aunque al principio me cueste.",
         "Me animo a probar cosas nuevas aunque al principio me cueste."),
    ],
}
# Orden de presentación: primero la 1.ª afirmación de cada habilidad, luego la 2.ª (se intercalan las habilidades).
_ORDEN_AUTO = [(h["id"], k) for k in (0, 1) for h in K.HABILIDADES]
N_AUTO = len(_ORDEN_AUTO)


def contenido_test(nivel):
    """Contenido para el navegador (sin canales ni habilidades asociadas)."""
    col = 0 if nivel == "primaria" else 1
    vak = [{"n": i + 1, "pregunta": q, "opciones": [t for t, _ in ops]} for i, (q, ops) in enumerate(_VAK)]
    auto = [{"n": i + 1, "texto": _AUTO[h][k][col]} for i, (h, k) in enumerate(_ORDEN_AUTO)]
    return {"vak": vak, "auto": auto, "escala": ESCALA, "intereses": K.INTERESES, "maxIntereses": K.MAX_INTERESES}


def validar_envio(vak, auto, intereses):
    if not isinstance(vak, list) or len(vak) != N_VAK or \
            any(isinstance(v, bool) or not isinstance(v, int) or not 0 <= v <= 2 for v in vak):
        raise ValueError(f"El test de estilo debe tener {N_VAK} respuestas")
    if not isinstance(auto, list) or len(auto) != N_AUTO or \
            any(isinstance(v, bool) or not isinstance(v, int) or not 1 <= v <= 4 for v in auto):
        raise ValueError(f"La autopercepción debe tener {N_AUTO} respuestas")
    if not isinstance(intereses, list) or not 1 <= len(intereses) <= K.MAX_INTERESES:
        raise ValueError(f"Elige de 1 a {K.MAX_INTERESES} intereses")
    intereses = list(dict.fromkeys(intereses))
    if any(i not in K.NOMBRE_INT for i in intereses):
        raise ValueError("Interés inválido")
    return intereses


def calcular_resultado(vak, auto, intereses):
    """Devuelve un dict serializable con estilo, autopercepción (0-100 por habilidad) e intereses."""
    conteo = {"V": 0, "A": 0, "K": 0}
    for i, idx in enumerate(vak):
        conteo[_VAK[i][1][idx][1]] += 1
    orden = sorted(conteo, key=lambda c: (-conteo[c], "VAK".index(c)))
    principal = orden[0]
    # Si la diferencia con el segundo canal es de 1 respuesta o menos, se reporta también el canal de apoyo.
    secundario = orden[1] if conteo[orden[0]] - conteo[orden[1]] <= 1 else None
    equilibrado = conteo[orden[0]] - conteo[orden[2]] <= 1
    estilo = {
        "conteo": conteo,
        "porcentajes": {c: round(100 * conteo[c] / N_VAK) for c in conteo},
        "principal": principal,
        "secundario": secundario,
        "equilibrado": equilibrado,
        "total": N_VAK,
    }
    suma = {h["id"]: 0 for h in K.HABILIDADES}
    for (hab, _k), v in zip(_ORDEN_AUTO, auto):
        suma[hab] += v
    # 2 afirmaciones de 1 a 4: suma de 2 a 8  ->  0 a 100
    auto_pct = {h: round(100 * (s - 2) / 6) for h, s in suma.items()}
    return {"estilo": estilo, "auto": auto_pct, "intereses": intereses}
