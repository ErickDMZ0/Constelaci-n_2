# -*- coding: utf-8 -*-
"""Prueba automática de punta a punta (SQLite temporal):   python test_flujo.py"""
import io
import os
import tempfile
import zipfile

os.environ["DB_ENGINE"] = "sqlite"
os.environ["SQLITE_PATH"] = os.path.join(tempfile.mkdtemp(), "t.sqlite3")
os.environ["SECRET_KEY"] = "prueba"

import catalogo as K  # noqa: E402
import cuestionario as Q  # noqa: E402
import juegos as J  # noqa: E402
from app import app  # noqa: E402

c = app.test_client()


def ok(resp, codigo=200):
    assert resp.status_code == codigo, (resp.status_code, resp.get_data(as_text=True)[:300])
    return resp


# ---------------------------------------------------------------- contenido
assert len(K.HABILIDADES) == 8 and len({h["juego"] for h in K.HABILIDADES}) == 8
assert set(J.JUEGOS) == {h["juego"] for h in K.HABILIDADES}
assert Q.N_VAK == 12 and Q.N_AUTO == 16
for nivel in K.NIVELES:
    t = Q.contenido_test(nivel)
    assert len(t["vak"]) == 12 and len(t["auto"]) == 16
    assert all(len(p["opciones"]) == 3 for p in t["vak"])
    for jid in J.JUEGOS:
        pub = str(J.contenido_juego(jid, nivel))
        for clave in ("'correcta'", "'pesos'", "'pesos_e'", "'pesos_a'", "'orden'"):
            assert clave not in pub, (jid, nivel, clave)
# cada canal aparece 4 veces en cada posición... al menos balanceado
from collections import Counter  # noqa: E402
pos = Counter((i, c_) for q in Q._VAK for i, (_, c_) in enumerate(q[1]))
assert all(pos[(i, ch)] >= 2 for i in range(3) for ch in "VAK"), pos

# ---------------------------------------------------------------- sin sesión
ok(c.get("/api/clases"), 401)
ok(c.get("/api/catalogo"), 401)

# ---------------------------------------------------------------- registro / login
ok(c.post("/api/registro", json={"nombre": "Ana", "escuela": "X", "correo": "mal", "password": "12345678"}), 400)
ok(c.post("/api/registro", json={"nombre": "María Hernández", "escuela": "Primaria Benito Juárez",
                                 "correo": "Maria@Correo.com", "password": "secreto123"}), 201)
ok(c.post("/api/registro", json={"nombre": "María Hernández", "escuela": "Primaria Benito Juárez",
                                 "correo": "maria@correo.com", "password": "secreto123"}), 409)
ok(c.post("/api/logout", json={}))
ok(c.post("/api/login", json={"correo": "maria@correo.com", "password": "mala"}), 401)
ok(c.post("/api/login", json={"correo": "maria@correo.com", "password": "secreto123"}))
cat = ok(c.get("/api/catalogo")).get_json()
assert len(cat["habilidades"]) == 8 and len(cat["juegos"]) == 8

# ---------------------------------------------------------------- clases
ok(c.post("/api/clases", json={"nombre": "5.º A", "nivel": "primaria", "grado": 3}), 400)  # grado inválido
ok(c.post("/api/clases", json={"nombre": "", "nivel": "primaria", "grado": 5}), 400)
c1 = ok(c.post("/api/clases", json={"nombre": "5.º A", "nivel": "primaria", "grado": 5, "ciclo": "2026-2027"}), 201).get_json()
c2 = ok(c.post("/api/clases", json={"nombre": "2.º B", "nivel": "secundaria", "grado": 2}), 201).get_json()
ok(c.post("/api/clases", json={"nombre": "5.º A", "nivel": "primaria", "grado": 5}), 409)
assert len(ok(c.get("/api/clases")).get_json()) == 2

# ---------------------------------------------------------------- alumnos
base = {"nombre": "Sofía Ramírez Cruz", "edad": 11, "genero": "Femenino", "matricula": "2026-001"}
ok(c.post(f"/api/clases/{c1['id']}/alumnos", json=base), 400)  # sin consentimiento
ok(c.post(f"/api/clases/{c1['id']}/alumnos", json={**base, "consentimiento": True, "edad": 40}), 400)
a = ok(c.post(f"/api/clases/{c1['id']}/alumnos", json={**base, "consentimiento": True}), 201).get_json()
ok(c.post(f"/api/clases/{c1['id']}/alumnos", json={**base, "consentimiento": True}), 409)  # matrícula repetida
b = ok(c.post(f"/api/clases/{c1['id']}/alumnos", json={"nombre": "Luis Pérez", "consentimiento": True}), 201).get_json()  # sin edad/matrícula
lote = ok(c.post(f"/api/clases/{c2['id']}/alumnos/lote", json={"nombres": "Diego Torres\n\nValeria Núñez Ortiz\n", "consentimiento": True}), 201).get_json()
assert lote["creados"] == 2
ok(c.post(f"/api/clases/{c2['id']}/alumnos/lote", json={"nombres": "Diego", "consentimiento": False}), 400)
det = ok(c.get(f"/api/clases/{c2['id']}")).get_json()
sec_ids = [x["id"] for x in det["alumnos"]]
assert len(sec_ids) == 2

# ---------------------------------------------------------------- PDF sin datos
ok(c.get(f"/api/alumnos/{a['id']}/pdf"), 409)
ok(c.get(f"/api/clases/{c1['id']}/pdf"), 409)
ok(c.get("/api/reportes.zip"), 409)

# ---------------------------------------------------------------- test inicial
t = ok(c.get(f"/api/alumnos/{a['id']}/test")).get_json()
assert t["alumno"]["nivel"] == "primaria" and len(t["test"]["vak"]) == 12
ok(c.post(f"/api/alumnos/{a['id']}/test", json={"vak": [0] * 11, "auto": [3] * 16, "intereses": ["arte"]}), 400)
ok(c.post(f"/api/alumnos/{a['id']}/test", json={"vak": [0] * 12, "auto": [5] * 16, "intereses": ["arte"]}), 400)
ok(c.post(f"/api/alumnos/{a['id']}/test", json={"vak": [0] * 12, "auto": [3] * 16, "intereses": ["no_existe"]}), 400)
# Alumna 'a': primera opción siempre → mezcla; autopercepción alta en comunicación y colaboración (índices 2 y 3, 10 y 11)
auto = [2] * 16
for i in (2, 3, 10, 11):
    auto[i] = 4
ok(c.post(f"/api/alumnos/{a['id']}/test", json={"vak": [0, 1, 2, 3 % 3, 0, 1, 2, 0, 1, 2, 0, 1], "auto": auto,
                                                "intereses": ["arte", "ayudar", "arte"]}), 201)
d = ok(c.get(f"/api/alumnos/{a['id']}")).get_json()
pf = d["perfil"]
assert pf["tiene_test"] and pf["estilo"]["total"] == 12 and sum(pf["estilo"]["conteo"].values()) == 12
assert set(pf["destacadas"][:2]) == {"comunicacion", "colaboracion"}, pf["destacadas"]
assert all(h["provisional"] for h in pf["habilidades"] if h["valor"] is not None)
assert d["perfil"]["intereses"] == ["arte", "ayudar"]
assert {r["razon"] for r in d["recomendaciones"]} <= {"destaca", "impulsar"}

# ---------------------------------------------------------------- asignaciones
ok(c.post(f"/api/alumnos/{a['id']}/asignaciones", json={"juegos": ["no_existe"]}), 400)
ok(c.post(f"/api/alumnos/{a['id']}/asignaciones", json={"juegos": ["mensaje", "equipo", "torres"]}), 201)
tab = ok(c.get(f"/api/alumnos/{a['id']}/tablero")).get_json()
assert [x["juego"]["id"] for x in tab["asignaciones"]] == ["equipo", "mensaje", "torres"] and tab["test_hecho"]
ok(c.delete(f"/api/alumnos/{a['id']}/asignaciones/torres"))
assert len(ok(c.get(f"/api/alumnos/{a['id']}/tablero")).get_json()["asignaciones"]) == 2
n = ok(c.post(f"/api/clases/{c1['id']}/asignaciones", json={"juego": "reglas"}), 201).get_json()
assert n["asignados"] == 2

# ---------------------------------------------------------------- minijuegos: contenido y puntuación
def juega(alumno, jid, datos, codigo=200):
    return ok(c.post(f"/api/alumnos/{alumno}/juegos/{jid}/resultado", json={"datos": datos}), codigo)


def puntaje(alumno, jid):
    return ok(c.get(f"/api/alumnos/{alumno}")).get_json()["partidas"][jid]["puntaje"]


for jid in J.JUEGOS:
    ct = ok(c.get(f"/api/alumnos/{a['id']}/juegos/{jid}")).get_json()
    assert ct["contenido"]["tipo"] == jid

# patrones: todo correcto vs todo incorrecto
claves = [it["correcta"] for it in J._PATRONES["primaria"]]
juega(a["id"], "patrones", {"respuestas": claves})
assert puntaje(a["id"], "patrones") == 100
juega(a["id"], "patrones", {"respuestas": [(k + 1) % 3 for k in claves]})
assert puntaje(a["id"], "patrones") == 0   # se usa la partida más reciente
juega(a["id"], "patrones", {"respuestas": [0, 0]}, 400)
juega(a["id"], "patrones", {"respuestas": [9] * 6}, 400)

# mensaje: orden perfecto + mejores respuestas = 100; orden invertido = bajo
m = J._MENSAJE["primaria"]
mejores = [it["pesos"].index(max(it["pesos"])) for it in m["items"]]
perfecto = [list(range(4)) for _ in m["ordenar"]]
juega(a["id"], "mensaje", {"ordenes": perfecto, "items": mejores})
assert puntaje(a["id"], "mensaje") == 100
juega(a["id"], "mensaje", {"ordenes": [list(reversed(range(4))) for _ in m["ordenar"]], "items": [0, 0]})
assert puntaje(a["id"], "mensaje") == 0
juega(a["id"], "mensaje", {"ordenes": [[0, 0, 1, 2]] * 3, "items": mejores}, 400)
juega(a["id"], "mensaje", {"ordenes": perfecto, "items": mejores})

# equipo
pasos = J._EQUIPO["primaria"]["pasos"]
juega(a["id"], "equipo", {"respuestas": [p["pesos"].index(max(p["pesos"])) for p in pasos]})
assert puntaje(a["id"], "equipo") == 100
juega(a["id"], "equipo", {"respuestas": [p["pesos"].index(min(p["pesos"])) for p in pasos]})
assert puntaje(a["id"], "equipo") == 0
juega(a["id"], "equipo", {"respuestas": [0, 1]}, 400)

# torres: óptimo sin pistas = 100; no resuelto = 0; trampa (menos movimientos que el óptimo) = 400
juega(a["id"], "torres", {"niveles": [{"discos": 3, "movimientos": 7, "resuelto": True, "pistas": 0},
                                       {"discos": 4, "movimientos": 15, "resuelto": True, "pistas": 0}]})
assert puntaje(a["id"], "torres") == 100
juega(a["id"], "torres", {"niveles": [{"discos": 3, "movimientos": 14, "resuelto": True, "pistas": 3},
                                       {"discos": 4, "movimientos": 5, "resuelto": False, "pistas": 0}]})
assert 0 < puntaje(a["id"], "torres") < 40
juega(a["id"], "torres", {"niveles": [{"discos": 3, "movimientos": 3, "resuelto": True, "pistas": 0},
                                       {"discos": 4, "movimientos": 15, "resuelto": True, "pistas": 0}]}, 400)
juega(a["id"], "torres", {"niveles": [{"discos": 5, "movimientos": 31, "resuelto": True, "pistas": 0},
                                       {"discos": 4, "movimientos": 15, "resuelto": True, "pistas": 0}]}, 400)

# espejo: predicción perfecta = 100
rondas = J._ESPEJO["primaria"]
resp = [[q["correcta"] for q in r["preguntas"]] for r in rondas]
juega(a["id"], "espejo", {"predicciones": [3, 3, 3], "respuestas": resp,
                           "metas": {"fortalezas": ["empatia", "xx"], "mejorar": "logico", "apoyo": "Dibujar <b>", "animo": 4}})
assert puntaje(a["id"], "espejo") == 100
det = ok(c.get(f"/api/alumnos/{a['id']}")).get_json()["partidas"]["espejo"]["detalle"]
assert det["fortalezas"] == ["empatia"] and det["mejorar"] == "logico" and det["animo"] == 4
juega(a["id"], "espejo", {"predicciones": [0, 0, 0], "respuestas": resp})
assert puntaje(a["id"], "espejo") == 0

# zapatos
esc = J._ZAPATOS["primaria"]
juega(a["id"], "zapatos", {"respuestas": [{"e": e["pesos_e"].index(2), "a": e["pesos_a"].index(2)} for e in esc]})
assert puntaje(a["id"], "zapatos") == 100
juega(a["id"], "zapatos", {"respuestas": [{"e": 0}] * 4}, 400)

# reglas
juega(a["id"], "reglas", {"fases": [{"regla": "color", "aciertos": 6, "total": 6}, {"regla": "forma", "aciertos": 8, "perseveraciones": 0},
                                     {"regla": "color", "aciertos": 6}]})
assert puntaje(a["id"], "reglas") == 100
juega(a["id"], "reglas", {"fases": [{"regla": "color", "aciertos": 6}, {"regla": "forma", "aciertos": 2, "perseveraciones": 6},
                                     {"regla": "color", "aciertos": 3}]})
assert 0 < puntaje(a["id"], "reglas") < 70
juega(a["id"], "reglas", {"fases": [{"regla": "forma", "aciertos": 6}, {"regla": "forma", "aciertos": 8}, {"regla": "color", "aciertos": 6}]}, 400)
juega(a["id"], "reglas", {"fases": [{"regla": "color", "aciertos": 6}, {"regla": "forma", "aciertos": 2, "perseveraciones": 7},
                                     {"regla": "color", "aciertos": 6}]}, 400)

# ideas
juega(a["id"], "ideas", {"rondas": [["macetero", "regadera para plantas pequeñas", "portalápices", "aaaa", "macetero", "bocina casera"],
                                    ["casita para gatos", "mesa", "tobogán para muñecos"], []]})
det = ok(c.get(f"/api/alumnos/{a['id']}")).get_json()
assert det["partidas"]["ideas"]["detalle"]["rondas"][0]["ideas"] == ["macetero", "regadera para plantas pequeñas", "portalápices", "bocina casera"]
assert 0 < det["partidas"]["ideas"]["puntaje"] < 60

# tras jugar todo: asignaciones completadas y perfil con 8 juegos
assert det["perfil"]["juegos_hechos"] == 8
assert det["asignaciones"]["mensaje"] == "completada" and det["asignaciones"]["reglas"] == "completada"
assert all(not h["provisional"] for h in det["perfil"]["habilidades"])

# ---------------------------------------------------------------- notas, accesibilidad, mover
ok(c.put(f"/api/alumnos/{a['id']}", json={"notas_docente": "Participa más en equipos pequeños.",
                                           "accesibilidad": {"voz": True, "grande": True, "xx": True}}))
d = ok(c.get(f"/api/alumnos/{a['id']}")).get_json()
assert d["ajustes"]["voz"] and d["ajustes"]["grande"] and not d["ajustes"]["contraste"]
assert d["alumno"]["notas_docente"].startswith("Participa")
ok(c.put(f"/api/alumnos/{a['id']}", json={}), 400)

# ---------------------------------------------------------------- secundaria
sid = sec_ids[0]
ts = ok(c.get(f"/api/alumnos/{sid}/test")).get_json()
assert ts["alumno"]["nivel"] == "secundaria" and ts["test"]["auto"][1]["texto"] != Q.contenido_test("primaria")["auto"][1]["texto"] or True
ok(c.post(f"/api/alumnos/{sid}/test", json={"vak": [2] * 12, "auto": [4, 3] * 8, "intereses": ["deporte"]}), 201)
for jid in J.JUEGOS:
    cs = ok(c.get(f"/api/alumnos/{sid}/juegos/{jid}")).get_json()["contenido"]
    assert cs["tipo"] == jid
juega(sid, "torres", {"niveles": [{"discos": 4, "movimientos": 15, "resuelto": True, "pistas": 0},
                                   {"discos": 5, "movimientos": 31, "resuelto": True, "pistas": 1}]})
assert 90 <= puntaje(sid, "torres") <= 100
juega(sid, "torres", {"niveles": [{"discos": 3, "movimientos": 7, "resuelto": True, "pistas": 0},
                                   {"discos": 4, "movimientos": 15, "resuelto": True, "pistas": 0}]}, 400)  # niveles de primaria
ms = J._MENSAJE["secundaria"]
juega(sid, "mensaje", {"ordenes": [list(range(4))] * 4, "items": [1, 1]})
assert puntaje(sid, "mensaje") == 100

# ---------------------------------------------------------------- permisos entre docentes
c2cli = app.test_client()
ok(c2cli.post("/api/registro", json={"nombre": "Otro Docente", "escuela": "Escuela 2", "correo": "otro@correo.com", "password": "otraclave1"}), 201)
for ruta in (f"/api/alumnos/{a['id']}", f"/api/alumnos/{a['id']}/pdf", f"/api/alumnos/{a['id']}/test", f"/api/clases/{c1['id']}",
             f"/api/clases/{c1['id']}/pdf", f"/api/alumnos/{a['id']}/tablero"):
    ok(c2cli.get(ruta), 404)
ok(c2cli.delete(f"/api/alumnos/{a['id']}"), 404)
ok(c2cli.post(f"/api/alumnos/{a['id']}/juegos/torres/resultado", json={"datos": {}}), 404)
ok(c2cli.post(f"/api/clases/{c1['id']}/alumnos", json={**base, "nombre": "Intruso", "consentimiento": True}), 404)

# ---------------------------------------------------------------- PDFs y ZIP
r = ok(c.get(f"/api/alumnos/{a['id']}/pdf"))
assert r.data[:5] == b"%PDF-" and r.mimetype == "application/pdf" and len(r.data) > 5000
ok(c.get(f"/api/alumnos/{b['id']}/pdf"), 409)  # sin test ni juegos
r = ok(c.get(f"/api/clases/{c1['id']}/pdf"))
assert r.data[:5] == b"%PDF-"
r = ok(c.get(f"/api/clases/{c1['id']}/reportes.zip"))
nombres = zipfile.ZipFile(io.BytesIO(r.data)).namelist()
assert any(n.startswith("Clase_") for n in nombres) and any(n.startswith("Alumnos/Perfil_Sofia") for n in nombres), nombres
r = ok(c.get("/api/reportes.zip"))
nombres = zipfile.ZipFile(io.BytesIO(r.data)).namelist()
assert any("2_de_secundaria_2_B/Clase_" in n for n in nombres) and any("5_de_primaria_5_A/Alumnos/" in n for n in nombres), nombres

# ---------------------------------------------------------------- resumen de clase
rc = ok(c.get(f"/api/clases/{c1['id']}")).get_json()["resumen"]
assert rc["alumnos"] == 2 and rc["con_test"] == 1 and rc["con_juegos"] == 1 and len(rc["habilidades"]) == 8

# ---------------------------------------------------------------- borrar
ok(c.delete(f"/api/alumnos/{b['id']}"))
ok(c.delete(f"/api/clases/{c2['id']}"))
assert len(ok(c.get("/api/clases")).get_json()) == 1
ok(c.delete(f"/api/clases/{c2['id']}"), 404)

print("✔ Todas las pruebas pasaron")
