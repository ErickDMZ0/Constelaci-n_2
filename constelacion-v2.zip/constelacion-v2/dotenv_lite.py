# -*- coding: utf-8 -*-
"""Lector mínimo de archivos .env (evita depender de python-dotenv)."""
import os


def cargar_env(ruta=None):
    ruta = ruta or os.path.join(os.path.dirname(__file__), ".env")
    if not os.path.exists(ruta):
        return
    with open(ruta, encoding="utf-8") as f:
        for linea in f:
            linea = linea.strip()
            if not linea or linea.startswith("#") or "=" not in linea:
                continue
            clave, valor = linea.split("=", 1)
            os.environ.setdefault(clave.strip(), valor.strip().strip('"').strip("'"))
