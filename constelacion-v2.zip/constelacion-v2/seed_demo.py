# -*- coding: utf-8 -*-
"""Datos de DEMOSTRACIÓN (ficticios) para probar el prototipo sin capturar a mano:

    python seed_demo.py            # crea el docente demo y 2 clases con estudiantes simulados
    python seed_demo.py --borrar   # elimina esos datos

Docente demo:  demo@constelacion.test  /  Demo2026!
Los nombres y resultados son inventados; los resultados pasan por la MISMA función de puntuación que los reales.
"""
import json
import random
import sys

from werkzeug.security import generate_password_hash

import catalogo as K
import cuestionario as Q
import db
import juegos as J
from app import app

CORREO, CLAVE = "demo@constelacion.test", "Demo2026!"
NOMBRES = ["Ximena Torres", "Mateo Ruiz", "Valeria Ortega", "Diego Salazar", "Camila Reyes", "Emiliano Cruz", "Renata Mendoza",
           "Santiago Vega", "Regina Castillo", "Leonardo Núñez", "Fernanda Ibarra", "Iker Domínguez", "Sofía Paredes", "Joaquín Lara",
           "Itzel Aguilar", "Bruno Cabrera", "Daniela Fuentes", "Axel Montes", "Paula Esquivel", "Thiago Barrera", "Luna Valdez",
           "Nicolás Soto", "Aitana Rojas", "Gael Medina"]
IDEAS = ["sirve para guardar lápices y colores", "una maceta para sembrar flores", "hacer un instrumento musical", "un juguete para mi mascota",
         "usarlo como disfraz para la obra", "lámpara con luces pequeñas", "construir una casita de muñecos", "un comedero para pájaros",
         "organizador de cosas pequeñas", "un tambor", "regalo decorado a mano", "alcancía"]
HAB_IDS = [h["id"] for h in K.HABILIDADES]


def mejor(pesos):
    return max(range(len(pesos)), key=lambda i: pesos[i])


def elegir(rng, s, correcta, n):
    if rng.random() < s:
        return correcta
    return rng.choice([i for i in range(n) if i != correcta] or [correcta])


def datos_juego(jid, nivel, s, rng):
    if jid == "ideas":
        return {"rondas": [rng.sample(IDEAS, max(1, round(s * 6))) for _ in J._IDEAS[nivel]]}
    if jid == "patrones":
        return {"respuestas": [elegir(rng, s, it["correcta"], len(it["opciones"])) for it in J._PATRONES[nivel]]}
    if jid == "mensaje":
        d = J._MENSAJE[nivel]
        ordenes = []
        for r in d["ordenar"]:
            o = list(range(len(r["orden"])))
            for _ in range(round((1 - s) * 3)):
                i = rng.randrange(len(o) - 1)
                o[i], o[i + 1] = o[i + 1], o[i]
            ordenes.append(o)
        return {"ordenes": ordenes, "items": [elegir(rng, s, mejor(it["pesos"]), len(it["opciones"])) for it in d["items"]]}
    if jid == "equipo":
        return {"respuestas": [elegir(rng, s, mejor(p["pesos"]), len(p["opciones"])) for p in J._EQUIPO[nivel]["pasos"]]}
    if jid == "torres":
        niveles = []
        for n in J._TORRES[nivel]:
            opt = 2 ** n - 1
            niveles.append({"discos": n, "movimientos": opt + round((1 - s) * opt * 1.6), "resuelto": s > 0.25, "pistas": min(3, round((1 - s) * 3))})
        return {"niveles": niveles}
    if jid == "espejo":
        rondas = J._ESPEJO[nivel]
        resp = [[elegir(rng, s, q["correcta"], len(q["opciones"])) for q in r["preguntas"]] for r in rondas]
        pred = [max(0, min(3, round(s * 3 + rng.choice([-1, 0, 0, 1])))) for _ in rondas]
        fort = rng.sample(HAB_IDS, 2)
        return {"predicciones": pred, "respuestas": resp,
                "metas": {"fortalezas": fort, "mejorar": rng.choice(HAB_IDS), "apoyo": rng.choice(["que me expliquen con dibujos", "trabajar con un compañero", "practicar con ejemplos"]), "animo": rng.randint(3, 5)}}
    if jid == "zapatos":
        return {"respuestas": [{"e": elegir(rng, s, mejor(e["pesos_e"]), len(e["emociones"])), "a": elegir(rng, s, mejor(e["pesos_a"]), len(e["acciones"]))} for e in J._ZAPATOS[nivel]]}
    if jid == "reglas":
        fases = []
        for regla, total in J._REGLAS[nivel]:
            aciertos = min(total, round(total * (0.5 + 0.5 * s) + rng.choice([-1, 0, 0, 1])))
            fases.append({"regla": regla, "aciertos": max(0, aciertos), "perseveraciones": min(total - max(0, aciertos), round((1 - s) * 3))})
        return {"fases": fases}
    raise KeyError(jid)


def crear_clase(rng, docente_id, nombre, nivel, grado, n, juegos_por_alumno):
    cid = db.ejecutar("INSERT INTO clases (docente_id, nombre, nivel, grado, ciclo) VALUES (%s, %s, %s, %s, %s)",
                      (docente_id, nombre, nivel, grado, "2026-2027"))
    for nombre_al in rng.sample(NOMBRES, n):
        edad = (10 if grado == 5 else 11) if nivel == "primaria" else 11 + grado
        aid = db.ejecutar("INSERT INTO alumnos (docente_id, clase_id, nombre, edad, genero, matricula, consentimiento) VALUES (%s, %s, %s, %s, %s, %s, 1)",
                          (docente_id, cid, nombre_al, edad + rng.choice([0, 0, 1]), rng.choice(["Femenino", "Masculino", "Prefiero no decirlo"]), f"D{cid}{rng.randint(100, 999)}"))
        base = {h: min(0.97, max(0.12, rng.gauss(0.62, 0.22))) for h in HAB_IDS}
        # Test: preferencia VAK y autopercepción correlacionada con la habilidad
        vak = [rng.choices([0, 1, 2], weights=[3, 2, 2][::1] if rng.random() < .5 else [1, 3, 2])[0] for _ in range(Q.N_VAK)]
        auto = [max(1, min(4, round(1 + 3 * base[h] + rng.gauss(0, .6)))) for h, _k in Q._ORDEN_AUTO]
        res = Q.calcular_resultado(vak, auto, rng.sample([i["id"] for i in K.INTERESES], rng.randint(1, 3)))
        db.ejecutar("INSERT INTO evaluaciones (alumno_id, estado, resultado_json, completada_en) VALUES (%s, 'completada', %s, CURRENT_TIMESTAMP)",
                    (aid, json.dumps(res, ensure_ascii=False)))
        # Juegos: los que "ya jugó" y alguno pendiente
        jugados = rng.sample(K.HABILIDADES, juegos_por_alumno)
        for hb in jugados:
            jid = hb["juego"]
            puntaje, det = J.puntuar_juego(jid, nivel, datos_juego(jid, nivel, base[hb["id"]], rng))
            db.ejecutar("INSERT INTO partidas (alumno_id, juego_id, puntaje, detalle_json) VALUES (%s, %s, %s, %s)", (aid, jid, puntaje, json.dumps(det, ensure_ascii=False)))
            db.ejecutar("INSERT INTO asignaciones (alumno_id, juego_id, estado, completada_en) VALUES (%s, %s, 'completada', CURRENT_TIMESTAMP)", (aid, jid))
        for hb in rng.sample([h for h in K.HABILIDADES if h not in jugados], 1):
            db.ejecutar("INSERT INTO asignaciones (alumno_id, juego_id) VALUES (%s, %s)", (aid, hb["juego"]))
    return cid


def main():
    rng = random.Random(2026)
    with app.app_context():
        previo = db.consulta("SELECT id FROM docentes WHERE correo = %s", (CORREO,), uno=True)
        if previo:
            db.ejecutar("DELETE FROM docentes WHERE id = %s", (previo["id"],))
            print("Datos demo anteriores eliminados.")
        if "--borrar" in sys.argv:
            return
        did = db.ejecutar("INSERT INTO docentes (nombre, correo, escuela, password_hash) VALUES (%s, %s, %s, %s)",
                          ("Docente Demo", CORREO, "Escuela de Demostración", generate_password_hash(CLAVE)))
        crear_clase(rng, did, "5.º A", "primaria", 5, 14, 5)
        crear_clase(rng, did, "2.º B", "secundaria", 2, 12, 4)
        print(f"Listo. Entra con  {CORREO}  /  {CLAVE}")


if __name__ == "__main__":
    main()
