# -*- coding: utf-8 -*-
"""Catálogo base de Constelación: habilidades (octágono), niveles, intereses y textos para reportes."""

# ------------------------------------------------------------------ Niveles y grados
NIVELES = {
    "primaria": {"nombre": "Primaria", "grados": [5, 6]},
    "secundaria": {"nombre": "Secundaria", "grados": [1, 2, 3]},
}


def nombre_grupo(nivel, grado):
    return f"{grado}.º de {NIVELES[nivel]['nombre'].lower()}"


# ------------------------------------------------------------------ Las 8 habilidades del octágono
# El orden es el del octágono (sentido de las manecillas, empezando arriba).
# color = versión para pantalla oscura; color_pdf = versión para impresión.
# Cada color se usa siempre junto con un icono y el nombre: el color nunca es la única pista.
HABILIDADES = [
    {"id": "creatividad", "nombre": "Creatividad", "corto": "Creatividad", "icono": "💡",
     "color": "#ff8a5b", "color_pdf": "#e8622f", "juego": "ideas",
     "frase": "Imaginar ideas nuevas y distintas"},
    {"id": "logico", "nombre": "Pensamiento lógico", "corto": "Lógico", "icono": "🧩",
     "color": "#5aa9ff", "color_pdf": "#2f7de0", "juego": "patrones",
     "frase": "Descubrir reglas, patrones y razones"},
    {"id": "comunicacion", "nombre": "Comunicación", "corto": "Comunicación", "icono": "💬",
     "color": "#ffcc4d", "color_pdf": "#d99a00", "juego": "mensaje",
     "frase": "Expresar ideas con claridad"},
    {"id": "colaboracion", "nombre": "Colaboración", "corto": "Colaboración", "icono": "🤝",
     "color": "#6ee09a", "color_pdf": "#1fa860", "juego": "equipo",
     "frase": "Trabajar con otras personas"},
    {"id": "resolucion", "nombre": "Resolución de problemas", "corto": "Resolución", "icono": "🛠️",
     "color": "#9b8cff", "color_pdf": "#6c5ce7", "juego": "torres",
     "frase": "Planear pasos para llegar a una solución"},
    {"id": "autoconocimiento", "nombre": "Autoconocimiento", "corto": "Autoconoc.", "icono": "🪞",
     "color": "#3fd0d4", "color_pdf": "#12a3a8", "juego": "espejo",
     "frase": "Saber cómo soy y cómo aprendo"},
    {"id": "empatia", "nombre": "Empatía", "corto": "Empatía", "icono": "💗",
     "color": "#ff8fb3", "color_pdf": "#d6457a", "juego": "zapatos",
     "frase": "Entender lo que sienten los demás"},
    {"id": "adaptabilidad", "nombre": "Adaptabilidad", "corto": "Adaptabilidad", "icono": "🌊",
     "color": "#c7e35a", "color_pdf": "#8fae1b", "juego": "reglas",
     "frase": "Cambiar de estrategia cuando algo cambia"},
]
HAB = {h["id"]: h for h in HABILIDADES}
HAB_DE_JUEGO = {h["juego"]: h["id"] for h in HABILIDADES}
NOMBRE_HAB = {h["id"]: h["nombre"] for h in HABILIDADES}

# Umbrales de nivel (sobre 0-100)
UMBRAL_DESTACA = 75
UMBRAL_DESARROLLO = 50


def nivel(valor):
    if valor is None:
        return None
    if valor >= UMBRAL_DESTACA:
        return "Destaca"
    if valor >= UMBRAL_DESARROLLO:
        return "En desarrollo"
    return "Para impulsar"


# ------------------------------------------------------------------ Intereses
INTERESES = [
    {"id": "arte", "nombre": "Arte y dibujo", "icono": "🎨"},
    {"id": "musica", "nombre": "Música", "icono": "🎵"},
    {"id": "deporte", "nombre": "Deporte y movimiento", "icono": "⚽"},
    {"id": "ciencia", "nombre": "Ciencia y experimentos", "icono": "🔬"},
    {"id": "tecnologia", "nombre": "Tecnología y computadoras", "icono": "💻"},
    {"id": "naturaleza", "nombre": "Naturaleza y animales", "icono": "🌿"},
    {"id": "historias", "nombre": "Leer y escribir historias", "icono": "📚"},
    {"id": "manualidades", "nombre": "Construir y hacer cosas con las manos", "icono": "🛠️"},
    {"id": "ayudar", "nombre": "Ayudar a otras personas", "icono": "🤝"},
]
NOMBRE_INT = {i["id"]: i["nombre"] for i in INTERESES}
MAX_INTERESES = 3

# ------------------------------------------------------------------ Canales de aprendizaje (modelo PNL / VAK)
CANALES = {"V": "Visual", "A": "Auditivo", "K": "Cinestésico"}
DESCRIPCION_ESTILO = {
    "V": "Prefiere aprender viendo: esquemas, mapas conceptuales, colores, imágenes, videos y un pizarrón bien organizado.",
    "A": "Prefiere aprender escuchando y hablando: explicaciones orales, conversaciones, audios, rimas y repetir en voz alta.",
    "K": "Prefiere aprender haciendo: manipular materiales, moverse, experimentar, dramatizar y trabajar con proyectos.",
}
IDEAS_ESTILO = {
    "V": "Apoyar las explicaciones con esquemas, dibujos o videos cortos; usar colores para organizar ideas.",
    "A": "Dar espacio para explicar en voz alta, trabajar en parejas y escuchar audios o canciones del tema.",
    "K": "Incluir material manipulable, pausas con movimiento, experimentos y proyectos en los que construyan algo.",
}

# ------------------------------------------------------------------ Textos orientativos para el docente
TIPS_DESTACA = {
    "creatividad": "Darle espacio para proponer ideas y diseñar soluciones originales en proyectos; puede presentar o inspirar a su equipo.",
    "logico": "Proponerle acertijos, juegos de estrategia o retos de razonamiento; puede explicar procedimientos a sus compañeros.",
    "comunicacion": "Puede ser vocero o vocera del equipo, presentar proyectos y ayudar a otros a ordenar y expresar sus ideas.",
    "colaboracion": "Puede coordinar equipos, repartir tareas y acompañar a quien se integra con dificultad.",
    "resolucion": "Retos de planeación con varios pasos, proyectos con problemas abiertos y apoyo a quien se atora.",
    "autoconocimiento": "Puede llevar un diario de aprendizaje, fijar metas propias y compartir estrategias con el grupo.",
    "empatia": "Puede ser mediador o mediadora en conflictos, acompañar a estudiantes nuevos y participar en proyectos de servicio.",
    "adaptabilidad": "Puede asumir roles distintos en el equipo, probar formatos nuevos y ayudar al grupo cuando cambian los planes.",
}
TIPS_IMPULSAR = {
    "creatividad": "Lluvias de ideas sin evaluar, retos de 'qué pasaría si' y proyectos abiertos con materiales reciclados.",
    "logico": "Series y acertijos con material manipulable, de lo sencillo a lo complejo, pidiendo que explique su razonamiento en voz alta.",
    "comunicacion": "Espacios breves y seguros para explicar a un compañero antes de hablar frente al grupo; modelar cómo ordenar ideas.",
    "colaboracion": "Roles rotativos en equipo y una reflexión posterior sobre qué ayudó a trabajar mejor juntos.",
    "resolucion": "Dividir los problemas en pasos pequeños, usar dibujos o material concreto y celebrar el intento, no solo el resultado.",
    "autoconocimiento": "Preguntas guía como '¿qué se me facilitó hoy?' y '¿qué me ayudó?'; comparar lo que predijo con lo que logró.",
    "empatia": "Historias y juegos de roles, conversar sobre cómo se sintió cada personaje y qué habría ayudado.",
    "adaptabilidad": "Pequeños cambios de reglas en juegos conocidos, anticipar los cambios y conversar sobre qué hacer con un plan B.",
}
TIPS_INTERES = {
    "arte": "proyectos con dibujo, carteles, maquetas y presentaciones visuales",
    "musica": "ritmos, canciones y rimas para aprender contenidos, y proyectos sonoros",
    "deporte": "aprendizaje con movimiento, juegos cooperativos y pausas activas",
    "ciencia": "experimentos sencillos y preguntas de investigación",
    "tecnologia": "actividades con computadoras o dispositivos y pensamiento computacional sin pantalla",
    "naturaleza": "huertos, observación de animales y proyectos de cuidado del entorno",
    "historias": "escritura de cuentos, periódico escolar y teatro leído",
    "manualidades": "construcción de prototipos, reparaciones y proyectos con materiales",
    "ayudar": "proyectos de servicio comunitario y tutorías entre compañeros",
}

# ------------------------------------------------------------------ Ajustes de accesibilidad por alumno
AJUSTES_ACCESIBILIDAD = {
    "voz": "Lectura en voz alta de preguntas y opciones",
    "grande": "Texto grande",
    "contraste": "Alto contraste",
    "espaciado": "Letra con más espacio entre letras y líneas",
    "quieto": "Sin animaciones ni movimiento",
}
