# -*- coding: utf-8 -*-
"""Los 8 minijuegos de Constelación (uno por habilidad del octágono): contenido, claves y puntuación.

- Cada juego tiene contenido para primaria (5.º-6.º) y secundaria (1.º-3.º).
- Las claves (respuestas correctas, pesos) NUNCA se envían al navegador: `contenido_juego()` las elimina.
- Cada juego devuelve un puntaje 0-100 + un `detalle` que el docente puede revisar.
- Ningún juego tiene cronómetro: se mide el razonamiento, no la velocidad.
"""
import copy
import unicodedata

import catalogo as K

_CLAVES_PRIVADAS = {"correcta", "pesos", "pesos_e", "pesos_a", "orden"}

# --------------------------------------------------------------- Catálogo (para el panel del docente)
CATALOGO = [
    {"id": "ideas", "habilidad": "creatividad", "titulo": "Taller de ideas", "icono": "💡", "minutos": 6,
     "subtitulo": "¿Para qué más sirve? Inventa usos nuevos para objetos comunes.",
     "mide": "Fluidez (cuántas ideas distintas) y elaboración (ideas desarrolladas). No juzga si una idea es "
             "'buena' u original: el docente puede leer todas las ideas.",
     "accesibilidad": ["Se puede escribir o usar el dictado del teclado del dispositivo (la app no graba audio)",
                       "Sin tiempo límite", "Lectura en voz alta de la consigna"]},
    {"id": "patrones", "habilidad": "logico", "titulo": "Patrones secretos", "icono": "🧩", "minutos": 6,
     "subtitulo": "Descubre la regla de cada serie y elige lo que sigue.",
     "mide": "Razonamiento inductivo y deductivo en 6 reactivos de dificultad creciente.",
     "accesibilidad": ["Las series usan formas y números, nunca solo color", "Sin tiempo límite",
                       "Lectura en voz alta de la consigna"]},
    {"id": "mensaje", "habilidad": "comunicacion", "titulo": "Arma tu mensaje", "icono": "💬", "minutos": 7,
     "subtitulo": "Ordena las frases para que el mensaje sea claro y elige la mejor forma de decirlo.",
     "mide": "Organización de ideas (orden lógico de un mensaje) y elección de formas claras de comunicar.",
     "accesibilidad": ["Ordenar con toques o con teclado (flechas), sin arrastrar", "Sin tiempo límite",
                       "Lectura en voz alta de cada frase"]},
    {"id": "equipo", "habilidad": "colaboracion", "titulo": "Misión del equipo", "icono": "🤝", "minutos": 7,
     "subtitulo": "Tu equipo tiene una misión. Decide qué hacer en cada situación.",
     "mide": "Decisiones de colaboración en 5 situaciones de equipo (escuchar, repartir, incluir, reparar, reconocer).",
     "accesibilidad": ["Historia corta con apoyo en voz alta", "Sin tiempo límite",
                       "Las consecuencias se cuentan con palabras, no solo con color"]},
    {"id": "torres", "habilidad": "resolucion", "titulo": "Torres mágicas", "icono": "🗼", "minutos": 8,
     "subtitulo": "Mueve los discos a otra torre. ¡Piensa tus pasos antes de mover!",
     "mide": "Planeación y eficiencia al resolver un problema de varios pasos (Torre de Hanoi). Las pistas se "
             "pueden usar (máximo 3 por nivel) y restan un poco.",
     "accesibilidad": ["Se juega con toques o con teclado (teclas 1, 2 y 3)", "Cada disco tiene número y tamaño, no solo color",
                       "Botón de pista y de reiniciar; se puede saltar un nivel"]},
    {"id": "espejo", "habilidad": "autoconocimiento", "titulo": "Mi espejo", "icono": "🪞", "minutos": 8,
     "subtitulo": "Adivina cómo te irá, inténtalo y compara. Después elige tus cartas de fortalezas.",
     "mide": "Calibración: qué tan cerca está lo que el alumno predice de lo que logra (no importa acertar mucho). "
             "Las cartas de fortalezas y metas no se puntúan; se muestran al docente.",
     "accesibilidad": ["Sin tiempo límite", "Lectura en voz alta", "Escala de ánimo con caritas y palabras"]},
    {"id": "zapatos", "habilidad": "empatia", "titulo": "Ponte en sus zapatos", "icono": "👟", "minutos": 7,
     "subtitulo": "Conoce a cuatro personas, entiende cómo se sienten y decide cómo ayudar.",
     "mide": "Reconocimiento de emociones y toma de perspectiva en 4 situaciones escolares diversas.",
     "accesibilidad": ["Emociones con emoji y palabra", "Personajes diversos (lengua, discapacidad, situación familiar)",
                       "Lectura en voz alta de cada historia"]},
    {"id": "reglas", "habilidad": "adaptabilidad", "titulo": "Cambio de reglas", "icono": "🔁", "minutos": 5,
     "subtitulo": "Clasifica tarjetas… pero atento: ¡la regla puede cambiar!",
     "mide": "Flexibilidad cognitiva: precisión antes y después de que cambia la regla, y errores por seguir la regla anterior.",
     "accesibilidad": ["Cada tarjeta tiene color, forma y nombre escrito", "La regla vigente siempre está a la vista",
                       "Sin cronómetro; el aviso de cambio es visual y en texto"]},
]
JUEGOS = {j["id"]: j for j in CATALOGO}
for _j in CATALOGO:
    _j["habilidad_nombre"] = K.NOMBRE_HAB[_j["habilidad"]]


def _norm(txt):
    txt = unicodedata.normalize("NFD", str(txt).strip().lower())
    return " ".join("".join(c for c in txt if unicodedata.category(c) != "Mn").split())


# =============================================================== CONTENIDO
# ---------------------------------------------------------------- 1. Taller de ideas
_IDEAS = {
    "primaria": [("🧴", "una botella de plástico vacía"), ("📦", "una caja de cartón grande"), ("🧦", "un calcetín viejo")],
    "secundaria": [("☂️", "un paraguas roto"), ("🚲", "una llanta de bicicleta vieja"), ("📱", "un celular sin batería")],
}

# ---------------------------------------------------------------- 2. Patrones secretos
_PATRONES = {
    "primaria": [
        {"pregunta": "¿Qué figura sigue?", "secuencia": "🔺 🔵 🔺 🔵 🔺 ❓", "opciones": ["🔺", "🔵", "⭐", "⬛"], "correcta": 1},
        {"pregunta": "¿Qué número sigue?", "secuencia": "2 · 4 · 6 · 8 · ❓", "opciones": ["9", "10", "12", "14"], "correcta": 1},
        {"pregunta": "¿Qué figura sigue?", "secuencia": "⭐ ⭐ 🌙 ⭐ ⭐ 🌙 ⭐ ⭐ ❓", "opciones": ["⭐", "🌙", "☀️", "⬛"], "correcta": 1},
        {"pregunta": "¿Qué número sigue?", "secuencia": "3 · 6 · 12 · 24 · ❓", "opciones": ["30", "36", "48", "27"], "correcta": 2},
        {"pregunta": "¿Qué número sigue?", "secuencia": "1 · 4 · 9 · 16 · ❓", "opciones": ["20", "24", "25", "36"], "correcta": 2},
        {"pregunta": "Ana, Beto y Carla tienen una mascota cada uno: un perro, un gato y un pez. Pista 1: Ana no tiene gato ni pez. "
                     "Pista 2: Beto no tiene pez. ¿Quién tiene el pez?",
         "opciones": ["Ana", "Beto", "Carla"], "correcta": 2},
    ],
    "secundaria": [
        {"pregunta": "¿Qué número sigue?", "secuencia": "5 · 8 · 11 · 14 · ❓", "opciones": ["16", "17", "18", "20"], "correcta": 1},
        {"pregunta": "¿Qué número sigue?", "secuencia": "2 · 6 · 18 · 54 · ❓", "opciones": ["108", "148", "162", "72"], "correcta": 2},
        {"pregunta": "¿Qué número sigue?", "secuencia": "1 · 1 · 2 · 3 · 5 · 8 · ❓", "opciones": ["11", "12", "13", "16"], "correcta": 2},
        {"pregunta": "¿Qué letra sigue?", "secuencia": "A · B · D · G · ❓", "opciones": ["J", "K", "L", "M"], "correcta": 1},
        {"pregunta": "Todos los gatos son mamíferos. Algunos mamíferos viven en el agua. Luis tiene un gato. "
                     "¿Qué se puede asegurar?",
         "opciones": ["El gato de Luis es un mamífero", "El gato de Luis vive en el agua", "Luis tiene un pez",
                      "Todos los mamíferos son gatos"], "correcta": 0},
        {"pregunta": "Si 3 máquinas hacen 3 piezas en 3 minutos, ¿cuántos minutos tardan 100 máquinas en hacer 100 piezas?",
         "opciones": ["1", "3", "33", "100"], "correcta": 1},
    ],
}

# ---------------------------------------------------------------- 3. Arma tu mensaje
# "orden" = frases en el orden correcto; al navegador se envían barajadas con una permutación fija.
_MENSAJE = {
    "primaria": {
        "ordenar": [
            {"escenario": "Vas a enseñar las escondidillas a un compañero nuevo.",
             "orden": ["Hola, te voy a enseñar un juego que se llama las escondidillas.",
                       "Una persona cuenta hasta diez con los ojos cerrados mientras los demás se esconden.",
                       "Después busca a los demás; al primero que encuentre le toca contar la próxima vez.",
                       "¿Quedó claro? ¿Quieres que lo intentemos juntos?"], "perm": [2, 0, 3, 1]},
            {"escenario": "No entendiste un ejercicio y le pides ayuda a tu maestra.",
             "orden": ["Maestra, ¿tiene un momento, por favor?",
                       "No entendí el ejercicio 4 de la página 20.",
                       "Intenté sumar primero, pero el resultado no coincide.",
                       "¿Me podría explicar el primer paso?"], "perm": [3, 1, 0, 2]},
            {"escenario": "Le cuentas al grupo lo que hiciste el fin de semana.",
             "orden": ["Este fin de semana fui con mi familia al río.",
                       "Salimos temprano y caminamos casi una hora.",
                       "Lo mejor fue ver una garza volar muy cerca de nosotros.",
                       "Por eso quiero volver pronto."], "perm": [1, 3, 2, 0]},
        ],
        "items": [
            {"pregunta": "Tienes que explicar un juego nuevo a alguien. ¿Qué haces primero?",
             "opciones": ["Digo todas las reglas muy rápido para terminar pronto",
                          "Explico la idea general, doy un ejemplo y pregunto si quedó claro",
                          "Le digo que mejor me observe mientras jugamos",
                          "Le pido a otra persona que se lo explique"], "pesos": [0, 2, 1, 0]},
            {"pregunta": "Vas a presentar un tema frente al grupo. ¿Qué preparación ayuda más a que te entiendan?",
             "opciones": ["Memorizar cada palabra sin mirar a nadie",
                          "Ordenar mis ideas en tres puntos, usar ejemplos y mirar al grupo",
                          "Leer un texto largo en voz baja",
                          "Decir lo primero que se me ocurra"], "pesos": [0, 2, 0, 1]},
        ],
    },
    "secundaria": {
        "ordenar": [
            {"escenario": "Escribes al chat del grupo para organizar un trabajo en equipo.",
             "orden": ["Hola a todos, les escribo para organizar el trabajo de Historia.",
                       "Propongo que nos veamos el jueves a las 4 p. m. en la biblioteca para repartir secciones.",
                       "Cada quien puede traer lo que ya tenga investigado para ahorrar tiempo.",
                       "Si no pueden ese día, díganme hoy y buscamos otro horario."], "perm": [2, 0, 3, 1]},
            {"escenario": "Pides con respeto más tiempo para entregar una tarea.",
             "orden": ["Maestro, buenas tardes. Quisiera pedirle un favor sobre el proyecto de Ciencias.",
                       "Esta semana mi familia tuvo una emergencia y no pude terminarlo.",
                       "Ya llevo la mitad y puedo entregarlo completo el lunes.",
                       "Agradezco mucho su comprensión."], "perm": [3, 1, 0, 2]},
            {"escenario": "Defiendes una opinión en un debate de clase.",
             "orden": ["Creo que el celular debería poder usarse en clase, solo para actividades de aprendizaje.",
                       "La razón es que permite buscar información al momento y trabajar con aplicaciones educativas.",
                       "Por ejemplo, en la clase pasada resolvimos una duda en dos minutos con un diccionario digital.",
                       "Por eso propongo reglas claras de uso en lugar de una prohibición total."], "perm": [1, 3, 2, 0]},
            {"escenario": "Le das retroalimentación a un compañero sobre su exposición.",
             "orden": ["Me gustó mucho tu ejemplo del volcán; ayudó a entender el tema.",
                       "Algo que podría mejorar es la diapositiva final, que tenía mucho texto.",
                       "Quizá podrías dejar solo tres ideas y explicarlas hablando.",
                       "Gracias por dejarme opinar; creo que te quedó muy bien."], "perm": [2, 0, 3, 1]},
        ],
        "items": [
            {"pregunta": "Debes explicar un tema difícil a un compañero que no lo entendió. ¿Qué haces?",
             "opciones": ["Repito lo mismo, pero más fuerte y más rápido",
                          "Pregunto qué parte no entendió, lo explico con otro ejemplo y verifico que quedó claro",
                          "Le paso mis apuntes y ya",
                          "Le digo que le pregunte al maestro"], "pesos": [0, 2, 1, 0]},
            {"pregunta": "Vas a exponer frente al grupo. ¿Qué ayuda más a que te entiendan?",
             "opciones": ["Leer las diapositivas tal como están",
                          "Tener un hilo claro (inicio, desarrollo, cierre), usar ejemplos y mirar al público",
                          "Hablar rápido para que no se aburran",
                          "Improvisar todo para parecer natural"], "pesos": [0, 2, 0, 1]},
        ],
    },
}

# ---------------------------------------------------------------- 4. Misión del equipo
_EQUIPO = {
    "primaria": {
        "titulo": "La feria del huerto",
        "intro": "Tu equipo (Lupe, Omar, Sam y tú) presentará un huerto escolar en la feria de la escuela.",
        "pasos": [
            {"situacion": "Tienen que decidir qué sembrar. Lupe quiere jitomates, Omar quiere flores y no se ponen de acuerdo.",
             "opciones": [
                 {"texto": "Voto por lo que yo quiero.", "consecuencia": "Se decide rápido, pero Lupe y Omar se quedan molestos."},
                 {"texto": "Propongo que cada quien explique sus razones y sembremos un poco de cada cosa.", "consecuencia": "Todos se sienten escuchados y el huerto queda más bonito."},
                 {"texto": "Los dejo decidir; yo no opino.", "consecuencia": "Al final deciden entre los dos, pero tu idea no se escuchó."},
                 {"texto": "Le pido a la maestra que elija.", "consecuencia": "La maestra elige, aunque habría sido bueno intentarlo entre ustedes."}],
             "pesos": [0, 2, 1, 1]},
            {"situacion": "Hay que repartir tareas: regar, hacer el cartel, explicar al público y traer materiales.",
             "opciones": [
                 {"texto": "Me quedo con la tarea más fácil.", "consecuencia": "A los demás les toca más trabajo y se cansan."},
                 {"texto": "Preguntamos a cada quien qué le gusta o qué hace mejor, y vamos rotando las tareas.", "consecuencia": "Cada quien se siente útil y aprenden cosas distintas."},
                 {"texto": "Hago todo yo para que quede perfecto.", "consecuencia": "Terminas agotado y los demás sienten que no los necesitabas."},
                 {"texto": "Repartimos al azar y no se cambia.", "consecuencia": "Se reparte rápido, aunque a alguien le toca algo que no se le da."}],
             "pesos": [0, 2, 0, 1]},
            {"situacion": "Sam casi no ha participado y se ve desanimado.",
             "opciones": [
                 {"texto": "Le pregunto qué le gustaría hacer y le propongo una tarea que pueda lograr.", "consecuencia": "Sam sonríe y se anima a ayudar con el cartel."},
                 {"texto": "Hago su parte para terminar rápido.", "consecuencia": "Terminan más rápido, pero Sam se siente aún más fuera."},
                 {"texto": "Lo dejo; es su problema.", "consecuencia": "Sam sigue solo y el equipo pierde su ayuda."},
                 {"texto": "Aviso a la maestra de inmediato.", "consecuencia": "La maestra habla con Sam, aunque quizá él habría preferido que primero se lo preguntaran."}],
             "pesos": [2, 0, 0, 1]},
            {"situacion": "El día antes de la feria, a Omar se le rompe el cartel por accidente.",
             "opciones": [
                 {"texto": "Le digo que fue su culpa.", "consecuencia": "Omar se siente muy mal y deja de querer participar."},
                 {"texto": "Lo ayudo a rehacerlo entre todos.", "consecuencia": "Con cuatro pares de manos el cartel queda listo y hasta mejor."},
                 {"texto": "Hacemos otro rápido sin él.", "consecuencia": "El cartel queda, pero Omar se siente excluido."},
                 {"texto": "Mejor no presentamos.", "consecuencia": "Se pierde el trabajo de todo el equipo."}],
             "pesos": [0, 2, 1, 0]},
            {"situacion": "La feria salió muy bien y la maestra felicita al equipo. ¿Qué haces?",
             "opciones": [
                 {"texto": "Digo que la mayor parte fue mía.", "consecuencia": "Los demás se sienten ignorados."},
                 {"texto": "Reconozco lo que cada quien aportó.", "consecuencia": "Todos se sienten orgullosos y quieren volver a trabajar juntos."},
                 {"texto": "No digo nada.", "consecuencia": "La maestra no se entera de lo que cada uno hizo."},
                 {"texto": "Digo que lo que faltó fue culpa de Sam.", "consecuencia": "Sam se siente mal y el equipo se enfría."}],
             "pesos": [0, 2, 1, 0]},
        ],
    },
    "secundaria": {
        "titulo": "Proyecto para la feria de ciencias",
        "intro": "Tu equipo (Mar, Iván, Sam y tú) prepara un proyecto sobre energías limpias para la feria de ciencias.",
        "pasos": [
            {"situacion": "Mar propone hacer un modelo con paneles solares; Iván prefiere un video. Empiezan a discutir en el chat.",
             "opciones": [
                 {"texto": "Me uno a quien me cae mejor.", "consecuencia": "Se decide, pero queda un ambiente tenso."},
                 {"texto": "Propongo escuchar las dos ideas y combinarlas: modelo en la feria y video corto para explicarlo.", "consecuencia": "Los dos sienten que su idea cuenta y el proyecto crece."},
                 {"texto": "Salgo del chat para no meterme en problemas.", "consecuencia": "La discusión se alarga y nadie decide."},
                 {"texto": "Pido al profesor que decida.", "consecuencia": "El profesor decide, aunque podrían haberlo resuelto ustedes."}],
             "pesos": [0, 2, 0, 1]},
            {"situacion": "Hay que dividir el trabajo y todos tienen exámenes la próxima semana.",
             "opciones": [
                 {"texto": "Elijo las tareas que más me convienen.", "consecuencia": "A alguien le toca más de lo que puede."},
                 {"texto": "Hacemos una tabla con tareas, tiempos y quién puede qué, y la revisamos cada quien.", "consecuencia": "El trabajo queda parejo y cada quien sabe qué entregar."},
                 {"texto": "Que lo haga quien tenga más tiempo.", "consecuencia": "Se agiliza, pero una persona carga con todo."},
                 {"texto": "Lo dejamos para después.", "consecuencia": "El tiempo se acaba y todo queda a última hora."}],
             "pesos": [0, 2, 1, 0]},
            {"situacion": "Sam casi no responde en el chat y no ha entregado su parte.",
             "opciones": [
                 {"texto": "Le escribo en privado para preguntar si necesita ayuda y propongo una tarea más pequeña.", "consecuencia": "Sam cuenta que tiene problemas en casa y retoma una tarea que sí puede hacer."},
                 {"texto": "Hago su parte sin decir nada.", "consecuencia": "Se cumple la fecha, pero acumulas cansancio y resentimiento."},
                 {"texto": "Lo exhibo en el chat del grupo.", "consecuencia": "Sam se siente avergonzado y deja de contestar."},
                 {"texto": "Aviso al profesor.", "consecuencia": "El profesor interviene; habría ayudado hablar antes con Sam."}],
             "pesos": [2, 0, 0, 1]},
            {"situacion": "El día anterior se descubre que el modelo no funciona como esperaban.",
             "opciones": [
                 {"texto": "Culpo a quien armó esa parte.", "consecuencia": "Se pierde tiempo discutiendo."},
                 {"texto": "Propongo que juntos revisemos qué falló y repartamos cómo arreglarlo.", "consecuencia": "Encuentran el error en una hora y lo corrigen entre todos."},
                 {"texto": "Presentamos así y que salga lo que salga.", "consecuencia": "El proyecto se presenta con una falla evidente."},
                 {"texto": "Lo arreglo yo solo esa noche.", "consecuencia": "Funciona, pero te desvelas y el equipo no aprende qué falló."}],
             "pesos": [0, 2, 0, 1]},
            {"situacion": "Reciben un reconocimiento por el proyecto. Te piden decir unas palabras.",
             "opciones": [
                 {"texto": "Agradezco solo a quien más hizo.", "consecuencia": "Los demás sienten que su esfuerzo no se vio."},
                 {"texto": "Menciono lo que aportó cada integrante, incluida la ayuda de Sam al final.", "consecuencia": "El equipo se siente valorado y celebra junto."},
                 {"texto": "Prefiero no hablar.", "consecuencia": "El reconocimiento pasa sin que se destaque a nadie."},
                 {"texto": "Hablo de mis ideas, porque fueron las mejores.", "consecuencia": "El ambiente se enfría y el equipo no lo disfruta."}],
             "pesos": [1, 2, 1, 0]},
        ],
    },
}

# ---------------------------------------------------------------- 5. Torres mágicas
_TORRES = {"primaria": [3, 4], "secundaria": [4, 5]}
_TORRES_PESO = [0.4, 0.6]
PISTAS_MAX = 3

# ---------------------------------------------------------------- 6. Mi espejo
_ESPEJO = {
    "primaria": [
        {"tema": "Números", "icono": "🔢", "preguntas": [
            {"pregunta": "8 + 7 = ?", "opciones": ["13", "14", "15", "16"], "correcta": 2},
            {"pregunta": "6 × 4 = ?", "opciones": ["20", "24", "26", "28"], "correcta": 1},
            {"pregunta": "50 − 18 = ?", "opciones": ["28", "32", "38", "42"], "correcta": 1}]},
        {"tema": "Palabras", "icono": "📖", "preguntas": [
            {"pregunta": "¿Qué palabra significa lo mismo que «contento»?", "opciones": ["triste", "alegre", "enojado", "cansado"], "correcta": 1},
            {"pregunta": "¿Cuál palabra NO es un animal?", "opciones": ["gato", "perro", "mesa", "caballo"], "correcta": 2},
            {"pregunta": "¿Cuál es lo contrario de «abrir»?", "opciones": ["cerrar", "mover", "pegar", "romper"], "correcta": 0}]},
        {"tema": "Figuras", "icono": "🔷", "preguntas": [
            {"pregunta": "¿Cuántos lados tiene un hexágono?", "opciones": ["5", "6", "7", "8"], "correcta": 1},
            {"pregunta": "¿Qué figura tiene 3 lados?", "opciones": ["cuadrado", "triángulo", "círculo", "rombo"], "correcta": 1},
            {"pregunta": "¿Cuántas esquinas (vértices) tiene un cubo?", "opciones": ["6", "8", "10", "12"], "correcta": 1}]},
    ],
    "secundaria": [
        {"tema": "Números", "icono": "🔢", "preguntas": [
            {"pregunta": "¿Cuánto es el 15 % de 200?", "opciones": ["15", "20", "30", "40"], "correcta": 2},
            {"pregunta": "3/4 + 1/2 = ?", "opciones": ["4/6", "5/4", "1", "7/8"], "correcta": 1},
            {"pregunta": "−5 + (−7) = ?", "opciones": ["−2", "2", "−12", "12"], "correcta": 2}]},
        {"tema": "Palabras y razones", "icono": "📖", "preguntas": [
            {"pregunta": "«Efímero» significa:", "opciones": ["eterno", "breve", "enorme", "antiguo"], "correcta": 1},
            {"pregunta": "¿Cuál es lo contrario de «escaso»?", "opciones": ["raro", "abundante", "pobre", "limitado"], "correcta": 1},
            {"pregunta": "Si todos los A son B y todos los B son C, entonces:", "opciones": ["todos los A son C", "todos los C son A", "ningún A es C", "algunos C no son B"], "correcta": 0}]},
        {"tema": "Ciencias", "icono": "🔬", "preguntas": [
            {"pregunta": "¿Qué gas toman las plantas para la fotosíntesis?", "opciones": ["oxígeno", "dióxido de carbono", "nitrógeno", "helio"], "correcta": 1},
            {"pregunta": "¿Cuál es el planeta más cercano al Sol?", "opciones": ["Venus", "Mercurio", "Marte", "Tierra"], "correcta": 1},
            {"pregunta": "El agua hierve a ___ °C al nivel del mar.", "opciones": ["90", "100", "120", "80"], "correcta": 1}]},
    ],
}
ANIMOS = [{"valor": 1, "emoji": "😞", "texto": "Mal"}, {"valor": 2, "emoji": "😕", "texto": "Regular"},
          {"valor": 3, "emoji": "🙂", "texto": "Bien"}, {"valor": 4, "emoji": "😄", "texto": "Muy bien"},
          {"valor": 5, "emoji": "🤩", "texto": "Genial"}]

# ---------------------------------------------------------------- 7. Ponte en sus zapatos
_EMO = {"triste": ("😢", "Triste"), "solo": ("😔", "Solo(a) e inseguro(a)"), "enojo": ("😠", "Enojado(a)"),
        "feliz": ("😄", "Contento(a)"), "preocupado": ("😟", "Preocupado(a)"), "verguenza": ("😳", "Con vergüenza"),
        "excluido": ("🥺", "Excluido(a)"), "orgullo": ("😎", "Orgulloso(a) de lo que pasó"),
        "cansado": ("😮‍💨", "Cansado(a)"), "indiferente": ("😐", "Le da igual")}


def _esc(persona, emoji, historia, emos, pesos_e, acciones, pesos_a):
    return {"persona": {"nombre": persona, "emoji": emoji}, "historia": historia,
            "emociones": [{"emoji": _EMO[e][0], "texto": _EMO[e][1]} for e in emos], "pesos_e": pesos_e,
            "acciones": acciones, "pesos_a": pesos_a}


_ZAPATOS = {
    "primaria": [
        _esc("Itzel", "👧🏽", "Itzel llegó hace una semana a la escuela. En su casa habla maya y todavía está aprendiendo español. "
             "En el recreo se sienta sola.", ["feliz", "solo", "enojo", "preocupado"], [0, 2, 0, 1],
             ["La dejo sola; seguro así le gusta.", "La invito a jugar y le explico el juego con palabras sencillas y gestos.",
              "Le pido a la maestra que ya no esté en nuestro salón.", "La invito una vez y, si no habla, ya no insisto."], [0, 2, 0, 1]),
        _esc("Mateo", "🧒🏻", "Mateo usa silla de ruedas. Hoy en educación física el juego será en una cancha con escalones y Mateo se queda mirando desde afuera.",
             ["feliz", "excluido", "orgullo", "cansado"], [0, 2, 0, 1],
             ["Cambiamos el juego o el lugar para que todos podamos participar.", "Le digo que se quede mirando; así está bien.",
              "Lo dejo de árbitro sin preguntarle si quiere.", "No hago nada."], [2, 0, 1, 0]),
        _esc("Camila", "👧🏻", "Los equipos ya se formaron para el trabajo de Ciencias y a Camila no la eligieron.",
             ["triste", "feliz", "enojo", "indiferente"], [2, 0, 1, 0],
             ["Le pregunto si quiere unirse a mi equipo y hago un lugar.", "Me río con los demás.",
              "No digo nada para no meterme en problemas.", "Le digo que se queje con la maestra."], [2, 0, 1, 0]),
        _esc("Daniel", "👦🏽", "Daniel llegó tarde otra vez porque ayuda a su familia en el puesto del mercado antes de ir a la escuela. Algunos se ríen de él.",
             ["verguenza", "orgullo", "enojo", "feliz"], [2, 0, 1, 0],
             ["Me río también para que no se burlen de mí.", "Le pregunto cómo está y le ofrezco los apuntes que se perdió.",
              "No digo nada, pero no me burlo.", "Le digo que ya no llegue tarde."], [0, 2, 1, 0]),
    ],
    "secundaria": [
        _esc("Rodrigo", "👦🏽", "Rodrigo dejó de hablar en el chat del grupo después de que varios se burlaron de una foto suya.",
             ["feliz", "verguenza", "indiferente", "enojo"], [0, 2, 0, 1],
             ["Le escribo en privado para preguntar cómo está y dejo claro que no estuvo bien lo que pasó.", "Ignoro el tema; ya se le pasará.",
              "Comparto la foto para que vean que no es tan grave.", "Le digo que no se tome las cosas tan a pecho."], [2, 0, 0, 1]),
        _esc("Fernanda", "👧🏻", "Fernanda sabe que su familia pasa por problemas de dinero. Hoy no llevó almuerzo y dice que no tiene hambre.",
             ["preocupado", "feliz", "enojo", "cansado"], [2, 0, 1, 1],
             ["Pregunto en voz alta por qué no come.", "Le ofrezco compartir mi almuerzo de forma natural, sin hacer un tema de eso.",
              "Aviso a todo el grupo para que le ayuden.", "No hago nada porque no es mi asunto."], [0, 2, 0, 0]),
        _esc("Emiliano", "🧑🏽", "Emiliano tiene dislexia. Al leer en voz alta se equivoca varias veces y algunos se ríen.",
             ["verguenza", "feliz", "orgullo", "indiferente"], [2, 0, 0, 0],
             ["Me río también, es un momento incómodo.", "Digo que no es gracioso y, después, le ofrezco leer juntos o ayudarle a practicar.",
              "Corrijo cada error en voz alta.", "Me quedo callado."], [0, 2, 0, 1]),
        _esc("Sam", "🧑🏻", "Sam acaba de mudarse de otra ciudad y no conoce a nadie. En el trabajo en equipo nadie le pide participar.",
             ["solo", "feliz", "indiferente", "enojo"], [2, 0, 0, 1],
             ["Lo invito a mi equipo y le explico cómo vamos.", "Espero a que alguien más lo haga.",
              "Le digo que se integre solo.", "Pido que lo pasen a otro grupo."], [2, 1, 0, 0]),
    ],
}

# ---------------------------------------------------------------- 8. Cambio de reglas
_REGLAS = {
    "primaria": [("color", 6), ("forma", 8), ("color", 6)],
    "secundaria": [("color", 8), ("forma", 10), ("color", 8)],
}
_PESO_FASES = [0.2, 0.5, 0.3]


# =============================================================== API: contenido público
def _limpiar(obj):
    if isinstance(obj, dict):
        return {k: _limpiar(v) for k, v in obj.items() if k not in _CLAVES_PRIVADAS}
    if isinstance(obj, list):
        return [_limpiar(v) for v in obj]
    return obj


def contenido_juego(jid, nivel):
    """Contenido de un juego para el navegador, sin claves ni pesos."""
    if jid not in JUEGOS or nivel not in K.NIVELES:
        raise KeyError(jid)
    if jid == "ideas":
        return {"tipo": "ideas", "maxIdeas": 6, "rondas": [{"icono": i, "objeto": o} for i, o in _IDEAS[nivel]]}
    if jid == "patrones":
        return {"tipo": "patrones", "items": _limpiar(copy.deepcopy(_PATRONES[nivel]))}
    if jid == "mensaje":
        d = _MENSAJE[nivel]
        ordenar = []
        for r in d["ordenar"]:
            tarjetas = [{"id": p, "texto": r["orden"][p]} for p in r["perm"]]
            ordenar.append({"escenario": r["escenario"], "tarjetas": tarjetas})
        return {"tipo": "mensaje", "ordenar": ordenar, "items": _limpiar(copy.deepcopy(d["items"]))}
    if jid == "equipo":
        return {"tipo": "equipo", **_limpiar(copy.deepcopy(_EQUIPO[nivel]))}
    if jid == "torres":
        return {"tipo": "torres", "niveles": _TORRES[nivel], "pistasMax": PISTAS_MAX}
    if jid == "espejo":
        return {"tipo": "espejo", "rondas": _limpiar(copy.deepcopy(_ESPEJO[nivel])), "animos": ANIMOS,
                "fortalezas": [{"id": h["id"], "nombre": h["nombre"], "icono": h["icono"], "frase": h["frase"]}
                               for h in K.HABILIDADES]}
    if jid == "zapatos":
        return {"tipo": "zapatos", "escenarios": _limpiar(copy.deepcopy(_ZAPATOS[nivel]))}
    if jid == "reglas":
        return {"tipo": "reglas", "fases": [{"regla": r, "ensayos": n} for r, n in _REGLAS[nivel]]}
    raise KeyError(jid)


# =============================================================== API: puntuación
def _entero(v, lo, hi, msg="Respuesta inválida"):
    if isinstance(v, bool) or not isinstance(v, int) or not lo <= v <= hi:
        raise ValueError(msg)
    return v


def _lista(v, n, msg="Número de respuestas incorrecto"):
    if not isinstance(v, list) or len(v) != n:
        raise ValueError(msg)
    return v


def puntuar_juego(jid, nivel, datos):
    """Devuelve (puntaje 0-100, detalle dict). Lanza ValueError si el formato es inválido."""
    if jid not in JUEGOS or nivel not in K.NIVELES:
        raise ValueError("Juego inválido")
    if not isinstance(datos, dict):
        raise ValueError("Datos inválidos")
    return _PUNTUAR[jid](nivel, datos)


def _p_ideas(nivel, datos):
    rondas = _lista(datos.get("rondas"), len(_IDEAS[nivel]))
    puntos, detalle = [], []
    for (_, objeto), lista in zip(_IDEAS[nivel], rondas):
        if not isinstance(lista, list):
            raise ValueError("Lista inválida")
        ideas, vistas = [], set()
        for t in lista[:6]:
            t = str(t).strip()[:120]
            clave = _norm(t)
            letras = {c for c in clave if c.isalpha()}
            if len(clave) >= 3 and len(letras) >= 3 and clave not in vistas:
                vistas.add(clave)
                ideas.append(t)
        elaboradas = sum(1 for t in ideas if len(t.split()) >= 3)
        puntos.append(100 * (0.7 * min(len(ideas), 6) / 6 + 0.3 * min(elaboradas, 3) / 3))
        detalle.append({"objeto": objeto, "ideas": ideas, "elaboradas": elaboradas})
    return round(sum(puntos) / len(puntos)), {"rondas": detalle}


def _p_patrones(nivel, datos):
    items = _PATRONES[nivel]
    resp = _lista(datos.get("respuestas"), len(items))
    aciertos = 0
    for it, r in zip(items, resp):
        aciertos += _entero(r, 0, len(it["opciones"]) - 1) == it["correcta"]
    return round(100 * aciertos / len(items)), {"aciertos": aciertos, "total": len(items)}


def _p_mensaje(nivel, datos):
    d = _MENSAJE[nivel]
    ordenes = _lista(datos.get("ordenes"), len(d["ordenar"]))
    parciales = []
    for r, orden in zip(d["ordenar"], ordenes):
        n = len(r["orden"])
        if not isinstance(orden, list) or sorted(orden) != list(range(n)):
            raise ValueError("Orden inválido")
        pares = [(i, j) for i in range(n) for j in range(i + 1, n)]
        parciales.append(sum(1 for i, j in pares if orden[i] < orden[j]) / len(pares))
    resp = _lista(datos.get("items"), len(d["items"]))
    suma = sum(it["pesos"][_entero(r, 0, len(it["opciones"]) - 1)] for it, r in zip(d["items"], resp))
    maximo = sum(max(it["pesos"]) for it in d["items"])
    puntaje = 100 * (0.6 * sum(parciales) / len(parciales) + 0.4 * suma / maximo)
    return round(puntaje), {"orden_promedio": round(100 * sum(parciales) / len(parciales)),
                            "situaciones": f"{suma} de {maximo}"}


def _p_equipo(nivel, datos):
    pasos = _EQUIPO[nivel]["pasos"]
    resp = _lista(datos.get("respuestas"), len(pasos))
    suma = sum(p["pesos"][_entero(r, 0, len(p["opciones"]) - 1)] for p, r in zip(pasos, resp))
    maximo = sum(max(p["pesos"]) for p in pasos)
    elegidas = [p["opciones"][r]["texto"] for p, r in zip(pasos, resp)]
    return round(100 * suma / maximo), {"puntos": f"{suma} de {maximo}", "decisiones": elegidas}


def _optimo(n):
    return 2 ** n - 1


def _p_torres(nivel, datos):
    niveles = _lista(datos.get("niveles"), len(_TORRES[nivel]))
    total, detalle = 0.0, []
    for discos, peso, r in zip(_TORRES[nivel], _TORRES_PESO, niveles):
        if not isinstance(r, dict) or r.get("discos") != discos:
            raise ValueError("Nivel inválido")
        resuelto = r.get("resuelto") is True
        mov = _entero(r.get("movimientos"), 0, 5000, "Movimientos inválidos")
        pistas = _entero(r.get("pistas"), 0, PISTAS_MAX, "Pistas inválidas")
        opt = _optimo(discos)
        if resuelto:
            if mov < opt:
                raise ValueError("Movimientos inválidos")
            efic = opt / mov
            pt = max(0.0, 40 + 60 * efic - 5 * pistas)
        else:
            pt = 0.0
        total += peso * pt
        detalle.append({"discos": discos, "resuelto": resuelto, "movimientos": mov, "optimo": opt, "pistas": pistas})
    return round(total), {"niveles": detalle}


def corregir_ronda_espejo(nivel, ronda, respuestas):
    """Califica UNA ronda de «Mi espejo» para mostrar «predijiste X, lograste Y» (no guarda nada).
    Devuelve (aciertos, total). Mantiene las respuestas correctas solo en el servidor."""
    rondas = _ESPEJO[nivel]
    ronda = _entero(ronda, 0, len(rondas) - 1, "Ronda inválida")
    preguntas = rondas[ronda]["preguntas"]
    respuestas = _lista(respuestas, len(preguntas))
    aciertos = sum(1 for q, r in zip(preguntas, respuestas) if _entero(r, 0, len(q["opciones"]) - 1) == q["correcta"])
    return aciertos, len(preguntas)


def _p_espejo(nivel, datos):
    rondas = _ESPEJO[nivel]
    pred = _lista(datos.get("predicciones"), len(rondas))
    resp = _lista(datos.get("respuestas"), len(rondas))
    difs, detalle = [], []
    for ronda, p, rs in zip(rondas, pred, resp):
        p = _entero(p, 0, len(ronda["preguntas"]))
        rs = _lista(rs, len(ronda["preguntas"]))
        real = sum(1 for q, r in zip(ronda["preguntas"], rs) if _entero(r, 0, len(q["opciones"]) - 1) == q["correcta"])
        difs.append(abs(p - real) / len(ronda["preguntas"]))
        detalle.append({"tema": ronda["tema"], "predijo": p, "logro": real})
    metas = datos.get("metas") if isinstance(datos.get("metas"), dict) else {}
    ids = set(K.HAB)
    fort = [f for f in (metas.get("fortalezas") or []) if f in ids][:3] if isinstance(metas.get("fortalezas"), list) else []
    mejorar = metas.get("mejorar") if metas.get("mejorar") in ids else None
    apoyo = str(metas.get("apoyo", "")).strip()[:160]
    animo = metas.get("animo") if isinstance(metas.get("animo"), int) and 1 <= metas.get("animo") <= 5 else None
    puntaje = round(100 * (1 - sum(difs) / len(difs)))
    return puntaje, {"rondas": detalle, "fortalezas": fort, "mejorar": mejorar, "apoyo": apoyo, "animo": animo}


def _p_zapatos(nivel, datos):
    esc = _ZAPATOS[nivel]
    resp = _lista(datos.get("respuestas"), len(esc))
    suma = maximo = 0
    for e, r in zip(esc, resp):
        if not isinstance(r, dict):
            raise ValueError("Respuesta inválida")
        suma += e["pesos_e"][_entero(r.get("e"), 0, len(e["emociones"]) - 1)]
        suma += e["pesos_a"][_entero(r.get("a"), 0, len(e["acciones"]) - 1)]
        maximo += max(e["pesos_e"]) + max(e["pesos_a"])
    return round(100 * suma / maximo), {"puntos": f"{suma} de {maximo}"}


def _p_reglas(nivel, datos):
    cfg = _REGLAS[nivel]
    fases = _lista(datos.get("fases"), len(cfg))
    acc, detalle = [], []
    for (regla, total), f, peso in zip(cfg, fases, _PESO_FASES):
        if not isinstance(f, dict) or f.get("regla") != regla:
            raise ValueError("Fase inválida")
        aciertos = _entero(f.get("aciertos"), 0, total)
        pers = _entero(f.get("perseveraciones", 0), 0, total)
        if pers > total - aciertos:
            raise ValueError("Datos inconsistentes")
        acc.append(aciertos / total)
        detalle.append({"regla": regla, "aciertos": aciertos, "total": total, "perseveraciones": pers})
    puntaje = 100 * sum(a * p for a, p in zip(acc, _PESO_FASES))
    return round(puntaje), {"fases": detalle}


_PUNTUAR = {"ideas": _p_ideas, "patrones": _p_patrones, "mensaje": _p_mensaje, "equipo": _p_equipo,
            "torres": _p_torres, "espejo": _p_espejo, "zapatos": _p_zapatos, "reglas": _p_reglas}
