# -*- coding: utf-8 -*-
"""Crea la base de datos MySQL/MariaDB ejecutando schema.sql (solo si usas DB_ENGINE=mysql).
Con SQLite (por defecto) NO hace falta: las tablas se crean solas la primera vez."""
import os
import re
import sys

from dotenv_lite import cargar_env

cargar_env()


def main():
    import pymysql

    ruta = os.path.join(os.path.dirname(os.path.abspath(__file__)), "schema.sql")
    with open(ruta, encoding="utf-8") as f:
        sql = f.read()
    sql = re.sub(r"--.*", "", sql)  # quita comentarios
    sentencias = [s.strip() for s in sql.split(";") if s.strip()]
    conn = pymysql.connect(
        host=os.getenv("DB_HOST", "127.0.0.1"), port=int(os.getenv("DB_PORT", "3306")),
        user=os.getenv("DB_ADMIN_USER", os.getenv("DB_USER", "root")),
        password=os.getenv("DB_ADMIN_PASSWORD", os.getenv("DB_PASSWORD", "")), charset="utf8mb4", autocommit=True)
    with conn.cursor() as cur:
        for s in sentencias:
            cur.execute(s)
    conn.close()
    print("Base de datos 'constelacion_v2' creada correctamente.")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:  # noqa: BLE001
        print("No se pudo crear la base de datos:", exc)
        sys.exit(1)
