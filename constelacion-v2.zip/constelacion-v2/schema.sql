-- =====================================================================
--  Constelación v2 · Esquema de base de datos (MySQL 5.7+ / MariaDB 10.3+)
--  Solo se necesita si usas MySQL (DB_ENGINE=mysql). Con SQLite (por defecto) las tablas se crean solas.
--  Ejecutar:   mysql -u root -p < schema.sql     o bien:   python init_db.py
-- =====================================================================

CREATE DATABASE IF NOT EXISTS constelacion_v2
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE constelacion_v2;

-- Docentes que se registran en la plataforma
CREATE TABLE IF NOT EXISTS docentes (
  id            INT UNSIGNED NOT NULL AUTO_INCREMENT,
  nombre        VARCHAR(120) NOT NULL,
  correo        VARCHAR(160) NOT NULL,
  escuela       VARCHAR(160) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  creado_en     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_docentes_correo (correo)
) ENGINE=InnoDB;

-- Clases (grupos) de cada docente: p. ej. «5.º A» de primaria, «2.º B» de secundaria
CREATE TABLE IF NOT EXISTS clases (
  id         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  docente_id INT UNSIGNED NOT NULL,
  nombre     VARCHAR(60)  NOT NULL,
  nivel      ENUM('primaria','secundaria') NOT NULL,
  grado      TINYINT UNSIGNED NOT NULL,          -- primaria: 5-6 · secundaria: 1-3
  ciclo      VARCHAR(20)  NULL,                  -- p. ej. 2026-2027
  creado_en  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_clases_docente (docente_id),
  CONSTRAINT fk_clases_docente FOREIGN KEY (docente_id)
    REFERENCES docentes (id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Alumnos: cada uno pertenece a una clase
CREATE TABLE IF NOT EXISTS alumnos (
  id               INT UNSIGNED NOT NULL AUTO_INCREMENT,
  docente_id       INT UNSIGNED NOT NULL,
  clase_id         INT UNSIGNED NOT NULL,
  nombre           VARCHAR(160) NOT NULL,
  edad             TINYINT UNSIGNED NULL,
  genero           VARCHAR(30)  NULL,             -- opcional
  matricula        VARCHAR(30)  NULL,             -- opcional; única dentro de la clase
  consentimiento   TINYINT(1)   NOT NULL DEFAULT 0, -- consentimiento de madre/padre/tutor
  accesibilidad_json TEXT       NULL,             -- ajustes de acceso (voz, texto grande, etc.)
  notas_docente    TEXT         NULL,             -- observaciones del docente (van en el PDF)
  creado_en        DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_alumno_clase_matricula (clase_id, matricula),
  KEY idx_alumnos_docente (docente_id),
  KEY idx_alumnos_clase (clase_id),
  CONSTRAINT fk_alumnos_docente FOREIGN KEY (docente_id) REFERENCES docentes (id) ON DELETE CASCADE,
  CONSTRAINT fk_alumnos_clase FOREIGN KEY (clase_id) REFERENCES clases (id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Test inicial (estilo de aprendizaje + autopercepción + intereses)
CREATE TABLE IF NOT EXISTS evaluaciones (
  id             INT UNSIGNED NOT NULL AUTO_INCREMENT,
  alumno_id      INT UNSIGNED NOT NULL,
  estado         ENUM('en_curso','completada') NOT NULL DEFAULT 'en_curso',
  resultado_json MEDIUMTEXT NULL,
  creado_en      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  completada_en  DATETIME NULL DEFAULT NULL,
  PRIMARY KEY (id),
  KEY idx_evaluaciones_alumno (alumno_id),
  CONSTRAINT fk_evaluaciones_alumno FOREIGN KEY (alumno_id) REFERENCES alumnos (id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Minijuegos asignados por el docente
CREATE TABLE IF NOT EXISTS asignaciones (
  id            INT UNSIGNED NOT NULL AUTO_INCREMENT,
  alumno_id     INT UNSIGNED NOT NULL,
  juego_id      VARCHAR(20)  NOT NULL,
  estado        ENUM('pendiente','completada') NOT NULL DEFAULT 'pendiente',
  asignada_en   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  completada_en DATETIME NULL DEFAULT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_asignacion (alumno_id, juego_id),
  CONSTRAINT fk_asignaciones_alumno FOREIGN KEY (alumno_id) REFERENCES alumnos (id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Cada vez que un alumno juega un minijuego se guarda una partida (se usa la más reciente)
CREATE TABLE IF NOT EXISTS partidas (
  id           INT UNSIGNED NOT NULL AUTO_INCREMENT,
  alumno_id    INT UNSIGNED NOT NULL,
  juego_id     VARCHAR(20)  NOT NULL,
  puntaje      TINYINT UNSIGNED NOT NULL,          -- 0-100
  detalle_json MEDIUMTEXT NULL,
  creada_en    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_partidas_alumno (alumno_id, juego_id),
  CONSTRAINT fk_partidas_alumno FOREIGN KEY (alumno_id) REFERENCES alumnos (id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- (Opcional) Usuario dedicado para la aplicación. Cambia la contraseña.
-- ---------------------------------------------------------------------
-- CREATE USER IF NOT EXISTS 'constelacion'@'localhost' IDENTIFIED BY 'CAMBIA_ESTA_CLAVE';
-- GRANT SELECT, INSERT, UPDATE, DELETE ON constelacion_v2.* TO 'constelacion'@'localhost';
-- FLUSH PRIVILEGES;
