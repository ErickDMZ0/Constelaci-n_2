/* Constelación · utilidades compartidas (sin dependencias, sin innerHTML: todo texto entra como textContent). */
'use strict';

const $ = (sel, raiz = document) => raiz.querySelector(sel);
const $$ = (sel, raiz = document) => Array.from(raiz.querySelectorAll(sel));

/** Crea un elemento HTML. props: class, style (objeto), on<evento>, atributos; hijos: nodos, textos, arreglos. */
function h(tag, props, ...hijos) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(props || {})) {
    if (v == null || v === false) continue;
    if (k === 'class') el.className = v;
    else if (k === 'style' && typeof v === 'object') Object.assign(el.style, v);
    else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2), v);
    else if (k === 'value') el.value = v;
    else if (v === true) el.setAttribute(k, '');
    else el.setAttribute(k, v);
  }
  for (const hijo of hijos.flat(Infinity)) {
    if (hijo == null || hijo === false) continue;
    el.append(hijo.nodeType ? hijo : document.createTextNode(String(hijo)));
  }
  return el;
}

const NS_SVG = 'http://www.w3.org/2000/svg';
function svg(tag, attrs, ...hijos) {
  const el = document.createElementNS(NS_SVG, tag);
  for (const [k, v] of Object.entries(attrs || {})) if (v != null && v !== false) el.setAttribute(k, v);
  for (const hijo of hijos.flat(Infinity)) {
    if (hijo == null || hijo === false) continue;
    el.append(hijo.nodeType ? hijo : document.createTextNode(String(hijo)));
  }
  return el;
}

/** Llamada a la API JSON. Lanza Error con .status si la respuesta no es 2xx. */
async function api(ruta, metodo = 'GET', cuerpo) {
  const opciones = { method: metodo, headers: {}, credentials: 'same-origin' };
  if (cuerpo !== undefined) {
    opciones.headers['Content-Type'] = 'application/json';
    opciones.body = JSON.stringify(cuerpo);
  }
  let resp;
  try { resp = await fetch('/api' + ruta, opciones); }
  catch (_) { throw new Error('No hay conexión con el servidor. Revisa que esté encendido.'); }
  let datos = null;
  try { datos = await resp.json(); } catch (_) { /* sin cuerpo */ }
  if (!resp.ok) {
    const err = new Error((datos && datos.error) || 'Ocurrió un error inesperado');
    err.status = resp.status;
    throw err;
  }
  return datos;
}

let _temporizadorAviso;
function aviso(mensaje, malo = false) {
  const t = $('#toast');
  t.textContent = mensaje;
  t.classList.toggle('mal', malo);
  t.hidden = false;
  clearTimeout(_temporizadorAviso);
  _temporizadorAviso = setTimeout(() => { t.hidden = true; }, 4500);
}

/* ---------- Diálogo modal (usa <dialog>) ---------- */
function abrirDialogo(titulo, cuerpo, { ancho } = {}) {
  const dlg = $('#dlg');
  dlg.style.width = ancho || '';
  dlg.replaceChildren(
    h('div', { class: 'dlg-cab' },
      h('h2', { id: 'dlg-titulo' }, titulo),
      h('button', { class: 'btn btn-suave btn-icono', type: 'button', 'aria-label': 'Cerrar', onclick: cerrarDialogo }, '✕')),
    h('div', { class: 'dlg-cuerpo' }, cuerpo));
  if (!dlg.open) dlg.showModal();
  return dlg;
}
function cerrarDialogo() { const d = $('#dlg'); if (d.open) d.close(); }

/** Confirmación propia (Promise<boolean>); evita confirm() nativo. */
function confirmar(titulo, texto, { si = 'Sí, continuar', peligro = false } = {}) {
  return new Promise((resolver) => {
    let resuelto = false;
    const fin = (v) => { if (!resuelto) { resuelto = true; resolver(v); } cerrarDialogo(); };
    const dlg = abrirDialogo(titulo, [
      h('p', { style: { marginBottom: '18px' } }, texto),
      h('div', { class: 'dlg-pie' },
        h('button', { class: 'btn btn-suave', type: 'button', onclick: () => fin(false) }, 'Cancelar'),
        h('button', { class: 'btn ' + (peligro ? 'btn-peligro' : 'btn-primario'), type: 'button', onclick: () => fin(true) }, si)),
    ]);
    dlg.addEventListener('close', () => fin(false), { once: true });
  });
}

/* ---------- Pequeños ayudantes ---------- */
function iniciales(nombre) {
  const p = nombre.trim().split(/\s+/);
  return ((p[0] || '')[0] + ((p[1] || '')[0] || '')).toUpperCase();
}
function plural(n, uno, varios) { return `${n} ${n === 1 ? uno : varios}`; }
/** Descarga un archivo de la API (PDF/ZIP). Si el servidor responde con error, lo muestra en un aviso. */
async function bajar(ruta) {
  try {
    const resp = await fetch('/api' + ruta, { credentials: 'same-origin' });
    if (!resp.ok) {
      let msg = 'No se pudo generar el archivo';
      try { msg = (await resp.json()).error || msg; } catch (_) { /* sin cuerpo */ }
      return aviso(msg, true);
    }
    const blob = await resp.blob();
    const cd = resp.headers.get('Content-Disposition') || '';
    const m = /filename\*?=(?:UTF-8'')?"?([^";]+)"?/i.exec(cd);
    const nombre = m ? decodeURIComponent(m[1]) : 'archivo';
    const url = URL.createObjectURL(blob);
    const a = h('a', { href: url, download: nombre });
    document.body.append(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 4000);
    aviso('Descarga lista: ' + nombre);
  } catch (_) { aviso('No hay conexión con el servidor.', true); }
}

/** Habilidades del catálogo (se llena en app.js). */
const CAT = { habilidades: [], juegos: [], porId: {}, juegoPorId: {}, textos: {}, ajustes: {}, niveles: {}, intereses: [], canales: {}, umbrales: { destaca: 75, desarrollo: 50 } };
function colorHab(id) { return (CAT.porId[id] || {}).color_pdf || '#6c5ce7'; }

/** Lectura en voz alta (speechSynthesis del navegador; no se graba ni se envía audio). */
const Voz = {
  disponible: typeof window !== 'undefined' && 'speechSynthesis' in window,
  decir(texto) {
    if (!this.disponible) return;
    window.speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(String(texto).replace(/[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}❓]/gu, ' '));
    u.lang = 'es-MX'; u.rate = 0.95;
    window.speechSynthesis.speak(u);
  },
  parar() { if (this.disponible) window.speechSynthesis.cancel(); },
};
