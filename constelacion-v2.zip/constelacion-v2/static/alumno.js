/* Constelación · MODO ALUMNO: estructura común, test inicial y tablero de misiones.
   El docente entrega el dispositivo; el alumno nunca ve puntajes (solo mensajes de ánimo). */
'use strict';

const Alumno = (() => {
  const LETRAS = ['A', 'B', 'C', 'D', 'E', 'F'];
  const E = { id: null, alumno: null, ajustes: {}, test: null, sesion: 0, limpiezas: [], alCerrar: null, directo: null };

  const raiz = () => $('#alumno-raiz');
  const vivo = (token) => token === E.sesion;

  /* ---------- estructura ---------- */
  function aplicarAjustes(aj) {
    const r = raiz();
    r.classList.toggle('ax-grande', !!aj.grande);
    r.classList.toggle('ax-contraste', !!aj.contraste);
    r.classList.toggle('ax-espaciado', !!aj.espaciado);
    r.classList.toggle('ax-quieto', !!aj.quieto);
  }

  function armar() {
    raiz().replaceChildren(
      h('div', { class: 'a-barra' },
        h('div', { class: 'a-progreso', 'aria-hidden': 'true' }, h('i', { id: 'a-prog', style: { width: '0%' } })),
        h('p', { class: 'a-progreso-txt', id: 'a-prog-txt' }),
        h('button', { class: 'btn btn-suave btn-peq', type: 'button', style: { color: '#fff', borderColor: 'rgba(255,255,255,.35)' }, onclick: pedirSalida }, 'Salir')),
      h('div', { class: 'a-escenario', id: 'a-esc', 'aria-live': 'polite' }));
  }

  function progreso(frac, texto) {
    const p = $('#a-prog');
    if (p) p.style.width = Math.round(100 * Math.min(1, Math.max(0, frac))) + '%';
    const t = $('#a-prog-txt');
    if (t) t.textContent = texto || '';
  }

  function limpiar() { E.limpiezas.splice(0).forEach((f) => { try { f(); } catch (_) { /* nada */ } }); }
  function alLimpiar(fn) { E.limpiezas.push(fn); }

  /** Reemplaza la pantalla actual por una tarjeta con los nodos dados. */
  function montar(...nodos) {
    limpiar();
    Voz.parar();
    const esc = $('#a-esc');
    esc.replaceChildren(h('div', { class: 'a-tarjeta' }, ...nodos));
    raiz().scrollTo({ top: 0 });
    const foco = $('.a-titulo', esc) || $('.a-pregunta', esc);
    if (foco) { foco.tabIndex = -1; foco.focus({ preventScroll: true }); }
  }

  /** Botón «Escuchar» solo si el docente activó la voz para este alumno. */
  function voz(texto) {
    if (!E.ajustes.voz || !Voz.disponible) return null;
    return h('button', { class: 'a-boton-voz', type: 'button', onclick: () => Voz.decir(texto) }, '🔊 Escuchar');
  }
  const textoConOpciones = (pregunta, opciones) => `${pregunta}. ${opciones.map((o, i) => `Opción ${LETRAS[i]}: ${o}`).join('. ')}`;

  /** Lista de opciones (botones). Devuelve {nodo, valor(), bloquear()}. */
  function opciones(textos, { alElegir, inicial = null, emojis = null, rejilla = false, etiqueta = '' } = {}) {
    let sel = inicial;
    const botones = textos.map((t, j) => {
      const b = h('button', { class: 'a-opcion', type: 'button', 'aria-pressed': String(sel === j) },
        emojis ? h('span', { class: 'emo', 'aria-hidden': 'true' }, emojis[j]) : h('span', { class: 'letra', 'aria-hidden': 'true' }, LETRAS[j]),
        h('span', null, t));
      b.addEventListener('click', () => {
        sel = j;
        botones.forEach((o, k) => o.setAttribute('aria-pressed', String(k === j)));
        if (alElegir) alElegir(j);
      });
      return b;
    });
    const nodo = h('div', { class: 'a-opciones' + (rejilla ? ' a-rejilla' : ''), role: 'group', 'aria-label': etiqueta }, botones);
    return { nodo, valor: () => sel, bloquear: (v = true) => botones.forEach((b) => { b.disabled = v; }) };
  }

  const botonSiguiente = (texto, onclick, deshabilitado = true) =>
    h('button', { class: 'btn btn-primario btn-grande', type: 'button', disabled: deshabilitado, onclick }, texto);

  async function pedirSalida() {
    const si = await confirmar('¿Salir de las actividades?', 'Si sales ahora, la actividad que está en curso se detiene y tendrás que empezarla de nuevo.', { si: 'Sí, salir', peligro: true });
    if (si) cerrar();
  }

  function cerrar() {
    E.sesion += 1;
    limpiar();
    Voz.parar();
    raiz().hidden = true;
    document.body.style.overflow = '';
    if (E.alCerrar) E.alCerrar();
  }

  /* ---------- apertura ---------- */
  /** modo: 'auto' (test si falta, si no tablero) | 'test' | {juego: id}. alCerrar: función para refrescar el panel. */
  async function abrir(alumnoId, modo = 'auto', alCerrar = null) {
    E.sesion += 1;
    E.alCerrar = alCerrar;
    E.id = alumnoId;
    raiz().hidden = false;
    document.body.style.overflow = 'hidden';
    armar();
    progreso(0, 'Cargando…');
    try {
      const t = await api(`/alumnos/${alumnoId}/tablero`);
      E.alumno = t.alumno; E.ajustes = t.ajustes || {};
      aplicarAjustes(E.ajustes);
      if (modo && modo.juego) return await jugar(modo.juego);
      if (modo === 'test' || (modo === 'auto' && !t.test_hecho)) return await correrTest();
      return await tablero();
    } catch (err) {
      aviso(err.message, true);
      cerrar();
    }
  }

  function nombrePila() { return E.alumno.nombre.trim().split(/\s+/)[0]; }

  /* ---------- tablero ---------- */
  async function tablero() {
    const token = E.sesion;
    const t = await api(`/alumnos/${E.id}/tablero`);
    if (!vivo(token)) return;
    const pendientes = t.asignaciones.filter((a) => a.estado !== 'completada');
    const hechas = t.asignaciones.filter((a) => a.estado === 'completada');
    progreso(t.asignaciones.length ? hechas.length / t.asignaciones.length : (t.test_hecho ? 1 : 0), t.asignaciones.length ? `${hechas.length} de ${t.asignaciones.length} misiones` : '');
    const lista = [];
    if (!t.test_hecho) {
      lista.push(h('div', { class: 'a-mision', style: { '--hab': '#ffb400' } },
        h('span', { class: 'ico', 'aria-hidden': 'true' }, '🧭'),
        h('h3', null, 'Cuestionario: ¿cómo aprendo?'),
        h('p', null, 'Unos 8 minutos. No hay respuestas buenas ni malas.'),
        h('button', { class: 'btn btn-primario', type: 'button', onclick: () => correrTest().catch(errorFatal) }, 'Empezar')));
    }
    for (const a of t.asignaciones) {
      const j = a.juego, hecha = a.estado === 'completada';
      lista.push(h('div', { class: 'a-mision' + (hecha ? ' hecha' : ''), style: { '--hab': (CAT.porId[j.habilidad] || {}).color || '#9b8cff' } },
        h('span', { class: 'ico', 'aria-hidden': 'true' }, j.icono),
        h('h3', null, j.titulo),
        h('p', null, hecha ? '✔ ¡Listo! Puedes jugarlo otra vez si quieres.' : `${j.subtitulo} · unos ${j.minutos} min`),
        h('button', { class: 'btn ' + (hecha ? 'btn-suave' : 'btn-primario'), style: hecha ? { color: '#fff', borderColor: 'rgba(255,255,255,.4)' } : null, type: 'button', onclick: () => jugar(j.id).catch(errorFatal) }, hecha ? 'Repetir' : 'Jugar')));
    }
    montar(
      h('span', { class: 'a-chip' }, 'Mis misiones'),
      h('h1', { class: 'a-titulo' }, `¡Hola, ${nombrePila()}! 👋`),
      h('p', { class: 'a-sub' }, !t.asignaciones.length && t.test_hecho
        ? 'Por ahora no tienes misiones pendientes. Tu maestro o maestra te asignará nuevas pronto.'
        : (pendientes.length ? 'Elige una misión. Puedes hacerlas en el orden que quieras.' : '¡Terminaste todas tus misiones! 🎉')),
      voz(`Hola ${nombrePila()}. Aquí están tus misiones.`),
      h('div', { class: 'a-misiones', style: { marginTop: '14px' } }, lista),
      h('div', { class: 'a-acciones' }, h('span'), h('button', { class: 'btn btn-primario btn-grande', type: 'button', onclick: cerrar }, 'Terminar por ahora')));
  }

  function errorFatal(err) { aviso(err.message || 'Ocurrió un error', true); }

  /* ---------- juegos ---------- */
  async function jugar(juegoId) {
    const token = E.sesion;
    const r = await api(`/alumnos/${E.id}/juegos/${juegoId}`);
    if (!vivo(token)) return;
    const j = r.juego;
    E.ajustes = r.ajustes || E.ajustes;
    const ctx = {
      id: E.id, nivel: E.alumno.nivel, nombre: nombrePila(), montar, progreso, voz, textoConOpciones, opciones,
      botonSiguiente, alLimpiar, vivo: () => vivo(token), ajustes: E.ajustes, api, LETRAS,
      color: (CAT.porId[j.habilidad] || {}).color || '#9b8cff',
    };
    // Portada del juego
    await new Promise((resolver) => {
      progreso(0, j.titulo);
      montar(
        h('span', { class: 'a-chip' }, `${j.icono} ${j.habilidad_nombre}`),
        h('h1', { class: 'a-titulo' }, j.titulo),
        h('p', { class: 'a-sub' }, j.subtitulo),
        h('div', { class: 'a-caja' }, `⏱ Unos ${j.minutos} minutos · Sin cronómetro: lo importante es pensar con calma. Aquí no hay calificación.`),
        voz(`${j.titulo}. ${j.subtitulo}`),
        h('div', { class: 'a-acciones' },
          h('button', { class: 'btn btn-suave', type: 'button', style: { color: '#fff', borderColor: 'rgba(255,255,255,.4)' }, onclick: () => tablero().catch(errorFatal) }, '← Volver'),
          h('button', { class: 'btn btn-primario btn-grande', type: 'button', onclick: () => resolver() }, '¡Vamos! 🚀')));
    });
    if (!vivo(token)) return;
    const datos = await Juegos[juegoId](r.contenido, ctx);
    if (!vivo(token) || !datos) return;
    montar(h('p', { class: 'a-sub centro' }, 'Guardando…'));
    await api(`/alumnos/${E.id}/juegos/${juegoId}/resultado`, 'POST', { datos });
    if (!vivo(token)) return;
    progreso(1, '¡Listo!');
    montar(h('div', { class: 'a-final' },
      h('span', { class: 'trofeo', 'aria-hidden': 'true' }, '🌟'),
      h('h1', { class: 'a-titulo' }, '¡Misión cumplida!'),
      h('p', { class: 'a-sub' }, `Gracias por tu esfuerzo, ${nombrePila()}. Pensar con calma y probar ideas es lo que más cuenta.`),
      h('button', { class: 'btn btn-primario btn-grande', type: 'button', onclick: () => tablero().catch(errorFatal) }, 'Volver a mis misiones')));
  }

  /* ---------- test inicial ---------- */
  async function correrTest() {
    const token = E.sesion;
    const r = await api(`/alumnos/${E.id}/test`);
    if (!vivo(token)) return;
    const T = r.test;
    const vak = new Array(T.vak.length).fill(null);
    const auto = new Array(T.auto.length).fill(null);
    const total = T.vak.length + T.auto.length + 1;
    let hechas = 0;

    const bienvenida = () => {
      progreso(0, 'Cuestionario');
      montar(
        h('span', { class: 'a-chip' }, 'Cuestionario'),
        h('h1', { class: 'a-titulo' }, `¡Hola, ${nombrePila()}! 👋`),
        h('p', { class: 'a-sub' }, 'Vamos a conocer cómo aprendes mejor, qué cosas se te dan bien y qué te gusta. Son tres partes cortas.'),
        h('div', { class: 'a-caja' }, '✨ No es un examen ni lleva calificación. No hay respuestas buenas ni malas: contesta lo que más se parezca a ti.'),
        voz('Vamos a conocer cómo aprendes mejor. No es un examen y no hay respuestas buenas ni malas.'),
        h('div', { class: 'a-acciones' },
          h('button', { class: 'btn btn-suave', type: 'button', style: { color: '#fff', borderColor: 'rgba(255,255,255,.4)' }, onclick: () => tablero().catch(errorFatal) }, '← Volver'),
          h('button', { class: 'btn btn-primario btn-grande', type: 'button', onclick: () => pasoVAK(0) }, '¡Empezar! 🚀')));
    };

    const pasoVAK = (i) => {
      if (!vivo(token)) return;
      const q = T.vak[i];
      progreso(hechas / total, `Parte 1 · ${i + 1} de ${T.vak.length}`);
      const op = opciones(q.opciones, {
        etiqueta: q.pregunta, inicial: vak[i],
        alElegir: (j) => { vak[i] = j; op.bloquear(); setTimeout(() => { if (!vivo(token)) return; hechas = Math.max(hechas, i + 1); i + 1 < T.vak.length ? pasoVAK(i + 1) : pasoAuto(0); }, 260); },
      });
      montar(
        h('span', { class: 'a-chip' }, 'Parte 1 · Cómo aprendo'),
        h('h1', { class: 'a-pregunta' }, q.pregunta),
        voz(textoConOpciones(q.pregunta, q.opciones)),
        h('div', { style: { marginTop: '12px' } }, op.nodo),
        h('div', { class: 'a-acciones' },
          h('button', { class: 'btn btn-suave', type: 'button', style: { color: '#fff', borderColor: 'rgba(255,255,255,.4)' }, disabled: i === 0, onclick: () => pasoVAK(i - 1) }, '← Atrás'),
          h('span', { class: 'suave' }, 'Elige la que más se parezca a ti')));
    };

    const pasoAuto = (i) => {
      if (!vivo(token)) return;
      const q = T.auto[i];
      progreso((T.vak.length + i) / total, `Parte 2 · ${i + 1} de ${T.auto.length}`);
      const op = opciones(T.escala.map((e) => e.texto), {
        etiqueta: q.texto, inicial: auto[i] == null ? null : auto[i] - 1, emojis: T.escala.map((e) => e.emoji),
        alElegir: (j) => { auto[i] = T.escala[j].valor; op.bloquear(); setTimeout(() => { if (!vivo(token)) return; i + 1 < T.auto.length ? pasoAuto(i + 1) : pasoIntereses(); }, 260); },
      });
      op.nodo.classList.add('a-escala');
      montar(
        h('span', { class: 'a-chip' }, 'Parte 2 · Cómo me veo'),
        h('p', { class: 'a-sub' }, '¿Qué tanto te describe esto?'),
        h('h1', { class: 'a-pregunta' }, q.texto),
        voz(`¿Qué tanto te describe esto? ${q.texto}. Puedes responder: nada, un poco, bastante o mucho.`),
        h('div', { style: { marginTop: '12px' } }, op.nodo),
        h('div', { class: 'a-acciones' },
          h('button', { class: 'btn btn-suave', type: 'button', style: { color: '#fff', borderColor: 'rgba(255,255,255,.4)' }, onclick: () => (i === 0 ? pasoVAK(T.vak.length - 1) : pasoAuto(i - 1)) }, '← Atrás'),
          h('span', null)));
    };

    const pasoIntereses = () => {
      if (!vivo(token)) return;
      progreso((total - 1) / total, 'Parte 3 · Mis gustos');
      const elegidos = new Set();
      const contador = h('p', { class: 'a-sub', 'aria-live': 'polite' }, `Elegiste 0 de ${T.maxIntereses}`);
      const boton = botonSiguiente('Terminar ✔', async () => {
        boton.disabled = true;
        try {
          await api(`/alumnos/${E.id}/test`, 'POST', { vak, auto, intereses: Array.from(elegidos) });
          if (!vivo(token)) return;
          progreso(1, '¡Listo!');
          montar(h('div', { class: 'a-final' },
            h('span', { class: 'trofeo', 'aria-hidden': 'true' }, '🌟'),
            h('h1', { class: 'a-titulo' }, '¡Lo lograste!'),
            h('p', { class: 'a-sub' }, 'Terminaste el cuestionario. Tu maestro o maestra verá cómo puedes aprender mejor y qué te gusta.'),
            h('button', { class: 'btn btn-primario btn-grande', type: 'button', onclick: () => tablero().catch(errorFatal) }, 'Ir a mis misiones')));
        } catch (err) { aviso(err.message, true); boton.disabled = false; }
      });
      const rejilla = h('div', { class: 'a-opciones a-rejilla', role: 'group', 'aria-label': 'Intereses' },
        T.intereses.map((it) => {
          const b = h('button', { class: 'a-opcion', type: 'button', 'aria-pressed': 'false' },
            h('span', { class: 'emo', 'aria-hidden': 'true' }, it.icono), h('span', null, it.nombre));
          b.addEventListener('click', () => {
            if (elegidos.has(it.id)) elegidos.delete(it.id);
            else if (elegidos.size < T.maxIntereses) elegidos.add(it.id);
            else return aviso(`Solo puedes elegir ${T.maxIntereses}. Quita una para cambiar.`);
            b.setAttribute('aria-pressed', String(elegidos.has(it.id)));
            contador.textContent = `Elegiste ${elegidos.size} de ${T.maxIntereses}`;
            boton.disabled = elegidos.size === 0;
          });
          return b;
        }));
      montar(
        h('span', { class: 'a-chip' }, 'Parte 3 · Mis gustos'),
        h('h1', { class: 'a-titulo' }, '¿Qué te gusta más?'),
        h('p', { class: 'a-sub' }, `Elige hasta ${T.maxIntereses} cosas que te emocionan o que te gustaría aprender.`),
        voz('¿Qué te gusta más? Elige hasta tres cosas.'),
        h('div', { style: { marginTop: '12px' } }, rejilla), contador,
        h('div', { class: 'a-acciones' },
          h('button', { class: 'btn btn-suave', type: 'button', style: { color: '#fff', borderColor: 'rgba(255,255,255,.4)' }, onclick: () => pasoAuto(T.auto.length - 1) }, '← Atrás'),
          boton));
    };

    bienvenida();
  }

  return { abrir, cerrar, montar, progreso };
})();
