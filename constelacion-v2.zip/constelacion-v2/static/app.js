/* Constelación · panel docente (clases, alumnos, perfil, octágono, asignaciones, PDF). */
'use strict';

const S = { docente: null, cargando: 0 };
const NIVEL_TXT = { Destaca: 'ok', 'En desarrollo': 'marca', 'Para impulsar': 'pend' };
const ANIMOS = ['', 'Mal', 'Regular', 'Bien', 'Muy bien', 'Genial'];
const raiz = () => $('#raiz');

/* ============================== arranque y rutas ============================== */
async function iniciar() {
  window.addEventListener('hashchange', ruta);
  try {
    S.docente = await api('/yo');
    await cargarCatalogo();
  } catch (_) { S.docente = null; }
  ruta();
}

async function cargarCatalogo() {
  const c = await api('/catalogo');
  Object.assign(CAT, c);
  CAT.porId = Object.fromEntries(c.habilidades.map((x) => [x.id, x]));
  CAT.juegoPorId = Object.fromEntries(c.juegos.map((x) => [x.id, x]));
}

async function ruta() {
  Voz.parar();
  if (!S.docente) return vistaAuth();
  const [, tipo, id] = (location.hash || '').match(/^#\/(clase|alumno)\/(\d+)/) || [];
  marco();
  try {
    if (tipo === 'clase') await vistaClase(Number(id));
    else if (tipo === 'alumno') await vistaAlumno(Number(id));
    else await vistaClases();
  } catch (err) {
    if (err.status === 401) { S.docente = null; return vistaAuth(); }
    if (err.status === 404) { aviso('No se encontró lo que buscabas', true); location.hash = '#/'; return; }
    $('#contenido').replaceChildren(h('div', { class: 'tarjeta vacio' }, h('span', { class: 'gran' }, '⚠️'), err.message));
  }
}

function titulo(t) { document.title = `${t} · Constelación`; }

/** Estructura fija del panel (barra + contenedor). */
function marco() {
  if ($('.barra')) return;
  raiz().className = '';
  raiz().replaceChildren(
    h('header', { class: 'barra' },
      h('a', { class: 'logo', href: '#/', 'aria-label': 'Constelación, ir a Mis clases' }, h('i', { 'aria-hidden': 'true' }, '✦'), 'Constelación'),
      h('div', { class: 'barra-der' },
        h('span', { class: 'usuario' }, `${S.docente.nombre} · ${S.docente.escuela}`),
        h('button', { class: 'btn btn-suave btn-peq', type: 'button', onclick: () => bajar('/reportes.zip') }, '⬇ Todos los reportes'),
        h('button', { class: 'btn btn-suave btn-peq', type: 'button', onclick: salir }, 'Cerrar sesión'))),
    h('main', { id: 'contenido', tabindex: '-1' }, h('p', { class: 'cargando' }, 'Cargando…')));
}
function contenido(...nodos) { const c = $('#contenido'); c.replaceChildren(...nodos.filter(Boolean)); window.scrollTo({ top: 0 }); }

async function salir() {
  try { await api('/logout', 'POST', {}); } catch (_) { /* ignorar */ }
  S.docente = null; location.hash = ''; vistaAuth();
}

/* ============================== acceso ============================== */
function vistaAuth() {
  titulo('Que ningún talento pase desapercibido');
  const r = raiz();
  r.className = 'noche';
  const formReg = h('form', { id: 'form-registro', novalidate: true, onsubmit: (e) => enviarAcceso(e, '/registro') },
    h('label', { class: 'campo' }, 'Nombre completo', h('input', { name: 'nombre', required: true, maxlength: 120, autocomplete: 'name', placeholder: 'Ej. María Hernández López' })),
    h('label', { class: 'campo' }, 'Escuela', h('input', { name: 'escuela', required: true, maxlength: 160, autocomplete: 'organization', placeholder: 'Ej. Escuela Benito Juárez' })),
    h('label', { class: 'campo' }, 'Correo electrónico', h('input', { name: 'correo', type: 'email', required: true, autocomplete: 'email', placeholder: 'docente@correo.com' })),
    h('label', { class: 'campo' }, 'Contraseña ', h('small', null, '(mínimo 8 caracteres)'), h('input', { name: 'password', type: 'password', required: true, minlength: 8, autocomplete: 'new-password' })),
    h('p', { class: 'error', role: 'alert', hidden: true }),
    h('button', { class: 'btn btn-primario btn-ancho', type: 'submit' }, 'Crear mi cuenta'));
  const formLogin = h('form', { id: 'form-login', novalidate: true, hidden: true, onsubmit: (e) => enviarAcceso(e, '/login') },
    h('label', { class: 'campo' }, 'Correo electrónico', h('input', { name: 'correo', type: 'email', required: true, autocomplete: 'email' })),
    h('label', { class: 'campo' }, 'Contraseña', h('input', { name: 'password', type: 'password', required: true, autocomplete: 'current-password' })),
    h('p', { class: 'error', role: 'alert', hidden: true }),
    h('button', { class: 'btn btn-primario btn-ancho', type: 'submit' }, 'Entrar'));
  const tabReg = h('button', { class: 'pestana', role: 'tab', type: 'button', id: 'tab-registro', 'aria-selected': 'true', 'aria-controls': 'form-registro' }, 'Registrarme');
  const tabLog = h('button', { class: 'pestana', role: 'tab', type: 'button', id: 'tab-login', 'aria-selected': 'false', 'aria-controls': 'form-login' }, 'Ya tengo cuenta');
  const elegir = (reg) => {
    tabReg.setAttribute('aria-selected', String(reg)); tabLog.setAttribute('aria-selected', String(!reg));
    formReg.hidden = !reg; formLogin.hidden = reg;
  };
  tabReg.onclick = () => elegir(true); tabLog.onclick = () => elegir(false);
  r.replaceChildren(h('main', { id: 'contenido', class: 'auth' },
    h('div', { class: 'auth-caja' },
      h('div', null,
        h('p', { class: 'etiqueta' }, 'Reto 20 · ProFuturo'),
        h('h1', null, 'Que ningún talento pase ', h('em', null, 'desapercibido')),
        h('p', { class: 'lead' }, 'Descubre las habilidades, los intereses y la forma de aprender de cada estudiante de primaria (5.º y 6.º) y secundaria (1.º a 3.º), más allá de sus calificaciones.'),
        h('ul', { class: 'puntos' },
          [['🧭', 'Un cuestionario breve: cómo aprende, cómo se ve y qué le gusta'], ['🎮', '8 minijuegos, uno por habilidad del octágono'],
            ['🏫', 'Tus clases en un solo lugar, con su octágono grupal'], ['📄', 'PDF por estudiante y por clase'],
            ['🤝', 'Orientación para ti: tú decides, la herramienta no etiqueta']].map(([i, t]) => h('li', null, h('span', { 'aria-hidden': 'true' }, i), t)))),
      h('div', { class: 'tarjeta' },
        h('div', { class: 'pestanas', role: 'tablist', 'aria-label': 'Acceso' }, tabReg, tabLog), formReg, formLogin,
        h('p', { class: 'demo-nota' }, 'Prototipo de prueba. Los datos se guardan solo en este servidor.')))));
}

async function enviarAcceso(e, ruta_) {
  e.preventDefault();
  const form = e.currentTarget;
  const err = $('.error', form);
  err.hidden = true;
  const datos = Object.fromEntries(new FormData(form));
  if (ruta_ === '/registro' && (datos.password || '').length < 8) { err.textContent = 'La contraseña debe tener al menos 8 caracteres'; err.hidden = false; return; }
  const boton = $('button[type=submit]', form);
  boton.disabled = true;
  try {
    S.docente = await api(ruta_, 'POST', datos);
    await cargarCatalogo();
    location.hash = '#/';
    ruta();
  } catch (x) { err.textContent = x.message; err.hidden = false; }
  finally { boton.disabled = false; }
}

/* ============================== componentes ============================== */
const chipHab = (id, extra) => {
  const hb = CAT.porId[id];
  return h('span', { class: 'chip', style: { '--hab': hb.color_pdf } }, h('span', { 'aria-hidden': 'true' }, hb.icono), hb.nombre, extra || null);
};
const miniHab = (id) => { const hb = CAT.porId[id]; return h('span', { class: 'mini-hab', style: { '--hab': hb.color_pdf }, title: hb.nombre }, h('span', { 'aria-hidden': 'true' }, hb.icono), h('span', { class: 'solo-lectores' }, hb.nombre)); };
const migas = (...partes) => h('nav', { class: 'migas', 'aria-label': 'Ruta' }, partes.flatMap((p, i) => [i ? h('span', { 'aria-hidden': 'true' }, '›') : null, p]));
const nivelLabel = (c) => `${c.nivel === 'primaria' ? 'Primaria' : 'Secundaria'} · ${c.grado}.º`;

function datosOcta(habilidades, { sub } = {}) {
  return CAT.habilidades.map((hb) => {
    const x = habilidades.find((a) => a.id === hb.id) || {};
    return { id: hb.id, nombre: hb.nombre, corto: hb.corto, icono: hb.icono, color: hb.color_pdf, valor: x.valor == null ? null : x.valor, auto: x.auto == null ? null : x.auto, sub: sub ? sub(x) : null };
  });
}

function barraVAK(conteo, total, etiquetas = CAT.canales) {
  return ['V', 'A', 'K'].map((k) => {
    const n = conteo[k] || 0, pct = total ? Math.round(100 * n / total) : 0;
    return h('div', { class: `vak-fila vak-${k}` }, h('span', null, etiquetas[k]), h('div', { class: 'vak-barra', role: 'img', 'aria-label': `${etiquetas[k]}: ${n}` }, h('i', { style: { width: pct + '%' } })), h('span', { style: { textAlign: 'right' } }, String(n)));
  });
}

/* ============================== vista: Mis clases ============================== */
async function vistaClases() {
  titulo('Mis clases');
  const clases = await api('/clases');
  const tarjetas = clases.map((c) => h('a', { class: 'tarjeta clase-card', href: `#/clase/${c.id}` },
    h('div', { class: 'clase-franja', 'aria-hidden': 'true' }),
    h('h3', null, c.nombre),
    h('div', null, h('span', { class: 'insignia marca' }, nivelLabel(c)), c.ciclo ? h('span', { class: 'suave', style: { marginLeft: '8px', fontSize: '.85rem' } }, c.ciclo) : null),
    h('div', { class: 'clase-datos' }, h('span', null, h('b', null, c.alumnos), c.alumnos === 1 ? ' estudiante' : ' estudiantes'), h('span', null, h('b', null, c.con_test), ' con cuestionario')),
    h('span', { class: 'progreso-mini', style: { width: '100%', height: '8px' }, 'aria-hidden': 'true' }, h('i', { style: { width: (c.alumnos ? Math.round(100 * c.con_test / c.alumnos) : 0) + '%' } }))));
  tarjetas.push(h('button', { class: 'tarjeta clase-card clase-nueva', type: 'button', onclick: () => dialogoClase() }, h('span', { class: 'mas', 'aria-hidden': 'true' }, '＋'), 'Nueva clase'));
  contenido(
    h('div', { class: 'encabezado' },
      h('div', null, h('h1', null, `Hola, ${S.docente.nombre.split(' ')[0]} 👋`), h('p', null, clases.length ? 'Estas son tus clases. Entra a una para registrar estudiantes, aplicar el cuestionario y ver su octágono.' : 'Empieza creando tu primera clase (por ejemplo «5.º A» o «2.º B»). Después agrega a tus estudiantes y aplícales el cuestionario.'))),
    h('div', { class: 'rejilla rej-clases' }, tarjetas),
    h('p', { class: 'nota-etica', style: { marginTop: '24px' } }, 'Constelación es una herramienta de orientación pedagógica: no diagnostica, no califica ni clasifica estudiantes, y sus resultados siempre deben contrastarse con tu observación en el aula.'));
}

function dialogoClase(clase) {
  const editar = !!clase;
  let nivel = clase ? clase.nivel : null;
  const grados = h('fieldset', { class: 'opciones-tarjeta' }, h('legend', null, 'Grado'));
  const pintarGrados = () => {
    grados.replaceChildren(h('legend', null, 'Grado'));
    const lista = nivel ? CAT.niveles[nivel].grados : [];
    if (!lista.length) grados.append(h('p', { class: 'suave' }, 'Primero elige el nivel.'));
    lista.forEach((g) => grados.append(h('label', { class: 'opc-tarjeta' },
      h('input', { type: 'radio', name: 'grado', value: g, checked: clase && clase.grado === g && clase.nivel === nivel }), h('span', null, `${g}.º`))));
  };
  const niveles = h('fieldset', { class: 'opciones-tarjeta' }, h('legend', null, 'Nivel educativo'),
    Object.entries(CAT.niveles).map(([k, v]) => h('label', { class: 'opc-tarjeta' },
      h('input', { type: 'radio', name: 'nivel', value: k, checked: nivel === k, onchange: () => { nivel = k; pintarGrados(); } }),
      h('span', null, v.nombre, h('small', null, k === 'primaria' ? '5.º y 6.º' : '1.º a 3.º')))));
  pintarGrados();
  const err = h('p', { class: 'error', role: 'alert', hidden: true });
  const form = h('form', { novalidate: true, onsubmit: async (e) => {
    e.preventDefault(); err.hidden = true;
    const f = new FormData(form);
    const cuerpo = { nombre: (f.get('nombre') || '').trim(), nivel: f.get('nivel'), grado: f.get('grado'), ciclo: (f.get('ciclo') || '').trim() };
    if (!cuerpo.nombre || !cuerpo.nivel || !cuerpo.grado) { err.textContent = 'Escribe el nombre y elige nivel y grado'; err.hidden = false; return; }
    try {
      const r = editar ? await api(`/clases/${clase.id}`, 'PUT', cuerpo) : await api('/clases', 'POST', cuerpo);
      cerrarDialogo(); aviso(editar ? 'Clase actualizada' : 'Clase creada ✔');
      if (editar) ruta(); else location.hash = `#/clase/${r.id}`;
    } catch (x) { err.textContent = x.message; err.hidden = false; }
  } },
    h('label', { class: 'campo' }, 'Nombre de la clase', h('input', { name: 'nombre', required: true, maxlength: 60, placeholder: 'Ej. 5.º A', value: clase ? clase.nombre : '' })),
    niveles, grados,
    h('label', { class: 'campo' }, 'Ciclo escolar ', h('small', null, '(opcional)'), h('input', { name: 'ciclo', maxlength: 20, placeholder: 'Ej. 2026-2027', value: clase && clase.ciclo ? clase.ciclo : '' })),
    err,
    h('div', { class: 'dlg-pie' }, h('button', { class: 'btn btn-suave', type: 'button', onclick: cerrarDialogo }, 'Cancelar'), h('button', { class: 'btn btn-primario', type: 'submit' }, editar ? 'Guardar cambios' : 'Crear clase')));
  abrirDialogo(editar ? 'Editar clase' : 'Nueva clase', form);
  $('input[name=nombre]', form).focus();
}

/* ============================== vista: una clase ============================== */
async function vistaClase(id) {
  const D = await api(`/clases/${id}`);
  const { clase, alumnos, resumen } = D;
  titulo(clase.nombre);
  const hayDatos = resumen.con_test + resumen.con_juegos > 0;
  const hab = resumen.habilidades;

  // Octágono grupal
  const octa = hayDatos
    ? Octagono.crear(datosOcta(hab, { sub: (x) => (x.destacan ? `${x.destacan} destacan` : '') }), { titulo: `Octágono de la clase ${clase.nombre}` })
    : null;
  const tarjetaOcta = h('div', { class: 'tarjeta' },
    h('h2', null, 'Octágono de la clase'),
    h('p', { class: 'sub' }, hayDatos
      ? `Promedio del grupo por habilidad (${plural(resumen.con_test, 'estudiante', 'estudiantes')} con cuestionario, ${plural(resumen.con_juegos, 'con minijuegos', 'con minijuegos')}). Es una vista del grupo: no compara ni ordena estudiantes.`
      : 'Aquí aparecerá el octágono del grupo en cuanto haya resultados.'),
    hayDatos ? h('div', { class: 'octa-caja' }, octa, Octagono.leyenda(false)) : h('div', { class: 'vacio' }, h('span', { class: 'gran' }, '🧭'), 'Aplica el cuestionario a tus estudiantes (botón «Aplicar test» en la tabla).'),
    hayDatos && resumen.destacadas.length ? h('div', { style: { marginTop: '10px' } }, h('h3', null, 'Lo que más destaca en el grupo'), h('div', { class: 'chips' }, resumen.destacadas.map((i) => chipHab(i)))) : null);

  // Cómo aprende el grupo
  const nStyle = resumen.estilos.V + resumen.estilos.A + resumen.estilos.K;
  const tarjetaEstilo = h('div', { class: 'tarjeta' },
    h('h2', null, 'Cómo prefiere aprender el grupo'),
    h('p', { class: 'sub' }, 'Canal predominante de cada estudiante (modelo PNL: visual, auditivo, cinestésico). Es una preferencia, no una capacidad: sirve para variar cómo presentas la información.'),
    nStyle ? barraVAK(resumen.estilos, nStyle) : h('p', { class: 'suave' }, 'Sin datos todavía.'),
    nStyle ? h('p', { class: 'suave', style: { fontSize: '.88rem', marginTop: '8px' } }, 'Para un grupo mixto: combina explicación oral, apoyos visuales (esquemas, colores) y actividades con las manos.') : null);

  const tarjetaInt = h('div', { class: 'tarjeta' },
    h('h2', null, 'Intereses del grupo'),
    resumen.intereses.length
      ? h('div', { class: 'chips', style: { marginTop: '8px' } }, resumen.intereses.map((x) => { const it = CAT.intereses.find((i) => i.id === x.id); return h('span', { class: 'chip', style: { '--hab': '#8a91c4' } }, h('span', { 'aria-hidden': 'true' }, it.icono), `${it.nombre} · ${x.n}`); }))
      : h('p', { class: 'suave' }, 'Sin datos todavía.'));

  // Asignar un minijuego a toda la clase
  const sel = h('select', { 'aria-label': 'Minijuego', id: 'sel-juego' }, CAT.juegos.map((j) => h('option', { value: j.id }, `${j.icono} ${j.titulo} — ${j.habilidad_nombre}`)));
  const tarjetaAsig = h('div', { class: 'tarjeta' },
    h('h2', null, 'Asignar un minijuego a toda la clase'),
    h('p', { class: 'sub' }, 'Cada estudiante lo verá en «Mis misiones». Para asignar según las fortalezas de cada uno, entra a su perfil.'),
    sel, h('div', { style: { marginTop: '10px' } }, h('button', { class: 'btn btn-marca', type: 'button', disabled: !alumnos.length, onclick: async () => {
      try { const r = await api(`/clases/${id}/asignaciones`, 'POST', { juego: sel.value }); aviso(`Asignado a ${plural(r.asignados, 'estudiante', 'estudiantes')} ✔`); ruta(); } catch (x) { aviso(x.message, true); }
    } }, 'Asignar a todos')));

  // Tabla de estudiantes
  const filas = alumnos.map((a) => {
    const completo = a.juegos_hechos > 0 || a.test;
    return h('tr', null,
      h('td', null, h('a', { class: 'nombre', href: `#/alumno/${a.id}` }, a.nombre), h('div', { class: 'suave', style: { fontSize: '.8rem' } }, [a.matricula ? `Mat. ${a.matricula}` : null, a.edad ? `${a.edad} años` : null, a.ajustes ? 'con apoyos de acceso' : null].filter(Boolean).join(' · '))),
      h('td', null, h('span', { class: 'insignia ' + (a.test ? 'ok' : 'pend') }, a.test ? '✔ Hecho' : 'Pendiente')),
      h('td', null, h('span', { class: 'progreso-mini', 'aria-hidden': 'true' }, h('i', { style: { width: Math.round(100 * a.juegos_hechos / a.juegos_total) + '%' } })), `${a.juegos_hechos}/${a.juegos_total}`, a.pendientes.length ? h('span', { class: 'suave', style: { fontSize: '.8rem' } }, ` · ${a.pendientes.length} asignado${a.pendientes.length === 1 ? '' : 's'}`) : null),
      h('td', null, a.destacadas.length ? h('div', { class: 'mini-hab-fila' }, a.destacadas.map(miniHab)) : h('span', { class: 'suave' }, '—')),
      h('td', null, a.estilo ? h('span', { class: 'insignia' }, CAT.canales[a.estilo]) : h('span', { class: 'suave' }, '—')),
      h('td', { class: 'der' }, h('div', { class: 'acc' },
        h('button', { class: 'btn btn-primario btn-peq', type: 'button', onclick: () => Alumno.abrir(a.id, a.test ? 'auto' : 'test', ruta) }, a.test ? 'Misiones' : 'Aplicar test'),
        h('a', { class: 'btn btn-suave btn-peq', href: `#/alumno/${a.id}` }, 'Perfil'),
        completo ? h('button', { class: 'btn btn-suave btn-peq', type: 'button', onclick: () => bajar(`/alumnos/${a.id}/pdf`), 'aria-label': `PDF de ${a.nombre}` }, 'PDF') : null)));
  });
  const tarjetaAlumnos = h('div', { class: 'tarjeta' },
    h('div', { class: 'encabezado', style: { marginBottom: '8px' } },
      h('div', null, h('h2', null, `Estudiantes (${alumnos.length})`), h('p', { class: 'sub', style: { marginBottom: 0 } }, 'En «Destaca en» ves las habilidades más altas de cada estudiante (con minijuegos o, si aún no los ha jugado, con el test).')),
      h('button', { class: 'btn btn-primario', type: 'button', onclick: () => dialogoAlumnos(clase) }, '＋ Agregar estudiantes')),
    alumnos.length
      ? h('div', { class: 'tabla-env' }, h('table', { class: 'tabla' }, h('thead', null, h('tr', null, ['Estudiante', 'Cuestionario', 'Minijuegos', 'Destaca en', 'Aprende mejor', ''].map((t) => h('th', null, t)))), h('tbody', null, filas)))
      : h('div', { class: 'vacio' }, h('span', { class: 'gran' }, '🌟'), 'Aún no hay estudiantes. Agrega al primero o pega una lista de nombres.'));

  contenido(
    migas(h('a', { href: '#/' }, 'Mis clases'), h('span', null, clase.nombre)),
    h('div', { class: 'encabezado' },
      h('div', null, h('h1', null, clase.nombre), h('p', null, `${nivelLabel(clase)}${clase.ciclo ? ' · ' + clase.ciclo : ''}`)),
      h('div', { class: 'acciones' },
        h('button', { class: 'btn btn-marca', type: 'button', onclick: () => bajar(`/clases/${id}/pdf`) }, '📄 PDF de la clase'),
        h('button', { class: 'btn btn-suave', type: 'button', onclick: () => bajar(`/clases/${id}/reportes.zip`) }, '⬇ PDF de todos (ZIP)'),
        h('button', { class: 'btn btn-suave', type: 'button', onclick: () => dialogoClase(clase) }, 'Editar'),
        h('button', { class: 'btn btn-peligro', type: 'button', onclick: async () => {
          if (!(await confirmar('¿Eliminar esta clase?', `Se borrará «${clase.nombre}» con sus ${alumnos.length} estudiantes y todos sus resultados. No se puede deshacer.`, { si: 'Sí, eliminar', peligro: true }))) return;
          try { await api(`/clases/${id}`, 'DELETE'); aviso('Clase eliminada'); location.hash = '#/'; } catch (x) { aviso(x.message, true); }
        } }, 'Eliminar'))),
    h('div', { class: 'pila' },
      h('div', { class: 'rejilla rej-lado' }, tarjetaOcta, h('div', { class: 'pila' }, tarjetaEstilo, tarjetaInt, tarjetaAsig)),
      tarjetaAlumnos,
      h('p', { class: 'nota-etica' }, 'Los resultados del grupo orientan cómo planear actividades; no sirven para clasificar ni comparar estudiantes.')));
}

/* ---------- agregar estudiantes ---------- */
function dialogoAlumnos(clase) {
  let modo = 'uno';
  const err = h('p', { class: 'error', role: 'alert', hidden: true });
  const cons = (id) => h('label', { class: 'check' }, h('input', { type: 'checkbox', name: 'consentimiento', id }), h('span', null, 'Cuento con el consentimiento informado de madres, padres o tutores para que participen.'));
  const generos = ['', ...CAT.generos];
  const formUno = h('form', { novalidate: true, onsubmit: guardarUno },
    h('label', { class: 'campo' }, 'Nombre completo', h('input', { name: 'nombre', required: true, maxlength: 160, placeholder: 'Nombre(s) y apellidos' })),
    h('div', { class: 'fila-2' },
      h('label', { class: 'campo' }, 'Edad ', h('small', null, '(opcional)'), h('input', { name: 'edad', type: 'number', min: 7, max: 18, inputmode: 'numeric', placeholder: '11' })),
      h('label', { class: 'campo' }, 'Género ', h('small', null, '(opcional)'), h('select', { name: 'genero' }, generos.map((g) => h('option', { value: g }, g || 'Sin indicar'))))),
    h('label', { class: 'campo' }, 'Matrícula o número de lista ', h('small', null, '(opcional)'), h('input', { name: 'matricula', maxlength: 30, placeholder: 'Ej. 2026-0143' })),
    cons('cons-uno'));
  const formLote = h('form', { novalidate: true, hidden: true, onsubmit: guardarLote },
    h('label', { class: 'campo' }, 'Pega la lista (un nombre por renglón)', h('textarea', { name: 'nombres', rows: 8, placeholder: 'Ana López Pérez\nLuis Hernández Cruz\n…' })),
    cons('cons-lote'));
  async function guardarUno(e) {
    e.preventDefault(); err.hidden = true;
    const f = new FormData(formUno);
    try {
      await api(`/clases/${clase.id}/alumnos`, 'POST', { nombre: (f.get('nombre') || '').trim(), edad: f.get('edad'), genero: f.get('genero'), matricula: f.get('matricula'), consentimiento: formUno.elements.consentimiento.checked });
      aviso('Estudiante guardado ✔'); const c = formUno.elements.consentimiento.checked; formUno.reset(); formUno.elements.consentimiento.checked = c; formUno.elements.nombre.focus(); hecho = true;
    } catch (x) { err.textContent = x.message; err.hidden = false; }
  }
  async function guardarLote(e) {
    e.preventDefault(); err.hidden = true;
    try {
      const r = await api(`/clases/${clase.id}/alumnos/lote`, 'POST', { nombres: formLote.elements.nombres.value, consentimiento: formLote.elements.consentimiento.checked });
      aviso(`${plural(r.creados, 'estudiante agregado', 'estudiantes agregados')} ✔`); hecho = true; cerrarDialogo();
    } catch (x) { err.textContent = x.message; err.hidden = false; }
  }
  let hecho = false;
  const tUno = h('button', { class: 'pestana', type: 'button', role: 'tab', 'aria-selected': 'true' }, 'Uno por uno');
  const tLote = h('button', { class: 'pestana', type: 'button', role: 'tab', 'aria-selected': 'false' }, 'Pegar lista');
  const cambiar = (m) => { modo = m; tUno.setAttribute('aria-selected', String(m === 'uno')); tLote.setAttribute('aria-selected', String(m === 'lote')); formUno.hidden = m !== 'uno'; formLote.hidden = m !== 'lote'; err.hidden = true; };
  tUno.onclick = () => cambiar('uno'); tLote.onclick = () => cambiar('lote');
  const dlg = abrirDialogo(`Agregar estudiantes a ${clase.nombre}`, [
    h('div', { class: 'pestanas', role: 'tablist' }, tUno, tLote), formUno, formLote, err,
    h('div', { class: 'dlg-pie' }, h('button', { class: 'btn btn-suave', type: 'button', onclick: cerrarDialogo }, 'Cerrar'),
      h('button', { class: 'btn btn-primario', type: 'button', onclick: () => (modo === 'uno' ? formUno.requestSubmit() : formLote.requestSubmit()) }, 'Guardar')),
  ]);
  dlg.addEventListener('close', () => { if (hecho) ruta(); }, { once: true });
  formUno.elements.nombre.focus();
}

/* ============================== vista: un estudiante ============================== */
async function vistaAlumno(id) {
  const D = await api(`/alumnos/${id}`);
  const { alumno, perfil, partidas, asignaciones, recomendaciones } = D;
  titulo(alumno.nombre);
  const tieneAlgo = perfil.tiene_test || perfil.juegos_hechos > 0;
  let conAuto = false;

  // Octágono con interruptor «con autopercepción»
  const caja = h('div', { class: 'octa-caja' });
  const pintarOcta = () => {
    caja.replaceChildren(Octagono.crear(datosOcta(perfil.habilidades), { mostrarAuto: conAuto, titulo: `Octágono de ${alumno.nombre}` }), Octagono.leyenda(conAuto));
  };
  const bInt = h('button', { type: 'button', 'aria-pressed': 'true', onclick: () => { conAuto = false; sync(); } }, 'Solo resultado');
  const bAuto = h('button', { type: 'button', 'aria-pressed': 'false', onclick: () => { conAuto = true; sync(); } }, 'Comparar con el test');
  const sync = () => { bInt.setAttribute('aria-pressed', String(!conAuto)); bAuto.setAttribute('aria-pressed', String(conAuto)); pintarOcta(); };
  pintarOcta();

  const lista = perfil.habilidades.map((x) => {
    const hb = CAT.porId[x.id];
    const fuente = x.fuente === 'juego' ? 'según el minijuego' : x.fuente === 'test' ? 'solo el test (provisional)' : 'sin datos';
    return h('div', { class: 'hab-fila', style: { '--hab': hb.color_pdf } },
      h('span', { class: 'hab-ico', 'aria-hidden': 'true' }, hb.icono),
      h('span', { class: 'hab-nombre' }, hb.nombre),
      h('span', { class: 'hab-valor' }, x.valor == null ? '—' : String(x.valor)),
      h('div', { class: 'hab-barra', 'aria-hidden': 'true' }, x.valor == null ? null : h('i', { style: { width: x.valor + '%' } }), h('b', { style: { left: CAT.umbrales.desarrollo + '%' } }), h('b', { style: { left: CAT.umbrales.destaca + '%' } })),
      h('div', { class: 'hab-meta' },
        x.nivel ? h('span', { class: 'insignia ' + NIVEL_TXT[x.nivel] }, x.nivel) : null,
        h('span', null, fuente), x.auto != null && x.juego != null ? h('span', null, `test: ${x.auto} · minijuego: ${x.juego}`) : null));
  });

  const tarjetaOcta = h('div', { class: 'tarjeta' },
    h('div', { class: 'encabezado', style: { marginBottom: '6px' } }, h('div', null, h('h2', null, 'Octágono de habilidades'),
      h('p', { class: 'sub', style: { marginBottom: 0 } }, 'Cada cuña es una habilidad (0-100). Se usa el resultado del minijuego; si aún no lo juega, se muestra lo que dijo en el test (provisional).')),
      tieneAlgo ? h('div', { class: 'interruptor', role: 'group', 'aria-label': 'Vista del octágono' }, bInt, bAuto) : null),
    tieneAlgo ? caja : h('div', { class: 'vacio' }, h('span', { class: 'gran' }, '🧭'), 'Todavía no hay resultados. Pulsa «Aplicar test» para empezar.'),
    tieneAlgo ? h('div', { style: { marginTop: '8px' } }, lista) : null);

  // Destaca / impulsar
  const bloques = (ids, clave, vacio) => (ids.length
    ? ids.map((i) => { const hb = CAT.porId[i]; const x = perfil.habilidades.find((a) => a.id === i); return h('div', { class: 'bloque-sugerencia', style: { '--hab': hb.color_pdf } }, h('h4', null, h('span', { 'aria-hidden': 'true' }, hb.icono), hb.nombre, h('span', { class: 'insignia', style: { marginLeft: 'auto' } }, x.valor)), h('p', null, CAT.textos[clave][i])); })
    : [h('p', { class: 'suave' }, vacio)]);
  const tDestaca = h('div', { class: 'tarjeta' }, h('h2', null, 'Destaca en'), h('p', { class: 'sub' }, 'Ideas para aprovechar sus fortalezas.'), bloques(perfil.destacadas, 'destaca', 'Aún no hay habilidades por encima de 50.'));
  const tImpulsar = h('div', { class: 'tarjeta' }, h('h2', null, 'Para impulsar'), h('p', { class: 'sub' }, 'Oportunidades de crecimiento, no limitaciones.'), bloques(perfil.impulsar, 'impulsar', 'No hay habilidades por debajo de 75 que impulsar por ahora.'));

  // Cómo aprende e intereses
  const est = perfil.estilo;
  const tEstilo = h('div', { class: 'tarjeta' },
    h('h2', null, 'Cómo prefiere aprender'),
    est ? [barraVAK(est.conteo, est.total),
      h('p', { style: { marginTop: '8px' } }, h('b', null, `Predominio ${CAT.canales[est.principal].toLowerCase()}. `), CAT.textos.estilo[est.principal]),
      est.secundario ? h('p', { style: { marginTop: '4px' } }, h('b', null, `Apoyo ${CAT.canales[est.secundario].toLowerCase()}. `), CAT.textos.estilo[est.secundario]) : null,
      est.equilibrado ? h('p', { class: 'suave' }, 'Sus tres canales están muy parejos: se beneficia de combinar formas de aprender.') : null,
      h('p', { class: 'nota-etica', style: { marginTop: '10px' } }, '💡 ' + CAT.textos.idea_estilo[est.principal])]
      : h('p', { class: 'suave' }, 'Aún no ha contestado el cuestionario.'),
    perfil.intereses.length ? [h('h3', { style: { marginTop: '16px' } }, 'Intereses'),
      h('div', { class: 'chips' }, perfil.intereses.map((i) => { const it = CAT.intereses.find((x) => x.id === i); return h('span', { class: 'chip', style: { '--hab': '#8a91c4' }, title: CAT.textos.interes[i] }, h('span', { 'aria-hidden': 'true' }, it.icono), it.nombre); })),
      h('p', { class: 'suave', style: { fontSize: '.88rem', marginTop: '6px' } }, 'Se puede aprovechar con: ' + perfil.intereses.map((i) => CAT.textos.interes[i]).join('; ') + '.')] : null);

  // Minijuegos
  const sugerida = Object.fromEntries(recomendaciones.map((r) => [r.juego, r.razon]));
  const juegosFilas = CAT.juegos.map((j) => {
    const p = partidas[j.id], asig = asignaciones[j.id];
    const hb = CAT.porId[j.habilidad];
    const estado = p ? `Jugado · ${p.puntaje} pts` : asig === 'pendiente' ? 'Asignado, por jugar' : 'Sin asignar';
    const nodoDet = p ? h('details', { class: 'det', style: { gridColumn: '1 / -1' } }, h('summary', null, 'Ver detalle de lo que hizo'), h('div', { class: 'detalle' }, detallePartida(j.id, p.detalle))) : null;
    return h('div', { class: 'juego-card', style: { '--hab': hb.color_pdf } },
      h('span', { class: 'ico', 'aria-hidden': 'true' }, j.icono),
      h('div', null, h('h4', null, j.titulo, sugerida[j.id] ? h('span', { class: 'insignia ' + (sugerida[j.id] === 'destaca' ? 'ok' : 'pend'), style: { marginLeft: '8px' } }, sugerida[j.id] === 'destaca' ? 'Sugerido: para lucirse' : 'Sugerido: para impulsar') : null),
        h('div', { class: 'meta' }, `${hb.nombre} · ${j.minutos} min · ${estado}`)),
      h('div', { class: 'botones' },
        asig === 'pendiente'
          ? h('button', { class: 'btn btn-suave btn-peq', type: 'button', onclick: async () => { await api(`/alumnos/${id}/asignaciones/${j.id}`, 'DELETE'); aviso('Asignación quitada'); ruta(); } }, 'Quitar')
          : h('button', { class: 'btn btn-marca btn-peq', type: 'button', onclick: async () => { await api(`/alumnos/${id}/asignaciones`, 'POST', { juegos: [j.id] }); aviso('Minijuego asignado ✔'); ruta(); } }, p ? 'Asignar otra vez' : 'Asignar'),
        h('button', { class: 'btn btn-primario btn-peq', type: 'button', onclick: () => Alumno.abrir(id, { juego: j.id }, ruta) }, 'Jugar ahora')),
      nodoDet);
  });
  const faltanSugeridas = recomendaciones.filter((r) => !r.asignado);
  const tJuegos = h('div', { class: 'tarjeta' },
    h('div', { class: 'encabezado', style: { marginBottom: '8px' } },
      h('div', null, h('h2', null, 'Minijuegos'), h('p', { class: 'sub', style: { marginBottom: 0 } }, 'Tú decides cuáles asignar. Las sugerencias combinan 2 minijuegos para que se luzca y 2 para impulsar, según su perfil.')),
      h('div', { class: 'acciones' },
        faltanSugeridas.length ? h('button', { class: 'btn btn-marca btn-peq', type: 'button', onclick: async () => { await api(`/alumnos/${id}/asignaciones`, 'POST', { juegos: faltanSugeridas.map((r) => r.juego) }); aviso('Sugeridos asignados ✔'); ruta(); } }, `Asignar los ${faltanSugeridas.length} sugeridos`) : null,
        h('button', { class: 'btn btn-suave btn-peq', type: 'button', onclick: async () => { await api(`/alumnos/${id}/asignaciones`, 'POST', { juegos: CAT.juegos.map((j) => j.id) }); aviso('Los 8 minijuegos quedaron asignados ✔'); ruta(); } }, 'Asignar los 8'))),
    juegosFilas);

  // Accesibilidad y notas
  const checks = Object.entries(CAT.ajustes).map(([k, txt]) => {
    const inp = h('input', { type: 'checkbox', checked: !!D.ajustes[k], onchange: async () => {
      D.ajustes[k] = inp.checked;
      try { await api(`/alumnos/${id}`, 'PUT', { accesibilidad: D.ajustes }); aviso('Apoyo actualizado ✔'); } catch (x) { aviso(x.message, true); inp.checked = !inp.checked; }
    } });
    return h('label', { class: 'check' }, inp, h('span', null, txt));
  });
  const tAcc = h('div', { class: 'tarjeta' }, h('h2', null, 'Apoyos de accesibilidad'), h('p', { class: 'sub' }, 'Se aplican solos cuando este estudiante contesta el test y los minijuegos. Ninguna actividad tiene cronómetro.'), h('div', { class: 'ajustes-lista' }, checks));
  const notas = h('textarea', { rows: 5, maxlength: 1500, placeholder: 'Lo que observas en clase: cómo participa, qué le motiva, qué apoyos le funcionan…', 'aria-label': 'Notas del docente' }, alumno.notas_docente || '');
  const tNotas = h('div', { class: 'tarjeta' }, h('h2', null, 'Tus observaciones'), h('p', { class: 'sub' }, 'Tu mirada es la más importante. Se incluyen en el PDF del estudiante.'), notas,
    h('div', { style: { marginTop: '10px' } }, h('button', { class: 'btn btn-marca', type: 'button', onclick: async () => { try { await api(`/alumnos/${id}`, 'PUT', { notas_docente: notas.value }); aviso('Notas guardadas ✔'); } catch (x) { aviso(x.message, true); } } }, 'Guardar observaciones')));

  contenido(
    migas(h('a', { href: '#/' }, 'Mis clases'), h('a', { href: `#/clase/${alumno.clase.id}` }, alumno.clase.nombre), h('span', null, alumno.nombre)),
    h('div', { class: 'encabezado' },
      h('div', null, h('h1', null, alumno.nombre), h('p', null, [alumno.clase.etiqueta, alumno.edad ? `${alumno.edad} años` : null, alumno.matricula ? `Mat. ${alumno.matricula}` : null, D.fecha_test ? `Cuestionario: ${D.fecha_test}` : null].filter(Boolean).join(' · '))),
      h('div', { class: 'acciones' },
        h('button', { class: 'btn btn-primario', type: 'button', onclick: () => Alumno.abrir(id, perfil.tiene_test ? 'auto' : 'test', ruta) }, perfil.tiene_test ? '🎮 Abrir sus misiones' : '🧭 Aplicar test'),
        perfil.tiene_test ? h('button', { class: 'btn btn-suave', type: 'button', onclick: () => Alumno.abrir(id, 'test', ruta) }, 'Repetir test') : null,
        tieneAlgo ? h('button', { class: 'btn btn-marca', type: 'button', onclick: () => bajar(`/alumnos/${id}/pdf`) }, '📄 PDF') : null,
        h('button', { class: 'btn btn-suave', type: 'button', onclick: () => dialogoEditarAlumno(D) }, 'Editar'),
        h('button', { class: 'btn btn-peligro', type: 'button', onclick: async () => {
          if (!(await confirmar('¿Eliminar a este estudiante?', `Se borrarán todos los datos y resultados de ${alumno.nombre}. No se puede deshacer.`, { si: 'Sí, eliminar', peligro: true }))) return;
          try { await api(`/alumnos/${id}`, 'DELETE'); aviso('Estudiante eliminado'); location.hash = `#/clase/${alumno.clase.id}`; } catch (x) { aviso(x.message, true); }
        } }, 'Eliminar'))),
    !tieneAlgo ? h('div', { class: 'nota-etica', style: { marginBottom: '18px' } }, 'Aún no hay resultados. Pulsa «Aplicar test»: entrega el dispositivo al estudiante (se aplican sus apoyos de accesibilidad). Cuando termine, aquí verás su octágono y las minijuegos sugeridos.') : null,
    h('div', { class: 'pila' },
      h('div', { class: 'rejilla rej-lado' }, tarjetaOcta, h('div', { class: 'pila' }, tDestaca, tImpulsar, tEstilo)),
      tJuegos,
      h('div', { class: 'rejilla rej-2' }, tNotas, tAcc),
      h('p', { class: 'nota-etica' }, 'Orientación pedagógica, no diagnóstico ni calificación. Cada habilidad se estima con pocos reactivos y depende del día y del contexto: contrástalo con tu observación.')));
}

function dialogoEditarAlumno(D) {
  const a = D.alumno;
  const err = h('p', { class: 'error', role: 'alert', hidden: true });
  const clases = h('select', { name: 'clase_id' }, h('option', { value: a.clase.id }, `${a.clase.nombre} (actual)`));
  api('/clases').then((cs) => cs.filter((c) => c.id !== a.clase.id).forEach((c) => clases.append(h('option', { value: c.id }, `${c.nombre} · ${nivelLabel(c)}`)))).catch(() => {});
  const form = h('form', { novalidate: true, onsubmit: async (e) => {
    e.preventDefault(); err.hidden = true;
    const f = new FormData(form);
    const cuerpo = { nombre: (f.get('nombre') || '').trim(), edad: f.get('edad'), genero: f.get('genero'), matricula: f.get('matricula') };
    if (Number(f.get('clase_id')) !== a.clase.id) cuerpo.clase_id = Number(f.get('clase_id'));
    try { await api(`/alumnos/${a.id}`, 'PUT', cuerpo); cerrarDialogo(); aviso('Datos actualizados ✔'); ruta(); } catch (x) { err.textContent = x.message; err.hidden = false; }
  } },
    h('label', { class: 'campo' }, 'Nombre completo', h('input', { name: 'nombre', required: true, maxlength: 160, value: a.nombre })),
    h('div', { class: 'fila-2' },
      h('label', { class: 'campo' }, 'Edad', h('input', { name: 'edad', type: 'number', min: 7, max: 18, value: a.edad || '' })),
      h('label', { class: 'campo' }, 'Género', h('select', { name: 'genero' }, ['', ...CAT.generos].map((g) => h('option', { value: g, selected: (a.genero || '') === g }, g || 'Sin indicar'))))),
    h('label', { class: 'campo' }, 'Matrícula', h('input', { name: 'matricula', maxlength: 30, value: a.matricula || '' })),
    h('label', { class: 'campo' }, 'Clase', clases), err,
    h('div', { class: 'dlg-pie' }, h('button', { class: 'btn btn-suave', type: 'button', onclick: cerrarDialogo }, 'Cancelar'), h('button', { class: 'btn btn-primario', type: 'submit' }, 'Guardar')));
  abrirDialogo('Editar estudiante', form);
}

/* ---------- detalle de lo que hizo el estudiante en un minijuego (solo lo ve el docente) ---------- */
function detallePartida(jid, d) {
  const p = (t) => h('p', null, t);
  switch (jid) {
    case 'ideas': return d.rondas.map((r) => h('p', null, h('b', null, `${r.objeto}: `), r.ideas.length ? r.ideas.join(' · ') : '(sin ideas válidas)'));
    case 'patrones': return p(`Aciertos: ${d.aciertos} de ${d.total}.`);
    case 'mensaje': return p(`Orden de las frases: ${d.orden_promedio} %. Situaciones: ${d.situaciones} puntos.`);
    case 'equipo': return [p(`Puntos: ${d.puntos}. Decisiones que tomó:`), h('ul', null, d.decisiones.map((x) => h('li', null, x)))];
    case 'torres': return d.niveles.map((n) => p(`${n.discos} discos: ${n.resuelto ? 'resuelto' : 'no resuelto'} en ${n.movimientos} movimientos (mínimo posible: ${n.optimo}); pistas usadas: ${n.pistas}.`));
    case 'espejo': return [...d.rondas.map((r) => p(`${r.tema}: predijo ${r.predijo}, logró ${r.logro}.`)),
      d.fortalezas.length ? p('Se siente fuerte en: ' + d.fortalezas.map((i) => CAT.porId[i].nombre).join(', ') + '.') : null,
      d.mejorar ? p('Quiere mejorar en: ' + CAT.porId[d.mejorar].nombre + '.') : null,
      d.apoyo ? p(`Dice que le ayuda a aprender: «${d.apoyo}».`) : null, d.animo ? p(`Ánimo durante la actividad: ${ANIMOS[d.animo]}.`) : null];
    case 'zapatos': return p(`Puntos: ${d.puntos} (reconocer emociones + elegir cómo ayudar).`);
    case 'reglas': return d.fases.map((f) => p(`Regla por ${f.regla}: ${f.aciertos} de ${f.total} aciertos; ${f.perseveraciones} errores por seguir la regla anterior.`));
    default: return null;
  }
}

document.addEventListener('DOMContentLoaded', iniciar);
