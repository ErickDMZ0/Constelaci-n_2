/* Constelación · los 8 minijuegos (uno por habilidad del octágono).
   Cada función recibe (contenido, ctx) y devuelve una Promise con los datos crudos; el SERVIDOR calcula el puntaje.
   Principios: sin cronómetro, todo se puede hacer con toques o teclado, la información nunca va solo en color,
   y el alumno recibe ánimo, no calificaciones. */
'use strict';

const Juegos = (() => {
  const CLARO = { color: '#fff', borderColor: 'rgba(255,255,255,.4)' };
  const chip = (t) => h('span', { class: 'a-chip' }, t);
  const pausa = (ms, ctx) => new Promise((r) => setTimeout(() => r(ctx.vivo()), ms));

  /** Pantalla con una pregunta de opción única. Devuelve Promise<índice elegido>. */
  function preguntar(ctx, { chip: etiqueta, cabecera = [], pregunta, opciones, ultimo = false, emojis = null, rejilla = false, atras = null }) {
    return new Promise((resolver) => {
      let sel = null;
      const op = ctx.opciones(opciones, { etiqueta: pregunta, emojis, rejilla, alElegir: (j) => { sel = j; btn.disabled = false; } });
      const btn = ctx.botonSiguiente(ultimo ? 'Terminar ✔' : 'Siguiente →', () => resolver(sel));
      ctx.montar(
        chip(etiqueta), ...cabecera,
        h('h2', { class: 'a-pregunta' }, pregunta),
        ctx.voz(ctx.textoConOpciones(pregunta, opciones)),
        op.nodo,
        h('div', { class: 'a-acciones' }, atras || h('span'), btn));
    });
  }

  /* ============================ 1 · Taller de ideas (creatividad) ============================ */
  async function ideas(c, ctx) {
    const rondas = [];
    for (let r = 0; r < c.rondas.length; r++) {
      const it = c.rondas[r];
      ctx.progreso(r / c.rondas.length, `Objeto ${r + 1} de ${c.rondas.length}`);
      const lista = await new Promise((resolver) => {
        const campos = Array.from({ length: c.maxIdeas }, (_, j) =>
          h('input', { type: 'text', maxlength: 120, placeholder: `Idea ${j + 1}`, 'aria-label': `Idea ${j + 1}`, autocomplete: 'off' }));
        const btn = ctx.botonSiguiente(r + 1 < c.rondas.length ? 'Siguiente objeto →' : 'Terminar ✔', () => resolver(campos.map((x) => x.value)));
        campos.forEach((i) => i.addEventListener('input', () => { btn.disabled = !campos.some((x) => x.value.trim().length >= 3); }));
        const consigna = `¿Para qué más podrías usar ${it.objeto}?`;
        ctx.montar(
          chip(`Objeto ${r + 1} de ${c.rondas.length}`),
          h('div', { style: { fontSize: '3.4rem', textAlign: 'center' }, 'aria-hidden': 'true' }, it.icono),
          h('h1', { class: 'a-titulo centro' }, consigna),
          h('p', { class: 'a-sub centro' }, 'Escribe todas las ideas distintas que se te ocurran, hasta 6. No hay ideas malas; las ideas con más detalle son mejores.'),
          ctx.voz(consigna),
          h('div', { class: 'a-ideas', style: { marginTop: '12px' } }, campos),
          h('div', { class: 'a-acciones' }, h('span'), btn));
        campos[0].focus();
      });
      rondas.push(lista);
    }
    return { rondas };
  }

  /* ============================ 2 · Patrones secretos (pensamiento lógico) ============================ */
  async function patrones(c, ctx) {
    const respuestas = [];
    for (let i = 0; i < c.items.length; i++) {
      const it = c.items[i];
      ctx.progreso(i / c.items.length, `Reto ${i + 1} de ${c.items.length}`);
      const cab = it.secuencia ? [h('div', { class: 'a-caja', style: { fontSize: '1.9rem', textAlign: 'center', letterSpacing: '.14em', fontWeight: 900 }, 'aria-label': `Serie: ${it.secuencia.replace('❓', 'incógnita')}` }, it.secuencia)] : [];
      respuestas.push(await preguntar(ctx, { chip: `Reto ${i + 1} de ${c.items.length}`, cabecera: cab, pregunta: it.pregunta, opciones: it.opciones, ultimo: i + 1 === c.items.length }));
    }
    return { respuestas };
  }

  /* ============================ 3 · Arma tu mensaje (comunicación) ============================ */
  function ordenarFrases(ctx, escenario, tarjetas, n, total, ultima) {
    return new Promise((resolver) => {
      let orden = tarjetas.slice();
      let foco = null;
      const ul = h('ol', { class: 'a-ordenar', 'aria-label': 'Frases del mensaje' });
      const mover = (i, d) => { const j = i + d; [orden[i], orden[j]] = [orden[j], orden[i]]; foco = `${orden[j].id}`; pintar(); };
      function pintar() {
        ul.replaceChildren(...orden.map((t, i) => h('li', null,
          h('span', null, t.texto),
          h('div', { class: 'mov' },
            h('button', { type: 'button', 'data-k': `${t.id}:u`, 'aria-label': `Subir: ${t.texto}`, disabled: i === 0, onclick: () => mover(i, -1) }, '▲'),
            h('button', { type: 'button', 'data-k': `${t.id}:d`, 'aria-label': `Bajar: ${t.texto}`, disabled: i === orden.length - 1, onclick: () => mover(i, 1) }, '▼')))));
        if (foco != null) {
          const pref = String(foco);
          const b = $(`[data-k="${pref}:u"]:not(:disabled)`, ul) || $(`[data-k="${pref}:d"]:not(:disabled)`, ul);
          if (b) b.focus();
        }
      }
      pintar();
      ctx.montar(
        chip(`Ordena el mensaje ${n} de ${total}`),
        h('h1', { class: 'a-pregunta' }, escenario),
        h('p', { class: 'a-sub' }, 'Usa las flechas ▲ ▼ para poner las frases en el orden en que el mensaje se entiende mejor.'),
        ctx.voz(`${escenario}. Frases: ${tarjetas.map((t) => t.texto).join('. ')}`),
        ul,
        h('div', { class: 'a-acciones' }, h('span'), ctx.botonSiguiente('Listo ✔', () => resolver(orden.map((t) => t.id)), false)));
    });
  }

  async function mensaje(c, ctx) {
    const ordenes = [], items = [];
    const total = c.ordenar.length + c.items.length;
    for (let i = 0; i < c.ordenar.length; i++) {
      ctx.progreso(i / total, `Mensaje ${i + 1} de ${c.ordenar.length}`);
      ordenes.push(await ordenarFrases(ctx, c.ordenar[i].escenario, c.ordenar[i].tarjetas, i + 1, c.ordenar.length));
    }
    for (let i = 0; i < c.items.length; i++) {
      ctx.progreso((c.ordenar.length + i) / total, `Situación ${i + 1} de ${c.items.length}`);
      items.push(await preguntar(ctx, { chip: `Situación ${i + 1} de ${c.items.length}`, pregunta: c.items[i].pregunta, opciones: c.items[i].opciones, ultimo: i + 1 === c.items.length }));
    }
    return { ordenes, items };
  }

  /* ============================ 4 · Misión del equipo (colaboración) ============================ */
  async function equipo(c, ctx) {
    await new Promise((resolver) => {
      ctx.progreso(0, c.titulo);
      ctx.montar(chip('Misión'), h('h1', { class: 'a-titulo' }, c.titulo), h('div', { class: 'a-caja' }, c.intro),
        ctx.voz(`${c.titulo}. ${c.intro}`),
        h('div', { class: 'a-acciones' }, h('span'), h('button', { class: 'btn btn-primario btn-grande', type: 'button', onclick: () => resolver() }, 'Empezar la misión →')));
    });
    const respuestas = [];
    for (let i = 0; i < c.pasos.length; i++) {
      const p = c.pasos[i];
      ctx.progreso(i / c.pasos.length, `Situación ${i + 1} de ${c.pasos.length}`);
      respuestas.push(await new Promise((resolver) => {
        const caja = h('div', { 'aria-live': 'polite' });
        let sel = null;
        const op = ctx.opciones(p.opciones.map((o) => o.texto), {
          etiqueta: p.situacion,
          alElegir: (j) => { sel = j; op.bloquear(); caja.replaceChildren(h('div', { class: 'a-consec' }, '➜ ' + p.opciones[j].consecuencia)); btn.disabled = false; btn.focus(); },
        });
        const btn = ctx.botonSiguiente(i + 1 < c.pasos.length ? 'Siguiente situación →' : 'Terminar misión ✔', () => resolver(sel));
        ctx.montar(chip(`${c.titulo} · ${i + 1} de ${c.pasos.length}`),
          h('h2', { class: 'a-pregunta' }, p.situacion),
          h('p', { class: 'a-sub' }, '¿Qué haces?'),
          ctx.voz(ctx.textoConOpciones(p.situacion, p.opciones.map((o) => o.texto))),
          op.nodo, caja,
          h('div', { class: 'a-acciones' }, h('span'), btn));
      }));
    }
    return { respuestas };
  }

  /* ============================ 5 · Torres mágicas (resolución de problemas) ============================ */
  const COLORES_DISCO = ['#ffd666', '#7cf0c9', '#8fb6ff', '#ff9ec0', '#c9a7ff'];

  /** Siguiente movimiento óptimo desde cualquier posición legal hacia la torre meta (índice 2). */
  function siguienteMovimiento(torres, n, meta = 2) {
    let objetivo = meta, mov = null;
    for (let d = n; d >= 1; d--) {
      const p = torres.findIndex((t) => t.includes(d));
      if (p === objetivo) continue;
      mov = { d, de: p, a: objetivo };
      objetivo = 3 - p - objetivo;
    }
    return mov;
  }

  function nivelTorres(c, ctx, n, idx, total) {
    return new Promise((resolver) => {
      const inicial = () => [Array.from({ length: n }, (_, k) => n - k), [], []];
      let torres = inicial(), sel = null, movs = 0, pistas = 0, resuelto = false;
      const msg = h('p', { class: 'a-pista', 'aria-live': 'polite', style: { minHeight: '46px' } }, `Mueve todos los discos a la torre 3. Un disco grande nunca puede ir sobre uno más pequeño.`);
      const cont = h('span', { class: 'a-sub', 'aria-live': 'off' });
      const zona = h('div', { class: 'torres' });
      const pie = h('div', { class: 'a-acciones' });

      const describir = (p) => (torres[p].length ? `Torre ${p + 1}: discos ${torres[p].slice().reverse().join(', ')} de arriba hacia abajo` : `Torre ${p + 1}: vacía`);
      function pintar() {
        zona.replaceChildren(...torres.map((t, p) => h('button', { class: 'torre', type: 'button', 'aria-pressed': String(sel === p), 'aria-label': describir(p) + (sel === p ? ' (seleccionada)' : ''), disabled: resuelto, onclick: () => tocar(p) },
          h('span', { class: 'num', 'aria-hidden': 'true' }, `Torre ${p + 1}`),
          t.map((d) => h('div', { class: 'disco', 'aria-hidden': 'true', style: { width: (36 + (d / n) * 58) + '%', background: COLORES_DISCO[d - 1] } }, String(d))))));
        cont.textContent = `Movimientos: ${movs} · Pistas usadas: ${pistas} de ${c.pistasMax}`;
      }
      function tocar(p) {
        if (resuelto) return;
        if (sel === null) {
          if (!torres[p].length) { msg.textContent = `La torre ${p + 1} está vacía. Elige una torre que tenga discos.`; return; }
          sel = p; msg.textContent = `Elegiste la torre ${p + 1}. Ahora elige a qué torre quieres mover su disco de arriba.`; pintar(); return;
        }
        if (sel === p) { sel = null; msg.textContent = 'Quitaste la selección.'; pintar(); return; }
        const d = torres[sel][torres[sel].length - 1];
        const destino = torres[p][torres[p].length - 1];
        if (destino !== undefined && destino < d) {
          msg.textContent = `No se puede: el disco ${d} es más grande que el disco ${destino}. Prueba con otra torre.`; sel = null; pintar(); return;
        }
        torres[sel].pop(); torres[p].push(d); movs += 1; msg.textContent = `Moviste el disco ${d} a la torre ${p + 1}.`; sel = null;
        if (torres[2].length === n) { resuelto = true; pintar(); ganar(); return; }
        pintar();
      }
      function ganar() {
        msg.textContent = `¡Lo lograste en ${movs} movimientos! 🎉`;
        pie.replaceChildren(h('span'), ctx.botonSiguiente(idx + 1 < total ? 'Siguiente nivel →' : 'Terminar ✔', () => resolver({ discos: n, movimientos: movs, resuelto: true, pistas }), false));
      }
      const btnPista = h('button', { class: 'btn btn-suave', type: 'button', style: CLARO, onclick: () => {
        if (pistas >= c.pistasMax) { msg.textContent = 'Ya usaste todas las pistas de este nivel. ¡Tú puedes!'; return; }
        const m = siguienteMovimiento(torres, n);
        if (!m) return;
        pistas += 1; msg.textContent = `💡 Pista: mueve el disco ${m.d} de la torre ${m.de + 1} a la torre ${m.a + 1}.`; pintar();
      } }, '💡 Pista');
      const btnReiniciar = h('button', { class: 'btn btn-suave', type: 'button', style: CLARO, onclick: () => {
        torres = inicial(); sel = null; msg.textContent = 'Volviste a empezar. Los movimientos y las pistas anteriores siguen contando.'; pintar();
      } }, '↺ Reiniciar');
      const btnSaltar = h('button', { class: 'btn btn-suave', type: 'button', style: CLARO, onclick: () => resolver({ discos: n, movimientos: movs, resuelto: false, pistas }) }, 'Saltar este nivel');
      pie.append(h('div', { class: 'acciones' }, btnPista, btnReiniciar), btnSaltar);

      pintar();
      ctx.montar(chip(`Nivel ${idx + 1} de ${total} · ${n} discos`), h('h1', { class: 'a-titulo' }, 'Mueve la torre'),
        ctx.voz(`Mueve todos los discos a la torre 3. Un disco grande nunca puede ir sobre uno pequeño. Puedes usar las teclas 1, 2 y 3.`),
        h('div', { class: 'torres-info' }, cont, h('span', { class: 'suave' }, 'Teclas 1, 2 y 3 también sirven')),
        zona, msg, pie);
      // Se registra DESPUÉS de montar(): montar() limpia los atajos de la pantalla anterior.
      const alTecla = (e) => { if (['1', '2', '3'].includes(e.key) && !e.ctrlKey && !e.metaKey && !e.altKey) { e.preventDefault(); tocar(Number(e.key) - 1); } };
      document.addEventListener('keydown', alTecla);
      ctx.alLimpiar(() => document.removeEventListener('keydown', alTecla));
    });
  }

  async function torres(c, ctx) {
    const niveles = [];
    for (let i = 0; i < c.niveles.length; i++) {
      ctx.progreso(i / c.niveles.length, `Nivel ${i + 1} de ${c.niveles.length}`);
      niveles.push(await nivelTorres(c, ctx, c.niveles[i], i, c.niveles.length));
    }
    return { niveles };
  }

  /* ============================ 6 · Mi espejo (autoconocimiento) ============================ */
  async function espejo(c, ctx) {
    const predicciones = [], respuestas = [];
    const totalPasos = c.rondas.length + 1;
    for (let r = 0; r < c.rondas.length; r++) {
      const ronda = c.rondas[r];
      const n = ronda.preguntas.length;
      ctx.progreso(r / totalPasos, `Ronda ${r + 1} de ${c.rondas.length}`);
      const pred = await preguntar(ctx, {
        chip: `Ronda ${r + 1} · ${ronda.tema}`,
        cabecera: [h('div', { style: { fontSize: '3rem', textAlign: 'center' }, 'aria-hidden': 'true' }, ronda.icono)],
        pregunta: `Vas a contestar ${n} preguntas de «${ronda.tema}». ¿Cuántas crees que vas a acertar?`,
        opciones: Array.from({ length: n + 1 }, (_, k) => `${k} ${k === 1 ? 'acierto' : 'aciertos'}`), rejilla: true,
      });
      predicciones.push(pred);
      const rs = [];
      for (let q = 0; q < n; q++) {
        rs.push(await preguntar(ctx, { chip: `${ronda.tema} · pregunta ${q + 1} de ${n}`, pregunta: ronda.preguntas[q].pregunta, opciones: ronda.preguntas[q].opciones, ultimo: q + 1 === n }));
      }
      respuestas.push(rs);
      const { logro, total } = await ctx.api(`/alumnos/${ctx.id}/juegos/espejo/ronda`, 'POST', { ronda: r, respuestas: rs });
      await new Promise((resolver) => {
        const dif = logro - pred;
        const frase = dif === 0 ? '¡Te conoces muy bien! Tu predicción fue justo lo que pasó.'
          : dif > 0 ? '¡Lograste más de lo que pensabas! A veces somos mejores de lo que creemos.'
            : 'Esperabas acertar más. Eso también ayuda a aprender: ¿qué crees que pasó?';
        ctx.montar(chip(`Ronda ${r + 1} · ${ronda.tema}`), h('h1', { class: 'a-titulo' }, 'Compara tu predicción'),
          h('div', { class: 'a-caja', style: { fontSize: '1.2em' } }, `Predijiste: ${pred} · Lograste: ${logro} de ${total}`),
          h('p', { class: 'a-sub' }, frase), ctx.voz(`Predijiste ${pred}. Lograste ${logro} de ${total}. ${frase}`),
          h('div', { class: 'a-acciones' }, h('span'), ctx.botonSiguiente(r + 1 < c.rondas.length ? 'Siguiente ronda →' : 'Seguir →', () => resolver(), false)));
      });
    }
    // Cartas de fortalezas y metas (no se puntúan: las lee el docente)
    ctx.progreso(c.rondas.length / totalPasos, 'Mis cartas');
    const metas = await new Promise((resolver) => {
      const fort = new Set();
      let mejorar = null, animo = null;
      const apoyo = h('input', { type: 'text', maxlength: 160, placeholder: 'Ej. que me expliquen con dibujos', 'aria-label': 'Algo que me ayuda a aprender' });
      const cuenta = h('p', { class: 'a-sub', 'aria-live': 'polite' }, 'Elegiste 0 de 3');
      const gFort = h('div', { class: 'a-opciones a-rejilla', role: 'group', 'aria-label': 'Mis fortalezas' }, c.fortalezas.map((f) => {
        const b = h('button', { class: 'a-opcion', type: 'button', 'aria-pressed': 'false' }, h('span', { class: 'emo', 'aria-hidden': 'true' }, f.icono), h('span', null, h('b', null, f.nombre), h('br'), f.frase));
        b.addEventListener('click', () => {
          if (fort.has(f.id)) fort.delete(f.id); else if (fort.size < 3) fort.add(f.id); else return aviso('Elige solo 3 fortalezas.');
          b.setAttribute('aria-pressed', String(fort.has(f.id))); cuenta.textContent = `Elegiste ${fort.size} de 3`;
        });
        return b;
      }));
      const bMej = c.fortalezas.map((f) => {
        const b = h('button', { class: 'a-opcion', type: 'button', 'aria-pressed': 'false' }, h('span', { class: 'emo', 'aria-hidden': 'true' }, f.icono), h('span', null, f.nombre));
        b.addEventListener('click', () => { mejorar = mejorar === f.id ? null : f.id; bMej.forEach((x, k) => x.setAttribute('aria-pressed', String(mejorar === c.fortalezas[k].id))); });
        return b;
      });
      const gMej = h('div', { class: 'a-opciones a-rejilla', role: 'group', 'aria-label': 'Quiero mejorar' }, bMej);
      const opAnimo = ctx.opciones(c.animos.map((a) => a.texto), { emojis: c.animos.map((a) => a.emoji), etiqueta: '¿Cómo te sentiste?', alElegir: (j) => { animo = c.animos[j].valor; } });
      opAnimo.nodo.classList.add('a-escala'); opAnimo.nodo.style.gridTemplateColumns = 'repeat(5, 1fr)';
      ctx.montar(chip('Mis cartas'), h('h1', { class: 'a-titulo' }, 'Mis cartas de fortalezas'),
        h('p', { class: 'a-sub' }, 'Ahora cuéntanos de ti. Aquí tampoco hay respuestas buenas ni malas.'),
        ctx.voz('Mis cartas de fortalezas. Elige hasta tres cosas en las que te sientes fuerte, una en la que quieres mejorar, y cuéntanos qué te ayuda a aprender.'),
        h('h2', { class: 'a-pregunta' }, '¿En qué te sientes fuerte? (hasta 3)'), gFort, cuenta,
        h('h2', { class: 'a-pregunta' }, '¿En qué te gustaría mejorar? (una)'), gMej,
        h('h2', { class: 'a-pregunta' }, '¿Qué te ayuda a aprender?'), h('div', { class: 'a-ideas' }, apoyo),
        h('h2', { class: 'a-pregunta' }, '¿Cómo te sentiste en estas actividades?'), opAnimo.nodo,
        h('div', { class: 'a-acciones' }, h('span'), ctx.botonSiguiente('Terminar ✔', () => resolver({ fortalezas: Array.from(fort), mejorar, apoyo: apoyo.value.trim(), animo }), false)));
    });
    return { predicciones, respuestas, metas };
  }

  /* ============================ 7 · Ponte en sus zapatos (empatía) ============================ */
  async function zapatos(c, ctx) {
    const respuestas = [];
    for (let i = 0; i < c.escenarios.length; i++) {
      const e = c.escenarios[i];
      ctx.progreso(i / c.escenarios.length, `Persona ${i + 1} de ${c.escenarios.length}`);
      respuestas.push(await new Promise((resolver) => {
        let eSel = null, aSel = null;
        const act = () => { btn.disabled = eSel === null || aSel === null; };
        const opE = ctx.opciones(e.emociones.map((x) => x.texto), { emojis: e.emociones.map((x) => x.emoji), rejilla: true, etiqueta: `¿Cómo se siente ${e.persona.nombre}?`, alElegir: (j) => { eSel = j; act(); } });
        const opA = ctx.opciones(e.acciones, { etiqueta: '¿Qué harías para ayudar?', alElegir: (j) => { aSel = j; act(); } });
        const btn = ctx.botonSiguiente(i + 1 < c.escenarios.length ? 'Siguiente persona →' : 'Terminar ✔', () => resolver({ e: eSel, a: aSel }));
        ctx.montar(chip(`Persona ${i + 1} de ${c.escenarios.length}`),
          h('div', { style: { display: 'flex', gap: '14px', alignItems: 'center' } },
            h('span', { style: { fontSize: '3.2rem' }, 'aria-hidden': 'true' }, e.persona.emoji), h('h1', { class: 'a-titulo', style: { margin: 0 } }, e.persona.nombre)),
          h('div', { class: 'a-caja' }, e.historia),
          ctx.voz(`${e.persona.nombre}. ${e.historia}`),
          h('h2', { class: 'a-pregunta' }, `¿Cómo crees que se siente ${e.persona.nombre}?`), opE.nodo,
          h('h2', { class: 'a-pregunta' }, '¿Qué harías para ayudar?'), opA.nodo,
          h('div', { class: 'a-acciones' }, h('span'), btn));
      }));
    }
    return { respuestas };
  }

  /* ============================ 8 · Cambio de reglas (adaptabilidad) ============================ */
  const COLORES = [{ n: 'rojo', hex: '#e5484d' }, { n: 'azul', hex: '#3b82f6' }, { n: 'verde', hex: '#16a37f' }, { n: 'amarillo', hex: '#f5b800' }];
  const FORMAS = ['círculo', 'cuadrado', 'triángulo', 'estrella'];

  function figura(f, hex) {
    const at = { fill: hex, stroke: '#10143a', 'stroke-width': 3, 'stroke-linejoin': 'round' };
    const s = svg('svg', { viewBox: '0 0 64 64', 'aria-hidden': 'true' });
    if (f === 0) s.append(svg('circle', { cx: 32, cy: 32, r: 22, ...at }));
    else if (f === 1) s.append(svg('rect', { x: 10, y: 10, width: 44, height: 44, rx: 4, ...at }));
    else if (f === 2) s.append(svg('polygon', { points: '32,8 58,54 6,54', ...at }));
    else {
      const p = [];
      for (let k = 0; k < 10; k++) { const r = k % 2 ? 11 : 27, a = (-90 + k * 36) * Math.PI / 180; p.push((32 + r * Math.cos(a)).toFixed(1) + ',' + (34 + r * Math.sin(a)).toFixed(1)); }
      s.append(svg('polygon', { points: p.join(' '), ...at }));
    }
    return s;
  }
  const etiquetaCarta = (ci, fi) => `${FORMAS[fi]} ${COLORES[ci].n}`;
  const cartaNodo = (tag, ci, fi, props) => h(tag, { class: 'carta', ...props }, figura(fi, COLORES[ci].hex), h('span', null, etiquetaCarta(ci, fi)));

  async function reglas(c, ctx) {
    const fases = [];
    const totalEnsayos = c.fases.reduce((s, f) => s + f.ensayos, 0);
    let hechos = 0, previa = null;
    for (let f = 0; f < c.fases.length; f++) {
      const { regla, ensayos } = c.fases[f];
      const nombre = regla === 'color' ? 'COLOR' : 'FORMA';
      // Aviso visual y en texto (al inicio y en cada cambio de regla)
      await new Promise((resolver) => {
        ctx.progreso(hechos / totalEnsayos, f === 0 ? 'Reglas' : '¡Cambio de regla!');
        ctx.montar(chip(f === 0 ? 'Regla inicial' : '¡Cambio de regla! 🔁'),
          h('h1', { class: 'a-titulo' }, f === 0 ? `Clasifica por ${nombre}` : `Ahora clasifica por ${nombre}`),
          h('div', { class: 'a-caja' }, regla === 'color'
            ? 'Pon cada tarjeta que aparezca en la pila que tenga el mismo COLOR, sin importar la forma.'
            : 'Pon cada tarjeta que aparezca en la pila que tenga la misma FORMA, sin importar el color.'),
          f > 0 ? h('div', { class: 'a-caja' }, `Antes se clasificaba por ${previa === 'color' ? 'COLOR' : 'FORMA'}. Fíjate bien: la regla cambió.`) : h('div', { class: 'a-caja' }, 'Ojo: durante la actividad la regla puede cambiar. Siempre verás arriba cuál es la regla que vale ahora.'),
          ctx.voz(f === 0 ? `Clasifica por ${nombre}.` : `Cambio de regla. Ahora clasifica por ${nombre}.`),
          h('div', { class: 'a-acciones' }, h('span'), h('button', { class: 'btn btn-primario btn-grande', type: 'button', onclick: () => resolver() }, 'Entendido ✔')));
      });
      // Ensayos
      const res = await new Promise((resolver) => {
        let n = 0, aciertos = 0, pers = 0, bloqueado = false, ci = 0, fi = 1, ultimo = '';
        const retro = h('p', { class: 'retro', 'aria-live': 'assertive' });
        const viva = h('div', { class: 'carta carta-viva', 'aria-live': 'polite' });
        const meta = h('div', { class: 'cartas-meta' }, [0, 1, 2, 3].map((k) =>
          cartaNodo('button', k, k, { type: 'button', 'aria-label': `Pila ${k + 1}: ${etiquetaCarta(k, k)}`, onclick: () => elegir(k) })));
        function nueva() {
          let clave;
          do { ci = Math.floor(Math.random() * 4); do { fi = Math.floor(Math.random() * 4); } while (fi === ci); clave = `${ci}${fi}`; } while (clave === ultimo);
          ultimo = clave;
          viva.replaceChildren(figura(fi, COLORES[ci].hex), h('span', null, `Tarjeta: ${etiquetaCarta(ci, fi)}`));
          ctx.progreso((hechos + n) / totalEnsayos, `Tarjeta ${hechos + n + 1} de ${totalEnsayos}`);
          bloqueado = false; retro.textContent = ''; retro.className = 'retro';
        }
        function elegir(k) {
          if (bloqueado) return;
          bloqueado = true;
          const ok = (regla === 'color' ? ci : fi) === k;
          if (ok) { aciertos += 1; retro.textContent = '✔ ¡Bien!'; retro.className = 'retro bien'; }
          else {
            if (previa && (previa === 'color' ? ci : fi) === k) pers += 1;
            retro.textContent = `✘ Esa no. Recuerda: la regla es ${nombre}.`; retro.className = 'retro mal';
          }
          pausa(ok ? 650 : 1300, ctx).then((vivo) => {
            if (!vivo) return;
            n += 1;
            if (n < ensayos) nueva(); else resolver({ regla, aciertos, perseveraciones: pers });
          });
        }
        ctx.montar(chip(`Regla ${f + 1} de ${c.fases.length}`),
          h('div', { class: 'regla-banner' }, regla === 'color' ? '🎨 Regla ahora: clasifica por COLOR' : '🔷 Regla ahora: clasifica por FORMA'),
          viva, retro,
          h('p', { class: 'a-sub centro' }, 'Toca la pila donde va la tarjeta:'), meta);
        nueva();
      });
      hechos += ensayos; previa = regla;
      fases.push(res);
    }
    return { fases };
  }

  return { ideas, patrones, mensaje, equipo, torres, espejo, zapatos, reglas };
})();
