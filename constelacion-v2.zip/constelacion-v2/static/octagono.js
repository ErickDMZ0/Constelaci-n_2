/* Constelación · Octágono de 8 habilidades.
   Cada habilidad ocupa una de las 8 cuñas; el largo de la cuña es su valor (0-100). El borde exterior de cada cuña
   queda paralelo a un lado del octágono (el apotema es el valor), así los anillos del fondo se leen como una regla.
   Anillos punteados: 50 (en desarrollo) y 75 (destaca). Opcional: línea punteada con la autopercepción del test. */
const Octagono = (() => {
  const GRAD = Math.PI / 180;
  const COS22 = Math.cos(22.5 * GRAD);

  const pto = (cx, cy, r, grados) => [cx + r * Math.cos(grados * GRAD), cy + r * Math.sin(grados * GRAD)];
  const pts = (arr) => arr.map((p) => p[0].toFixed(1) + ',' + p[1].toFixed(1)).join(' ');
  const centroAngulo = (i) => -90 + i * 45;

  function anillo(cx, cy, R, nivel) {
    const rv = (R * nivel / 100) / COS22;
    return pts([0, 1, 2, 3, 4, 5, 6, 7].map((k) => pto(cx, cy, rv, -112.5 + 45 * k)));
  }

  function cuna(cx, cy, R, i, valor) {
    const a = R * Math.max(valor, 5) / 100;       // apotema
    const rv = a / COS22;
    const c = centroAngulo(i);
    return pts([[cx, cy], pto(cx, cy, rv, c - 22.5), pto(cx, cy, rv, c + 22.5)]);
  }

  /** datos: [{id, nombre, corto, icono, color, valor, auto, sub}] en el orden del octágono.
   *  opciones: {mini, mostrarAuto, leyenda, titulo} */
  function crear(datos, opciones = {}) {
    const mini = !!opciones.mini;
    const W = mini ? 200 : 560, H = mini ? 200 : 490;
    const cx = W / 2, cy = mini ? 100 : 248, R = mini ? 86 : 135;
    const resumen = datos.map((d) => `${d.nombre}: ${d.valor == null ? 'sin datos' : d.valor}`).join('; ');
    const s = svg('svg', { class: 'octa', viewBox: `0 0 ${W} ${H}`, role: 'img',
      'aria-label': `${opciones.titulo || 'Octágono de habilidades'}. ${resumen}.` });

    // Fondo: anillos y radios
    for (const nivel of [25, 50, 75, 100]) {
      const marcado = nivel === 50 || nivel === 75;
      s.append(svg('polygon', { points: anillo(cx, cy, R, nivel), fill: nivel === 100 ? '#f7f8ff' : 'none',
        stroke: marcado ? '#8a91c4' : '#d3d8ee', 'stroke-width': marcado ? 1.4 : 1, 'stroke-dasharray': marcado ? '5 4' : null }));
    }
    for (let k = 0; k < 8; k++) {
      const [x, y] = pto(cx, cy, R / COS22, -112.5 + 45 * k);
      s.append(svg('line', { x1: cx, y1: cy, x2: x.toFixed(1), y2: y.toFixed(1), stroke: '#d3d8ee', 'stroke-width': 1 }));
    }

    // Cuñas de valor
    datos.forEach((d, i) => {
      const txt = `${d.nombre}: ${d.valor == null ? 'sin datos' : d.valor}${d.sub ? ' · ' + d.sub : ''}`;
      const g = svg('g', { 'data-hab': d.id }, svg('title', null, txt));
      if (d.valor == null) {
        g.append(svg('polygon', { points: cuna(cx, cy, R, i, 14), fill: 'none', stroke: '#aab0d6', 'stroke-width': 1.5, 'stroke-dasharray': '3 3' }));
      } else {
        g.append(svg('polygon', { points: cuna(cx, cy, R, i, d.valor), fill: d.color, 'fill-opacity': 0.88, stroke: '#fff', 'stroke-width': 2, 'stroke-linejoin': 'round' }));
      }
      s.append(g);
    });

    // Autopercepción (línea punteada sobre cada radio)
    if (opciones.mostrarAuto) {
      const puntos = datos.map((d, i) => (d.auto == null ? null : pto(cx, cy, R * Math.max(d.auto, 4) / 100, centroAngulo(i))));
      const validos = puntos.filter(Boolean);
      if (validos.length > 2) {
        s.append(svg('polygon', { points: pts(validos), fill: 'none', stroke: '#1b2150', 'stroke-width': 2, 'stroke-dasharray': '6 4', 'stroke-linejoin': 'round' }));
      }
      validos.forEach((p) => s.append(svg('circle', { cx: p[0].toFixed(1), cy: p[1].toFixed(1), r: 4.5, fill: '#fff', stroke: '#1b2150', 'stroke-width': 2 })));
    }

    // Etiquetas (icono + nombre + valor); en el modo mini no hay etiquetas
    if (!mini) {
      datos.forEach((d, i) => {
        const ang = centroAngulo(i);
        const eje = i % 2 === 0;                            // arriba, derecha, abajo, izquierda
        const lado = Math.cos(ang * GRAD);
        const dist = eje ? R + (Math.abs(lado) > 0.5 ? 26 : 44) : R + 56;
        let [x, y] = pto(cx, cy, dist, ang);
        const anclaje = Math.abs(lado) < 0.2 ? 'middle' : lado > 0 ? 'start' : 'end';
        if (anclaje === 'start' && eje) x = cx + R + 22;
        if (anclaje === 'end' && eje) x = cx - R - 22;
        const sinDato = d.valor == null;
        const t = svg('g', { 'aria-hidden': 'true' },
          svg('text', { x: x.toFixed(1), y: (y - 10).toFixed(1), 'text-anchor': anclaje, 'font-size': 21 }, d.icono),
          svg('text', { x: x.toFixed(1), y: (y + 9).toFixed(1), 'text-anchor': anclaje, 'font-size': 13.5, 'font-weight': 800, fill: '#1b2150' }, d.corto || d.nombre),
          svg('text', { x: x.toFixed(1), y: (y + 26).toFixed(1), 'text-anchor': anclaje, 'font-size': 13, 'font-weight': 900, fill: sinDato ? '#8a91c4' : d.color },
            sinDato ? 'sin datos' : String(d.valor)),
          d.sub ? svg('text', { x: x.toFixed(1), y: (y + 41).toFixed(1), 'text-anchor': anclaje, 'font-size': 11, fill: '#646b96' }, d.sub) : null);
        s.append(t);
      });
    }
    return s;
  }

  /** Leyenda en HTML (se coloca debajo del octágono). */
  function leyenda(mostrarAuto) {
    return h('div', { class: 'octa-leyenda' },
      h('span', null, '┈ anillos punteados: 50 (en desarrollo) y 75 (destaca)'),
      mostrarAuto ? h('span', null, h('i'), 'Lo que el estudiante dice de sí (test)') : null,
      h('span', null, 'Cuña de color: valor integrado'));
  }

  return { crear, leyenda };
})();
