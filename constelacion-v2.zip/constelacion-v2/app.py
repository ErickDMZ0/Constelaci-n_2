# -*- coding: utf-8 -*-
"""Constelación v2 · servidor Flask (API + archivos estáticos)."""
import io
import json
import os
import re
import secrets
import time
import unicodedata
import zipfile
from collections import defaultdict
from functools import wraps

from flask import Flask, abort, jsonify, request, send_file, session
from werkzeug.security import check_password_hash, generate_password_hash

from dotenv_lite import cargar_env

cargar_env()

import catalogo as K  # noqa: E402
import cuestionario as Q  # noqa: E402
import db  # noqa: E402
import juegos as J  # noqa: E402
import perfil as P  # noqa: E402
from report import generar_pdf_alumno, generar_pdf_clase  # noqa: E402

BASE = os.path.dirname(os.path.abspath(__file__))
app = Flask(__name__, static_folder=os.path.join(BASE, "static"), static_url_path="")


def _clave_secreta():
    clave = os.getenv("SECRET_KEY")
    if clave:
        return clave
    ruta = os.path.join(BASE, ".secret_key")
    if os.path.exists(ruta):
        return open(ruta, encoding="utf-8").read().strip()
    clave = secrets.token_hex(32)
    with open(ruta, "w", encoding="utf-8") as f:
        f.write(clave)
    return clave


app.config.update(
    SECRET_KEY=_clave_secreta(),
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=os.getenv("COOKIE_SECURE", "0") == "1",
    MAX_CONTENT_LENGTH=256 * 1024,
    JSON_AS_ASCII=False,
)
app.teardown_appcontext(db.cerrar)

GENEROS = ("Femenino", "Masculino", "Otro", "Prefiero no decirlo")
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


# ------------------------------------------------------------------ utilidades
def error(msg, codigo=400):
    return jsonify({"error": msg}), codigo


def datos_json():
    datos = request.get_json(silent=True)
    if not isinstance(datos, dict):
        abort(400, description="Se esperaba un JSON válido")
    return datos


def texto(datos, campo, minimo=1, maximo=160, etiqueta=None):
    valor = str(datos.get(campo, "") or "").strip()
    if not minimo <= len(valor) <= maximo:
        raise ValueError(f"«{etiqueta or campo}» debe tener entre {minimo} y {maximo} caracteres")
    return valor


@app.errorhandler(400)
@app.errorhandler(404)
@app.errorhandler(413)
@app.errorhandler(405)
def _error_http(e):
    return error(getattr(e, "description", "Solicitud inválida"), e.code)


def login_requerido(fn):
    @wraps(fn)
    def envoltura(*a, **kw):
        if "docente_id" not in session:
            return error("Inicia sesión para continuar", 401)
        return fn(*a, **kw)
    return envoltura


def docente_actual():
    return db.consulta("SELECT id, nombre, correo, escuela FROM docentes WHERE id = %s",
                       (session["docente_id"],), uno=True)


def clase_propia(clase_id):
    return db.consulta("SELECT * FROM clases WHERE id = %s AND docente_id = %s", (clase_id, session["docente_id"]), uno=True)


def alumno_propio(alumno_id):
    return db.consulta(
        "SELECT a.*, c.nombre AS clase_nombre, c.nivel, c.grado FROM alumnos a JOIN clases c ON c.id = a.clase_id "
        "WHERE a.id = %s AND a.docente_id = %s", (alumno_id, session["docente_id"]), uno=True)


def fecha_corta(valor):
    try:
        y, m, d = str(valor or "")[:10].split("-")
        return f"{d}/{m}/{y}"
    except ValueError:
        return None


def _ajustes(alumno):
    try:
        datos = json.loads(alumno.get("accesibilidad_json") or "{}")
    except ValueError:
        datos = {}
    return {k: bool(datos.get(k)) for k in K.AJUSTES_ACCESIBILIDAD}


def cargar_datos(ids):
    """Test, partidas más recientes y asignaciones de una lista de alumnos."""
    datos = {i: {"resultado": None, "fecha_test": None, "partidas": {}, "asig": {}} for i in ids}
    if not ids:
        return datos
    ph, args = db.marcadores(len(ids)), tuple(ids)
    for f in db.consulta("SELECT alumno_id, resultado_json, completada_en FROM evaluaciones "
                         f"WHERE estado = 'completada' AND alumno_id IN ({ph}) ORDER BY id", args):
        d = datos[f["alumno_id"]]
        d["resultado"], d["fecha_test"] = json.loads(f["resultado_json"]), f["completada_en"]
    for f in db.consulta("SELECT alumno_id, juego_id, puntaje, detalle_json, creada_en FROM partidas "
                         f"WHERE alumno_id IN ({ph}) ORDER BY id", args):
        datos[f["alumno_id"]]["partidas"][f["juego_id"]] = {
            "puntaje": int(f["puntaje"]), "detalle": json.loads(f["detalle_json"] or "{}"), "fecha": f["creada_en"]}
    for f in db.consulta(f"SELECT alumno_id, juego_id, estado FROM asignaciones WHERE alumno_id IN ({ph})", args):
        datos[f["alumno_id"]]["asig"][f["juego_id"]] = f["estado"]
    return datos


def _resumen_alumno(a, d):
    pf = P.perfil_alumno(d["resultado"], d["partidas"])
    return {
        "id": a["id"], "nombre": a["nombre"], "edad": a["edad"], "genero": a["genero"], "matricula": a["matricula"],
        "test": pf["tiene_test"], "juegos_hechos": pf["juegos_hechos"], "juegos_total": pf["juegos_total"],
        "destacadas": pf["destacadas"], "estilo": pf["estilo"]["principal"] if pf["estilo"] else None,
        "pendientes": [j for j, e in d["asig"].items() if e == "pendiente"],
        "ajustes": any(_ajustes(a).values()),
    }, pf


# ------------------------------------------------------------------ páginas
@app.route("/")
def inicio():
    return app.send_static_file("index.html")


# ------------------------------------------------------------------ sesión
_intentos = defaultdict(list)


def _limitar(clave, maximo=10, ventana=600):
    ahora = time.time()
    _intentos[clave] = [t for t in _intentos[clave] if ahora - t < ventana]
    return len(_intentos[clave]) >= maximo


@app.post("/api/registro")
def registro():
    d = datos_json()
    try:
        nombre = texto(d, "nombre", 3, 120, "Nombre")
        escuela = texto(d, "escuela", 3, 160, "Escuela")
        correo = texto(d, "correo", 5, 160, "Correo").lower()
        clave = str(d.get("password", ""))
    except ValueError as e:
        return error(str(e))
    if not EMAIL_RE.match(correo):
        return error("Escribe un correo válido")
    if len(clave) < 8 or len(clave) > 100:
        return error("La contraseña debe tener al menos 8 caracteres")
    if db.consulta("SELECT id FROM docentes WHERE correo = %s", (correo,), uno=True):
        return error("Ya existe una cuenta con ese correo", 409)
    nuevo = db.ejecutar("INSERT INTO docentes (nombre, correo, escuela, password_hash) VALUES (%s, %s, %s, %s)",
                        (nombre, correo, escuela, generate_password_hash(clave)))
    session.clear()
    session["docente_id"] = nuevo
    return jsonify(docente_actual()), 201


@app.post("/api/login")
def login():
    d = datos_json()
    correo = str(d.get("correo", "")).strip().lower()
    clave_limite = f"{request.remote_addr}|{correo}"
    if _limitar(clave_limite):
        return error("Demasiados intentos. Espera unos minutos e inténtalo de nuevo.", 429)
    fila = db.consulta("SELECT * FROM docentes WHERE correo = %s", (correo,), uno=True)
    if not fila or not check_password_hash(fila["password_hash"], str(d.get("password", ""))):
        _intentos[clave_limite].append(time.time())
        return error("Correo o contraseña incorrectos", 401)
    session.clear()
    session["docente_id"] = fila["id"]
    return jsonify(docente_actual())


@app.post("/api/logout")
def logout():
    session.clear()
    return jsonify({"ok": True})


@app.get("/api/yo")
@login_requerido
def yo():
    fila = docente_actual()
    if not fila:
        session.clear()
        return error("Sesión inválida", 401)
    return jsonify(fila)


@app.get("/api/catalogo")
@login_requerido
def catalogo():
    return jsonify({
        "habilidades": K.HABILIDADES, "juegos": J.CATALOGO, "niveles": K.NIVELES, "intereses": K.INTERESES,
        "canales": K.CANALES, "ajustes": K.AJUSTES_ACCESIBILIDAD, "generos": GENEROS,
        "umbrales": {"destaca": K.UMBRAL_DESTACA, "desarrollo": K.UMBRAL_DESARROLLO},
        "textos": {"destaca": K.TIPS_DESTACA, "impulsar": K.TIPS_IMPULSAR, "interes": K.TIPS_INTERES,
                   "estilo": K.DESCRIPCION_ESTILO, "idea_estilo": K.IDEAS_ESTILO},
    })


# ------------------------------------------------------------------ clases
def _clase_json(c, n_alumnos=0, n_test=0):
    return {"id": c["id"], "nombre": c["nombre"], "nivel": c["nivel"], "grado": c["grado"], "ciclo": c["ciclo"],
            "alumnos": n_alumnos, "con_test": n_test, "etiqueta": K.nombre_grupo(c["nivel"], c["grado"])}


@app.get("/api/clases")
@login_requerido
def listar_clases():
    filas = db.consulta(
        "SELECT c.*, (SELECT COUNT(*) FROM alumnos a WHERE a.clase_id = c.id) AS n_alumnos, "
        "(SELECT COUNT(DISTINCT e.alumno_id) FROM evaluaciones e JOIN alumnos a ON a.id = e.alumno_id "
        " WHERE a.clase_id = c.id AND e.estado = 'completada') AS n_test "
        "FROM clases c WHERE c.docente_id = %s ORDER BY c.nivel DESC, c.grado, c.nombre", (session["docente_id"],))
    return jsonify([_clase_json(c, int(c["n_alumnos"]), int(c["n_test"])) for c in filas])


def _validar_clase(d):
    nombre = texto(d, "nombre", 1, 60, "Nombre de la clase")
    nivel = d.get("nivel")
    if nivel not in K.NIVELES:
        raise ValueError("Elige primaria o secundaria")
    try:
        grado = int(d.get("grado"))
    except (TypeError, ValueError):
        raise ValueError("Elige el grado") from None
    if grado not in K.NIVELES[nivel]["grados"]:
        raise ValueError("Ese grado no corresponde al nivel elegido")
    ciclo = str(d.get("ciclo") or "").strip()[:20] or None
    return nombre, nivel, grado, ciclo


@app.post("/api/clases")
@login_requerido
def crear_clase():
    try:
        nombre, nivel, grado, ciclo = _validar_clase(datos_json())
    except ValueError as e:
        return error(str(e))
    if db.consulta("SELECT id FROM clases WHERE docente_id = %s AND nombre = %s AND nivel = %s AND grado = %s",
                   (session["docente_id"], nombre, nivel, grado), uno=True):
        return error("Ya tienes una clase con ese nombre, nivel y grado", 409)
    nuevo = db.ejecutar("INSERT INTO clases (docente_id, nombre, nivel, grado, ciclo) VALUES (%s, %s, %s, %s, %s)",
                        (session["docente_id"], nombre, nivel, grado, ciclo))
    return jsonify(_clase_json(clase_propia(nuevo))), 201


@app.put("/api/clases/<int:clase_id>")
@login_requerido
def editar_clase(clase_id):
    actual = clase_propia(clase_id)
    if not actual:
        return error("Clase no encontrada", 404)
    d = datos_json()
    try:
        nombre, nivel, grado, ciclo = _validar_clase({**actual, **d})
    except ValueError as e:
        return error(str(e))
    db.ejecutar("UPDATE clases SET nombre = %s, nivel = %s, grado = %s, ciclo = %s WHERE id = %s",
                (nombre, nivel, grado, ciclo, clase_id))
    return jsonify(_clase_json(clase_propia(clase_id)))


@app.delete("/api/clases/<int:clase_id>")
@login_requerido
def borrar_clase(clase_id):
    if not clase_propia(clase_id):
        return error("Clase no encontrada", 404)
    db.ejecutar("DELETE FROM clases WHERE id = %s", (clase_id,))
    return jsonify({"ok": True})


def _datos_de_clase(clase):
    alumnos = db.consulta("SELECT * FROM alumnos WHERE clase_id = %s ORDER BY nombre", (clase["id"],))
    datos = cargar_datos([a["id"] for a in alumnos])
    res, perfiles = [], []
    for a in alumnos:
        r, pf = _resumen_alumno(a, datos[a["id"]])
        res.append(r)
        perfiles.append(pf)
    return alumnos, datos, res, perfiles


@app.get("/api/clases/<int:clase_id>")
@login_requerido
def detalle_clase(clase_id):
    clase = clase_propia(clase_id)
    if not clase:
        return error("Clase no encontrada", 404)
    _, _, res, perfiles = _datos_de_clase(clase)
    resumen = P.resumen_clase(perfiles)
    return jsonify({"clase": _clase_json(clase, len(res), resumen["con_test"]), "alumnos": res, "resumen": resumen})


# ------------------------------------------------------------------ alumnos
def _validar_alumno(d, parcial=False):
    out = {}
    if not parcial or "nombre" in d:
        out["nombre"] = texto(d, "nombre", 3, 160, "Nombre")
    if not parcial or "edad" in d:
        edad = d.get("edad")
        if edad in (None, ""):
            out["edad"] = None
        else:
            try:
                edad = int(edad)
            except (TypeError, ValueError):
                raise ValueError("La edad debe ser un número") from None
            if not 7 <= edad <= 18:
                raise ValueError("La edad debe estar entre 7 y 18 años")
            out["edad"] = edad
    if not parcial or "genero" in d:
        g = d.get("genero") or None
        if g is not None and g not in GENEROS:
            raise ValueError("Género no válido")
        out["genero"] = g
    if not parcial or "matricula" in d:
        m = str(d.get("matricula") or "").strip()[:30]
        out["matricula"] = m or None
    return out


@app.post("/api/clases/<int:clase_id>/alumnos")
@login_requerido
def crear_alumno(clase_id):
    clase = clase_propia(clase_id)
    if not clase:
        return error("Clase no encontrada", 404)
    d = datos_json()
    try:
        v = _validar_alumno(d)
    except ValueError as e:
        return error(str(e))
    if d.get("consentimiento") is not True:
        return error("Confirma que cuentas con el consentimiento de madre, padre o tutor")
    if v["matricula"] and db.consulta("SELECT id FROM alumnos WHERE clase_id = %s AND matricula = %s",
                                      (clase_id, v["matricula"]), uno=True):
        return error("Ya registraste un alumno con esa matrícula en esta clase", 409)
    nuevo = db.ejecutar(
        "INSERT INTO alumnos (docente_id, clase_id, nombre, edad, genero, matricula, consentimiento) "
        "VALUES (%s, %s, %s, %s, %s, %s, 1)",
        (session["docente_id"], clase_id, v["nombre"], v["edad"], v["genero"], v["matricula"]))
    return jsonify({"id": nuevo, "nombre": v["nombre"]}), 201


@app.post("/api/clases/<int:clase_id>/alumnos/lote")
@login_requerido
def crear_alumnos_lote(clase_id):
    if not clase_propia(clase_id):
        return error("Clase no encontrada", 404)
    d = datos_json()
    if d.get("consentimiento") is not True:
        return error("Confirma que cuentas con el consentimiento de madre, padre o tutor de todos los alumnos")
    nombres = [re.sub(r"\s+", " ", n).strip() for n in str(d.get("nombres", "")).splitlines()]
    nombres = [n for n in nombres if n]
    if not nombres:
        return error("Escribe al menos un nombre (uno por renglón)")
    if len(nombres) > 60:
        return error("Máximo 60 alumnos por lote")
    malos = [n for n in nombres if not 3 <= len(n) <= 160]
    if malos:
        return error(f"Nombre no válido (3 a 160 caracteres): «{malos[0][:30]}»")
    db.ejecutar_varios([
        ("INSERT INTO alumnos (docente_id, clase_id, nombre, consentimiento) VALUES (%s, %s, %s, 1)",
         (session["docente_id"], clase_id, n)) for n in nombres])
    return jsonify({"creados": len(nombres)}), 201


@app.get("/api/alumnos/<int:alumno_id>")
@login_requerido
def detalle_alumno(alumno_id):
    a = alumno_propio(alumno_id)
    if not a:
        return error("Alumno no encontrado", 404)
    d = cargar_datos([alumno_id])[alumno_id]
    pf = P.perfil_alumno(d["resultado"], d["partidas"])
    return jsonify({
        "alumno": {"id": a["id"], "nombre": a["nombre"], "edad": a["edad"], "genero": a["genero"],
                   "matricula": a["matricula"], "notas_docente": a["notas_docente"] or "",
                   "clase": {"id": a["clase_id"], "nombre": a["clase_nombre"], "nivel": a["nivel"], "grado": a["grado"],
                             "etiqueta": K.nombre_grupo(a["nivel"], a["grado"])}},
        "ajustes": _ajustes(a),
        "perfil": pf,
        "fecha_test": fecha_corta(d["fecha_test"]),
        "partidas": d["partidas"],
        "asignaciones": d["asig"],
        "recomendaciones": P.recomendaciones(pf, d["partidas"], [j for j, e in d["asig"].items() if e == "pendiente"]),
    })


@app.put("/api/alumnos/<int:alumno_id>")
@login_requerido
def editar_alumno(alumno_id):
    a = alumno_propio(alumno_id)
    if not a:
        return error("Alumno no encontrado", 404)
    d = datos_json()
    campos, valores = [], []
    try:
        v = _validar_alumno(d, parcial=True)
    except ValueError as e:
        return error(str(e))
    if v.get("matricula") and v["matricula"] != a["matricula"] and db.consulta(
            "SELECT id FROM alumnos WHERE clase_id = %s AND matricula = %s AND id <> %s",
            (a["clase_id"], v["matricula"], alumno_id), uno=True):
        return error("Ya existe esa matrícula en la clase", 409)
    for k, val in v.items():
        campos.append(f"{k} = %s")
        valores.append(val)
    if "notas_docente" in d:
        campos.append("notas_docente = %s")
        valores.append(str(d.get("notas_docente") or "").strip()[:1500] or None)
    if "accesibilidad" in d:
        acc = d["accesibilidad"] if isinstance(d["accesibilidad"], dict) else {}
        campos.append("accesibilidad_json = %s")
        valores.append(json.dumps({k: bool(acc.get(k)) for k in K.AJUSTES_ACCESIBILIDAD}))
    if "clase_id" in d:
        if not clase_propia(d["clase_id"] if isinstance(d["clase_id"], int) else -1):
            return error("Clase no encontrada", 404)
        if db.consulta("SELECT id FROM alumnos WHERE clase_id = %s AND matricula = %s AND id <> %s AND matricula IS NOT NULL",
                       (d["clase_id"], a["matricula"], alumno_id), uno=True):
            return error("Ya existe esa matrícula en la clase de destino", 409)
        campos.append("clase_id = %s")
        valores.append(d["clase_id"])
    if not campos:
        return error("No hay cambios")
    db.ejecutar(f"UPDATE alumnos SET {', '.join(campos)} WHERE id = %s", (*valores, alumno_id))
    return jsonify({"ok": True})


@app.delete("/api/alumnos/<int:alumno_id>")
@login_requerido
def borrar_alumno(alumno_id):
    if not alumno_propio(alumno_id):
        return error("Alumno no encontrado", 404)
    db.ejecutar("DELETE FROM alumnos WHERE id = %s", (alumno_id,))
    return jsonify({"ok": True})


# ------------------------------------------------------------------ test inicial
@app.get("/api/alumnos/<int:alumno_id>/test")
@login_requerido
def contenido_test(alumno_id):
    a = alumno_propio(alumno_id)
    if not a:
        return error("Alumno no encontrado", 404)
    return jsonify({"alumno": {"id": a["id"], "nombre": a["nombre"], "nivel": a["nivel"]}, "ajustes": _ajustes(a),
                    "test": Q.contenido_test(a["nivel"])})


@app.post("/api/alumnos/<int:alumno_id>/test")
@login_requerido
def enviar_test(alumno_id):
    if not alumno_propio(alumno_id):
        return error("Alumno no encontrado", 404)
    d = datos_json()
    try:
        intereses = Q.validar_envio(d.get("vak"), d.get("auto"), d.get("intereses"))
    except ValueError as e:
        return error(str(e))
    resultado = Q.calcular_resultado(d["vak"], d["auto"], intereses)
    db.ejecutar("INSERT INTO evaluaciones (alumno_id, estado, resultado_json, completada_en) "
                "VALUES (%s, 'completada', %s, CURRENT_TIMESTAMP)",
                (alumno_id, json.dumps(resultado, ensure_ascii=False)))
    return jsonify({"ok": True}), 201


# ------------------------------------------------------------------ minijuegos
@app.get("/api/alumnos/<int:alumno_id>/tablero")
@login_requerido
def tablero(alumno_id):
    a = alumno_propio(alumno_id)
    if not a:
        return error("Alumno no encontrado", 404)
    d = cargar_datos([alumno_id])[alumno_id]
    lista = [{"juego": J.JUEGOS[j], "estado": e} for j, e in d["asig"].items() if j in J.JUEGOS]
    lista.sort(key=lambda x: (x["estado"] == "completada", x["juego"]["id"]))
    return jsonify({"alumno": {"id": a["id"], "nombre": a["nombre"], "nivel": a["nivel"]}, "ajustes": _ajustes(a),
                    "test_hecho": d["resultado"] is not None, "asignaciones": lista})


@app.get("/api/alumnos/<int:alumno_id>/juegos/<jid>")
@login_requerido
def contenido_del_juego(alumno_id, jid):
    a = alumno_propio(alumno_id)
    if not a or jid not in J.JUEGOS:
        return error("No encontrado", 404)
    return jsonify({"juego": J.JUEGOS[jid], "ajustes": _ajustes(a), "contenido": J.contenido_juego(jid, a["nivel"])})


@app.post("/api/alumnos/<int:alumno_id>/juegos/<jid>/resultado")
@login_requerido
def resultado_juego(alumno_id, jid):
    a = alumno_propio(alumno_id)
    if not a or jid not in J.JUEGOS:
        return error("No encontrado", 404)
    try:
        puntaje, detalle = J.puntuar_juego(jid, a["nivel"], datos_json().get("datos"))
    except ValueError as e:
        return error(str(e))
    db.ejecutar("INSERT INTO partidas (alumno_id, juego_id, puntaje, detalle_json) VALUES (%s, %s, %s, %s)",
                (alumno_id, jid, puntaje, json.dumps(detalle, ensure_ascii=False)))
    if db.consulta("SELECT id FROM asignaciones WHERE alumno_id = %s AND juego_id = %s", (alumno_id, jid), uno=True):
        db.ejecutar("UPDATE asignaciones SET estado = 'completada', completada_en = CURRENT_TIMESTAMP "
                    "WHERE alumno_id = %s AND juego_id = %s", (alumno_id, jid))
    else:
        db.ejecutar("INSERT INTO asignaciones (alumno_id, juego_id, estado, completada_en) "
                    "VALUES (%s, %s, 'completada', CURRENT_TIMESTAMP)", (alumno_id, jid))
    return jsonify({"ok": True})  # el alumno no ve puntajes: solo el docente


@app.post("/api/alumnos/<int:alumno_id>/juegos/espejo/ronda")
@login_requerido
def ronda_espejo(alumno_id):
    a = alumno_propio(alumno_id)
    if not a:
        return error("No encontrado", 404)
    d = datos_json()
    try:
        logro, total = J.corregir_ronda_espejo(a["nivel"], d.get("ronda"), d.get("respuestas"))
    except ValueError as e:
        return error(str(e))
    return jsonify({"logro": logro, "total": total})


def _asignar(alumno_id, juegos):
    for jid in juegos:
        fila = db.consulta("SELECT estado FROM asignaciones WHERE alumno_id = %s AND juego_id = %s",
                           (alumno_id, jid), uno=True)
        if not fila:
            db.ejecutar("INSERT INTO asignaciones (alumno_id, juego_id) VALUES (%s, %s)", (alumno_id, jid))
        elif fila["estado"] == "completada":
            db.ejecutar("UPDATE asignaciones SET estado = 'pendiente', completada_en = NULL, "
                        "asignada_en = CURRENT_TIMESTAMP WHERE alumno_id = %s AND juego_id = %s", (alumno_id, jid))


@app.post("/api/alumnos/<int:alumno_id>/asignaciones")
@login_requerido
def asignar_alumno(alumno_id):
    if not alumno_propio(alumno_id):
        return error("Alumno no encontrado", 404)
    juegos = datos_json().get("juegos")
    if not isinstance(juegos, list) or not juegos or any(j not in J.JUEGOS for j in juegos):
        return error("Elige al menos un minijuego válido")
    _asignar(alumno_id, list(dict.fromkeys(juegos)))
    return jsonify({"ok": True}), 201


@app.delete("/api/alumnos/<int:alumno_id>/asignaciones/<jid>")
@login_requerido
def quitar_asignacion(alumno_id, jid):
    if not alumno_propio(alumno_id):
        return error("Alumno no encontrado", 404)
    db.ejecutar("DELETE FROM asignaciones WHERE alumno_id = %s AND juego_id = %s AND estado = 'pendiente'",
                (alumno_id, jid))
    return jsonify({"ok": True})


@app.post("/api/clases/<int:clase_id>/asignaciones")
@login_requerido
def asignar_clase(clase_id):
    if not clase_propia(clase_id):
        return error("Clase no encontrada", 404)
    jid = datos_json().get("juego")
    if jid not in J.JUEGOS:
        return error("Minijuego no válido")
    ids = [a["id"] for a in db.consulta("SELECT id FROM alumnos WHERE clase_id = %s", (clase_id,))]
    for i in ids:
        _asignar(i, [jid])
    return jsonify({"asignados": len(ids)}), 201


# ------------------------------------------------------------------ reportes PDF
def _slug(txt, largo=60):
    crudo = unicodedata.normalize("NFKD", txt.replace("º", "").replace("ª", "").replace("°", ""))
    crudo = "".join(ch for ch in crudo if not unicodedata.combining(ch))
    return re.sub(r"[^A-Za-z0-9_-]+", "_", crudo).strip("_")[:largo] or "x"


def _nombre_pdf_alumno(a):
    return f"Perfil_{_slug(a['nombre'], 70)}.pdf"


def _pdf_alumno(a, clase, docente, d):
    pf = P.perfil_alumno(d["resultado"], d["partidas"])
    if not pf["tiene_test"] and not pf["juegos_hechos"]:
        return None
    fecha = fecha_corta(d["fecha_test"]) or None
    return generar_pdf_alumno(a, clase, docente, pf, d["partidas"], d["asig"], fecha)


@app.get("/api/alumnos/<int:alumno_id>/pdf")
@login_requerido
def pdf_alumno(alumno_id):
    a = alumno_propio(alumno_id)
    if not a:
        return error("Alumno no encontrado", 404)
    clase = {"nombre": a["clase_nombre"], "nivel": a["nivel"], "grado": a["grado"]}
    pdf = _pdf_alumno(a, clase, docente_actual(), cargar_datos([alumno_id])[alumno_id])
    if pdf is None:
        return error("Este alumno aún no tiene resultados: pídele que conteste el test", 409)
    return send_file(io.BytesIO(pdf), mimetype="application/pdf", as_attachment=True, download_name=_nombre_pdf_alumno(a))


def _pdf_clase(clase, docente):
    alumnos, datos, res, perfiles = _datos_de_clase(clase)
    resumen = P.resumen_clase(perfiles)
    if not resumen["con_test"] and not resumen["con_juegos"]:
        return None, alumnos, datos
    return generar_pdf_clase(clase, docente, resumen, res, perfiles), alumnos, datos


@app.get("/api/clases/<int:clase_id>/pdf")
@login_requerido
def pdf_de_clase(clase_id):
    clase = clase_propia(clase_id)
    if not clase:
        return error("Clase no encontrada", 404)
    pdf, _, _ = _pdf_clase(clase, docente_actual())
    if pdf is None:
        return error("Todavía no hay resultados en esta clase", 409)
    return send_file(io.BytesIO(pdf), mimetype="application/pdf", as_attachment=True,
                     download_name=f"Clase_{_slug(clase['nombre'])}.pdf")


def _agregar_clase_al_zip(z, clase, docente, carpeta):
    pdf_c, alumnos, datos = _pdf_clase(clase, docente)
    total = 0
    if pdf_c:
        z.writestr(f"{carpeta}Clase_{_slug(clase['nombre'])}.pdf", pdf_c)
        total += 1
    usados = set()
    for a in alumnos:
        pdf = _pdf_alumno(a, clase, docente, datos[a["id"]])
        if pdf:
            nombre = _nombre_pdf_alumno(a)
            if nombre in usados:
                nombre = nombre[:-4] + f"_{a['id']}.pdf"
            usados.add(nombre)
            z.writestr(f"{carpeta}Alumnos/{nombre}", pdf)
            total += 1
    return total


@app.get("/api/clases/<int:clase_id>/reportes.zip")
@login_requerido
def zip_clase(clase_id):
    clase = clase_propia(clase_id)
    if not clase:
        return error("Clase no encontrada", 404)
    buf, docente = io.BytesIO(), docente_actual()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        total = _agregar_clase_al_zip(z, clase, docente, "")
    if not total:
        return error("Todavía no hay resultados en esta clase", 409)
    buf.seek(0)
    return send_file(buf, mimetype="application/zip", as_attachment=True,
                     download_name=f"Reportes_{_slug(clase['nombre'])}.zip")


@app.get("/api/reportes.zip")
@login_requerido
def zip_todo():
    docente = docente_actual()
    clases = db.consulta("SELECT * FROM clases WHERE docente_id = %s ORDER BY nivel DESC, grado, nombre", (session["docente_id"],))
    buf, total = io.BytesIO(), 0
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for c in clases:
            carpeta = f"{_slug(K.nombre_grupo(c['nivel'], c['grado']))}_{_slug(c['nombre'])}/"
            total += _agregar_clase_al_zip(z, c, docente, carpeta)
    if not total:
        return error("Todavía no hay resultados para exportar", 409)
    buf.seek(0)
    return send_file(buf, mimetype="application/zip", as_attachment=True, download_name="Reportes_Constelacion.zip")


@app.after_request
def cabeceras(resp):
    resp.headers["X-Content-Type-Options"] = "nosniff"
    resp.headers["X-Frame-Options"] = "DENY"
    resp.headers["Referrer-Policy"] = "same-origin"
    resp.headers["Content-Security-Policy"] = (
        "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self'; "
        "connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'")
    resp.headers["Permissions-Policy"] = "microphone=(), camera=(), geolocation=()"
    if request.path.startswith("/api/"):
        resp.headers["Cache-Control"] = "no-store"
    return resp


if __name__ == "__main__":
    app.run(host=os.getenv("HOST", "127.0.0.1"), port=int(os.getenv("PORT", "5000")),
            debug=os.getenv("FLASK_DEBUG", "0") == "1")
